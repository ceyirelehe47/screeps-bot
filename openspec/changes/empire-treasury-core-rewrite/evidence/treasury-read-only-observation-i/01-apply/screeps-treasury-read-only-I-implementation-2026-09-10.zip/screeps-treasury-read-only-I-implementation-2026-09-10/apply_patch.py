#!/usr/bin/env python3
"""Apply this package only at its exact clean Git baseline. No network/deploy."""
from __future__ import annotations
import argparse, hashlib, json, subprocess, sys
from pathlib import Path, PurePosixPath
BASE = "77d67d6a02cfb55029515e00503b598a78870ae5"

def git(repo: Path, *args: str) -> str:
    p = subprocess.run(["git", "-C", str(repo), *args], text=True, capture_output=True)
    if p.returncode:
        raise RuntimeError(f"git {' '.join(args)} failed: {p.stderr.strip()}")
    return p.stdout.strip()

def sha256(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()

def target(repo: Path, name: str) -> Path:
    rel = PurePosixPath(name)
    if rel.is_absolute() or not rel.parts or any(x in {".", "..", ".git"} for x in rel.parts):
        raise RuntimeError("unsafe package path")
    p = repo
    for part in rel.parts:
        p = p / part
        if p.is_symlink():
            raise RuntimeError(f"refusing symlink: {p}")
    return p

def main() -> None:
    a = argparse.ArgumentParser(description=__doc__)
    a.add_argument("--repo", type=Path, required=True)
    a.add_argument("--check-only", action="store_true")
    opts = a.parse_args()
    package = Path(__file__).resolve().parent
    manifest = json.loads((package / "manifest.json").read_text())
    repo = opts.repo.resolve()
    if Path(git(repo, "rev-parse", "--show-toplevel")).resolve() != repo:
        raise RuntimeError("--repo must be the worktree root")
    if manifest["baseHead"] != BASE or git(repo, "rev-parse", "HEAD") != BASE:
        raise RuntimeError(f"wrong baseline; required {BASE}; no auto-reset/rebase")
    if git(repo, "status", "--porcelain", "--untracked-files=all"):
        raise RuntimeError("working tree is not clean; do not discard unrelated changes")
    patch = package / "changes.patch"
    if sha256(patch) != manifest["patchSha256"]:
        raise RuntimeError("patch hash mismatch")
    for c in manifest["changes"]:
        p = target(repo, c["path"])
        supplied = package / "files" / c["path"]
        if sha256(supplied) != c["afterSha256"]:
            raise RuntimeError(f"output payload mismatch: {c['path']}")
        if c["beforeGitBlob"] is None:
            if p.exists(): raise RuntimeError(f"new path already exists: {c['path']}")
        elif git(repo, "rev-parse", f"HEAD:{c['path']}") != c["beforeGitBlob"]:
            raise RuntimeError(f"baseline file mismatch: {c['path']}")
    git(repo, "apply", "--check", "--whitespace=error-all", str(patch))
    if opts.check_only:
        print(json.dumps({"status": "CHECKED_NOT_APPLIED", "baseHead": BASE, "files": len(manifest["changes"])}))
        return
    git(repo, "apply", "--whitespace=error-all", str(patch))
    for c in manifest["changes"]:
        # Canonical repository bytes permit ordinary Git EOL conversion. Actual
        # generated build bytes must still be measured independently later.
        if git(repo, "hash-object", "--path", c["path"], c["path"]) != c["afterGitBlob"]:
            raise RuntimeError(f"post-apply canonical file mismatch: {c['path']}; preserve worktree")
    git(repo, "diff", "--check")
    print(json.dumps({"status": "APPLIED_NOT_COMMITTED_NOT_DEPLOYED", "baseHead": BASE, "files": len(manifest["changes"])}))

if __name__ == "__main__":
    try: main()
    except (OSError, ValueError, KeyError, RuntimeError) as e:
        print(str(e), file=sys.stderr)
        sys.exit(1)
