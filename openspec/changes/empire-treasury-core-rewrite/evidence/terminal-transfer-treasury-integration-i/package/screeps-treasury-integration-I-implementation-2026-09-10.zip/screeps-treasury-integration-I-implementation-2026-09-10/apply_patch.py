#!/usr/bin/env python3
"""Apply only to the exact reviewed, clean Git base. No commit/push/game access."""
from __future__ import annotations
import argparse
import hashlib
import json
import subprocess
from pathlib import Path

def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def git_blob(data: bytes) -> str:
    return hashlib.sha1(b"blob " + str(len(data)).encode("ascii") + b"\0" + data).hexdigest()

def run_git(repo: Path, *args: str) -> str:
    proc = subprocess.run(["git", "-C", str(repo), *args], capture_output=True, text=True, check=False)
    if proc.returncode:
        raise RuntimeError(f"git {' '.join(args)} failed ({proc.returncode})\n{proc.stdout}\n{proc.stderr}")
    return proc.stdout

def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", required=True, type=Path)
    parser.add_argument("--check-only", action="store_true")
    args = parser.parse_args()
    package = Path(__file__).resolve().parent
    repo = args.repo.resolve(strict=True)
    manifest = json.loads((package / "manifest.json").read_text(encoding="utf-8"))
    patch = package / "changes.patch"
    if sha256(patch.read_bytes()) != manifest["patchSha256"]:
        raise RuntimeError("Patch SHA256 mismatch; refusing to apply")
    actual_head = run_git(repo, "rev-parse", "HEAD").strip()
    if actual_head != manifest["baseHead"]:
        raise RuntimeError(f"Wrong base: expected {manifest['baseHead']}, got {actual_head}")
    if run_git(repo, "status", "--porcelain=v1", "--untracked-files=all").strip():
        raise RuntimeError("Working tree is not clean; preserve existing work before applying")
    seen: set[str] = set()
    for entry in manifest["files"]:
        name = entry["path"]
        if name in seen or not name.startswith("test/lab/"):
            raise RuntimeError("Unexpected/duplicate change path: " + name)
        seen.add(name)
        target = (repo / name).resolve()
        target.relative_to(repo)  # Raises if a path escapes the repository.
        packaged = package / "files" / name
        if sha256(packaged.read_bytes()) != entry["sha256"]:
            raise RuntimeError("Packaged file identity mismatch: " + name)
        if entry["action"] == "add":
            if target.exists() or target.is_symlink():
                raise RuntimeError("New target already exists: " + name)
        elif entry["action"] == "modify":
            data = target.read_bytes()
            if git_blob(data) != entry["beforeGitBlob"] or sha256(data) != entry["beforeSha256"]:
                raise RuntimeError("Original source bytes differ: " + name)
        else:
            raise RuntimeError("Unsupported patch action")
    run_git(repo, "apply", "--check", "--whitespace=error-all", str(patch))
    print(f"CHECKED {actual_head}: {len(seen)} exact target files; patch applies cleanly")
    if args.check_only:
        return
    run_git(repo, "apply", "--whitespace=error-all", str(patch))
    for entry in manifest["files"]:
        if sha256((repo / entry["path"]).read_bytes()) != entry["sha256"]:
            raise RuntimeError("Post-apply hash mismatch; preserve worktree for inspection: " + entry["path"])
    run_git(repo, "diff", "--check")
    print("APPLIED; every output hash matches. No commit, push, server or game action performed.")

if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError, KeyError, RuntimeError) as exc:
        raise SystemExit(str(exc)) from exc
