from pathlib import Path
import subprocess,os,json,time
ROOT=Path(__file__).resolve().parent.parent
REPO=ROOT/'repo';OUT=ROOT/'validation'
env=dict(os.environ);env['NODE_PATH']=subprocess.check_output(['npm','root','-g'],text=True).strip()
commands={
 'final-new-node':['node','--test',*[f'test/lab/treasury-integration/{s}.spec.cjs' for s in ['local','process','tooling']]],
 'final-old-tools':['node','--test',*[f'test/lab/terminal-transfer/tools/{s}.spec.cjs' for s in ['memory','stop','independent']]],
 'final-real-linux-smoke':['node','test/lab/treasury-integration/process-smoke.cjs','--run-owned-process-smoke'],
}
summary=[]
for name,cmd in commands.items():
 start=time.time()
 result=subprocess.run(cmd,cwd=REPO,env=env,capture_output=True,timeout=40)
 (OUT/(name+'.stdout.log')).write_bytes(result.stdout);(OUT/(name+'.stderr.log')).write_bytes(result.stderr)
 (OUT/(name+'.exit-code.txt')).write_text(str(result.returncode)+'\n')
 record={'name':name,'command':cmd,'cwd':str(REPO),'NODE_PATH':env['NODE_PATH'],'exit_code':result.returncode,'elapsed_seconds':round(time.time()-start,3)}
 (OUT/(name+'.command.json')).write_text(json.dumps(record,indent=2)+'\n');summary.append(record)
 print(name,result.returncode,result.stdout.decode(errors='replace').splitlines()[-8:])
 assert result.returncode==0
summary.append({'node':subprocess.check_output(['node','--version'],text=True).strip(),'npm':subprocess.check_output(['npm','--version'],text=True).strip(),'typescript':subprocess.check_output(['node','-e',"console.log(require('typescript').version)"],text=True,env=env).strip(),'full_repo':False,'full_kernel_jest_executed':False,'real_screeps_executed':False,'real_windows_adapter_executed':False})
(OUT/'executed-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
