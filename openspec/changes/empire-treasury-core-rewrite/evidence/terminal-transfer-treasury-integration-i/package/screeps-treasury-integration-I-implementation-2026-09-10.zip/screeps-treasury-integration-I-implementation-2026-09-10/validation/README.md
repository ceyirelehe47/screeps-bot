# 实际执行范围

2026-09-10，选定源码重建目录；不是完整仓库检出。Node v22.16.0，TypeScript 5.8.3。

最终结果：final-new-node 117/117；final-old-tools 48/48；均零失败/取消/跳过。final-real-linux-smoke 实际创建并终止专属 launcher+6 子进程，第二轮确认约6.2ms，仅说明本机这次运行。Windows 的700ms批量查询是确定性端口模拟，不是Windows实机。

syntax-check.json 为CJS语法检查和新TS转译诊断，**不是项目类型检查**。

second-reconstructed-apply.*：另一份选定源码副本 git apply --check、实际应用、17文件SHA256完全匹配，165个Node用例再跑通过。它不是完整Git worktree、也不是独立Agent环境。guard-wrong-base.txt验证应用脚本拒绝非准确基线。

first-local/new-tests-round2/old-tools-regression/combined-round3是实现中间阶段原始记录。最终以final-*、syntax-check与second-reconstructed-apply为准。117和48是Node数量，不与Jest的1497相加。

尚未执行：实际facade/kernel Jest、完整源图bundle构建、npm ci项目类型检查/全仓Jest、Windows真实进程smoke、真实Screeps、生产部署或远端push。Agent必须在完整仓库完成这些相应检查。

reference-sources为实际局部复跑使用的选定字节。labConfig已核对到当前7314277的blob 0379754eebb97204e9827e9a446e92d5914da8de；三个修改目标的旧blob见manifest。较早中间测试曾使用历史cal-0002配置，最终final-*与第二副本已使用该当前配置。
