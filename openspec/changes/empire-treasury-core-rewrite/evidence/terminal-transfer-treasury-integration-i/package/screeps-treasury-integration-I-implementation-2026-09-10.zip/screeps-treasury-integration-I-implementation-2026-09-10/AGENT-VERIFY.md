# Treasury Terminal Integration I：代码应用与独立验收

## 0. 任务和基线

仓库：`ceyirelehe47/screeps-bot`  
分支：`refactor/empire-treasury-rearchitecture`  
补丁唯一基线：`73142771a616a5a4ca466ac10752a79027f901bf`  
继承的实机配置验证 SHA：`7f47a0d44396495865111d2856a575736a9e6654`  
继承测试预算：243 suites / 1497 Jest tests。

工作分工已经改变：本包是 ChatGPT 写好的实现，Agent 先原样应用、独立验收，不重新从任务书写一套实现。发现问题先保留失败输入和原始输出，再另行修复；不得静默改到全绿后隐去首轮失败。

已接受的旧事实：raw Terminal API 实验 ec0001 真实发送 H100 并到账，Memory 往返成立；报价 26、实测 energy 净减少 10；自动进程退出确认超时，但后续系统检查支持最终停止。不能把这些旧证据改写成新国库业务证据。worldSize 缓存解释与“storage 杀死停止确认”解释尚未完整证实，不再当作已确定根因。

本轮目标：修复停止工具的批量确认/共同时间预算，并让首条真实业务经过**实际 Treasury facade/kernel**，验证它管理过资源、费用和容量且能正常退出。不是生产部署，不改国库内核，不推进 Defense。

用户本轮要求继续这批实现与验收。本文件不扩展到线上或第二场发送；执行端已有明确覆盖本轮一次本机实验的授权时直接沿用，不要求逐命令复述。工具平台的实际审批仍正常处理，不能靠此文档绕过。实现包本身没有运行游戏或执行发送。

## 1. 交付边界与继承保护

仅修改三个原有工具：

- `test/lab/terminal-transfer/tools/process-scope.cjs`：Windows 批量查询；整个终止+确认共用 4500ms，父调用的 5000ms watchdog 保留；root 身份、PID 重用、子进程完整性和审计仍检查。
- `.../local-runtime.cjs`：把阶段审计传入终止函数，仍只执行一次并缓存同一终止 promise。
- `.../lab-control.cjs`：增加 `run-treasury`，保存真实停止结果，新入口只接受一个严格核对的 bundle。

新增代码位于 `test/lab/treasury-integration/`：真实 adapter、协调器、装配入口、默认关闭开关、隔离构建器、后验判读、局部测试、实际 kernel 的 Jest 测试及 OS smoke。详见该目录 README。

以下保持冻结：生产 `src` 全树、根依赖/构建配置、原 raw API 的 main/observer/singleShot/sendGate/controlRecord/worldRead/sample、Slice 0 代码及其测试、所有旧原始证据。调用实际 Treasury 与“修改 Treasury”不同；本轮是隔离实验装配，没有向生产入口注册新 writer。

允许的后续必要变化仅包括：新世界实测值回填 `labConfig.ts`/example；将新 `enabled.ts` 改为 true；相应当前配置的 CLI 测试 fixture 配对；按真实收集结果更新预算两个文件；本轮代码真实缺陷的单独修复提交；本轮新增证据与当前状态说明。不要删除旧反例或修改历史 fixture 来迎合新配置。

## 2. 原样应用和首轮检查

在完整仓库中先确认 HEAD 和干净工作树，包放仓库外：

```sh
git rev-parse HEAD
git status --short
python /absolute/package/apply_patch.py --repo /absolute/screeps-bot --check-only
python /absolute/package/apply_patch.py --repo /absolute/screeps-bot
npm ci
node --test test/lab/treasury-integration/local.spec.cjs test/lab/treasury-integration/process.spec.cjs test/lab/treasury-integration/tooling.spec.cjs
node --test test/lab/terminal-transfer/tools/memory.spec.cjs test/lab/terminal-transfer/tools/stop.spec.cjs test/lab/terminal-transfer/tools/independent.spec.cjs
npx tsc --noEmit -p tsconfig.json
npx tsc --noEmit -p tsconfig.build.json
npx jest --config jest.config.cjs --runInBand --runTestsByPath test/lab/treasury-integration/integration.test.ts test/lab/treasury-integration/tools.test.ts
```

不要再应用任何基于 d69726a 或 5773f1a 的旧包。guard 会检查准确基线、源字节、目标文件不存在、补丁与输出 hash，不做自动 commit/push、不连接游戏。基线前移时先检查差异，禁止强行 overwrite。

交付端只具有经核对的部分工作树，**没有执行完整依赖下的类型检查、生产构建、实际 facade/kernel Jest、完整源图构建或真实引擎**。这些是本轮 Agent 必须完成的实质工作，不得用包内 117 个 Node 用例替代。局部测试使用 TypeScript 5.8.3；这里必须使用 npm ci 的真实锁定版本。

类型或路径不兼容若发生，保存首次失败，再做最小修复。不得将 facade/kernel 换成 fake 以让 integration 测试通过；不能从新 bundle 引入 `test/mock` 或 testHarness。测试文件本身允许使用测试 reset helper。

## 3. 独立验收重点

### 3.1 实际国库链路

Jest 的 `integration.test.ts` 连接真实 facade/kernel/registry，必须原样跑，并独立增加有意义的反例。至少核对这些语义，不以总数代替：

1. 正常 q26/实扣26 与 q26/实扣10 两个延迟结果：调用前世界未改、已接纳后 H100/fee q/容量100 占用；OK 当 tick 仍 unknown；后续合法完整交易才通过注册 reconciler 结算。
2. 在 closing 期间、尚未从 active 删除时，源 H、energy 与目标容量不双扣；清理后 active 真正退出。低实扣不能永久保留“26−10”的虚构支出。查看实际 `service.query` 和 `riskAdjustedFreeCapacity`，不关闭 subtractOutgoing/subtractReservations。
3. 无交易、缺一个视图、部分量、100+60 多相关 ID、同 ID 矛盾、错误整串 description/双方/路线/时间、结构替换、实扣超预算，保持 unknown、不重试。世界净余额相同但缺交易不是完成。
4. 单在途来自持久 active，跨实例、完整模块 reset 和不同 workKey 都不能发第二笔；旧 permit 拒绝。代码没有重新签发 retry，也不按年龄删除 unknown。
5. 真正的 processor 变化不会调用 fake host 的世界序 helper：测试故意只改世界，不顺手 bump。新代码只能在完整证据成立后衔接现有 world-sequence hook，再调用真实注册结算；不能用每 tick bump 或写 Memory 聚合假装退出。
6. 默认 disabled bundle 装载与 loop 不调用 API、不初始化实验控制槽；enabled 也必须先 observer。观察异常、缺武装、权限拒绝、假 permit、费用变化均不得直达 send。

### 3.2 停止修复

```sh
node test/lab/treasury-integration/process-smoke.cjs --run-owned-process-smoke
```

在 Windows 真实执行并存 stdout/stderr/exit，确认这个测试只终止自己创建的 7 个进程。已有 Node tests 覆盖 700ms/系统调用的批量路径、共享剩余预算、PID 重用、root 先消失不证明子进程退出、保留 survivor、audit/kill 错误等，但这些模拟不能代替 Windows 实证。

不要简单把父超时加到几十秒、把“根 PID 不存在”当全树已停、捕获任意异常后返回成功或杀所有 node.exe。若真实 OS 总成本仍超过 4500ms，记录阶段耗时后处理具体成本；未确认退出继续报告未确认，不伪造 PASS。

## 4. 固定实现、构建和预算

原样首轮通过后提交代码/测试（IMPL_HEAD）。构建器要求全部**实际运行源图**已经被 Git 跟踪且与 HEAD 相同，因此先提交再构建；不要绕过此检查。

```sh
node test/lab/treasury-integration/build.cjs --out /absolute/new-external-disabled-bundle
```

这一步必须在完整仓库完成。核对 manifest 的依赖图确实包含生产 facade/kernel，且没有 mock、原 singleShot、生产 main/runtimeServices、测试文件或 Node 运行时依赖。构建器的合成图用例不证明实际源图能构建。模块上限/解析拒绝若遇到真实合理依赖，先报告具体路径，不添加笼统放行。

原预算为 243/1497。代码预计新增 2 个 Jest suites、11 个 Jest tests（8 个 kernel 集成场景、3 个 Node wrapper）；**以真实收集为准**。117 个新 Node 用例在 wrapper 内执行，不额外加到 Jest 总数。沿仓库已有预算脚本流程更新 `test/test-suite-budget.json` 与必要锚点，保留实际收集输出。预算维护不修改生产依赖或行为。

测试修补阶段不机械重复整轮全仓压力测试。完整正式回归集中到后面新实测配置+enable+预算已固定的最终 SHA。

## 5. 一次新的本机实机验收

### 5.1 环境与准备

新目录、新一次性官方 standalone 世界、新合成用户、新实验 ID。固定路线和 H100 不变。禁止正式服、PTR、已有用户私服、真实账户/凭证、市场/生产/搬运等其他 writer。

先完成地图、房间、归属、Terminal 和资源 fixture；记录管理操作、安装版本、lockfile、启动命令、真实 PID/监听。**完成地图/fixture 后统一重启相关引擎进程**，不要只重启 runner 再把“各进程一定同 worldSize”当作事实。取得独立真实玩家基线后，才能绑定本次 shard、user、结构 ID、q。q 不照抄26或10。上次 worldSize 原因仍作为待证解释，不修改引擎扣费逻辑来对齐结果。

只允许 endpoint 中 H 与 energy、无 Power effect、无该账户其他经济 writer；这使单笔净 energy 差可用于受控费用核对。旧孤儿收集器不属于本次授权清理范围，不可全局杀掉；先识别并记录，避免误把别的进程或旧日志混成本次证据。

先用**无发送路径**的原 controlProbe 做 initialize → observe-false 两真实 tick → arm 一次 → observe-armed 两真实 tick → 暂停后 facts。工具顺序和显式绑定参数继续使用 `test/lab/terminal-transfer/tools/README.md`。每步证据目录必须新建，不覆盖失败记录。

准备期 `enabled.ts` 保持 false，活动代码只装 no-send probe。共享 labConfig 先填本次真实身份与 q（本实验 cap=q）；占位 T 只用于无发送准备，不视为正式发送时间。历史 calibration 反例仍配历史配置；活 CLI 正常对照另配本轮真实 facts，不能反向由 config 生成。

### 5.2 首次固定最终 T 和正式验证

observe-armed 结束后实际稳定暂停 T0；再次确认两端和控制槽未变，以 `T≥T0+3` 首次固定最终 T。同步 example；新 `enabled.ts` 设 true（没有环境变量或 Memory enable 后门）。提交所有运行代码、测试、配置和预算，记为 VALIDATION_HEAD；不再改 T 试成功。

在该 SHA 上一次完成：

```sh
# Git Bash，先 unset DEST；不得 npm run push/local
npx tsc --noEmit -p tsconfig.json
npx tsc --noEmit -p tsconfig.build.json
npm run build
npx jest --config jest.config.cjs --runInBand --runTestsByPath test/lab/treasury-integration/integration.test.ts test/lab/treasury-integration/tools.test.ts
npx jest --config jest.config.cjs --runInBand --runTestsByPath test/lab/terminal-transfer/probe.test.ts test/lab/terminal-transfer/runI.test.ts test/lab/terminal-transfer/calibration.test.ts test/lab/terminal-transfer/controlRemediation.test.ts
npx jest --config jest.config.cjs --runInBand --runTestsByPath src/runtime/treasury/treasuryTerminalTransferSlice0.test.ts src/runtime/treasury/treasuryTerminalTransferSlice0RemediationI.test.ts src/runtime/treasury/treasuryTerminalTransferSlice0RemediationII.test.ts
npx jest --config jest.config.cjs src/runtime/treasury/ --runInBand
npx jest --config jest.config.cjs --runInBand
node scripts/verify-jest-budget.mjs
node scripts/verify-lab-calibration.mjs --facts /absolute/current/facts/calibration-facts.json
node test/lab/treasury-integration/build.cjs --out /absolute/new-external-live-bundle
git diff --exit-code 73142771a616a5a4ca466ac10752a79027f901bf HEAD -- src package.json package-lock.json jest.config.cjs tsconfig.json tsconfig.build.json rollup.config.js
git diff --check
```

每个测试命令保存实际命令、退出码、stdout/stderr；Jest 使用 `--json --outputFile` 独立保存原件。构建实验前后同一 dist/main.js 字节应不变；生产构建之间有 buildTime 不能据此冒充源码变化。第二干净工作树在相同最终 SHA 独立 npm ci，重跑新集成/局部工具/Slice0并重建新 bundle逐字节比较，不再次机械跑完整压力/budget。

### 5.3 正式装载和一次恢复

仅装载新 bundle 的 **一个 `main` 模块**。其内部已包含 observer 和新 adapter，**不得另外装载/调用旧 single-shot**，避免两条发送路径。实际活动模块回读字节须等于本次 manifest/当前源码；工具会再次核对。

```sh
node test/lab/terminal-transfer/tools/lab-control.cjs \
  --command run-treasury \
  --environment /absolute/new-env --host ::1 --port 21027 \
  --pid ACTUAL_BOUND_PID --user ACTUAL_SYNTHETIC_ID --username CURRENT_USERNAME \
  --experiment CURRENT_EXPERIMENT_ID --out /absolute/new-formal-evidence \
  --proof /absolute/observe-armed/console.jsonl \
  --facts /absolute/facts/calibration-facts.json \
  --main /absolute/new-external-live-bundle/main.js
```

填写实际本机路径和绑定值，不复制占位符。CLI 先核对 prepare proof/C02/暂停端点/唯一活动 bundle，再订阅、固定180秒期限并恢复一次。观察 T−2..T+20，共23个 tick；最多一次真实 API 调用（不是一次成功）；费用、数量和接收空间由真实 Treasury 授权，原控制槽仍守住实验单次边界。

non-OK、throw、缺观察、暂停或退出失败，立即保留事实并停止。不改ID/T、不扩大费用、不降低判据、不清 unknown、不 rearm 重发。旧世界不重置后冒充新实验。

## 6. 结果必须回答的问题

实机报告分开给出 API、国库和工具结果，不只贴最后一行 PASS：

- 唯一调用边界和同步返回，T 前世界未生效、T 后真实源/目标 H/energy/free/cooldown 和双方交易视图；完整 description 和唯一交易 ID 对齐数据库原件。
- kernel 接纳及尝试 ID；admitted 阶段的 pending 和 q/H/容量占用；OK 后 unknown；注册 reconciler 的结论；closing 和退出时实际 query 不双扣，active 最终清空，ring仅用于关联审计而不是授权。
- 实测费用与报价分别报告。费用低于 q 可以作为此隔离场景的有界支出通过，但必须保留异常说明，不宣称模型准确/正式服无此问题；费用超q或证据矛盾不能判通过。
- 暂停请求、稳定暂停、撤装保留 attempted、真实自动进程确认、最终系统监听分别核对。`process-stop-result.json` 必须有实际确认对象和阶段耗时；不能把手工后来找到的“进程已停”填成工具当时已通过。
- `treasury-verification.json` 是只读后验检查，不是新的游戏授权字段；Agent 仍须从原始证据独立判断。旧ENGINE_LAB_PASS不自动变成本轮TREASURY_INTEGRATION_PASS。

建议证据根：`openspec/changes/empire-treasury-core-rewrite/evidence/terminal-transfer-treasury-integration-i/`。包含原包指令/hash、原样首轮、独立失败输入、Windows smoke、最终验证/第二树、安装与控制往返、正式raw console/actions/Memory/objects/transactions、停止结果和报告。缺失如实记缺失，不重造历史原件。

## 7. 提交与交付纪律

实现/必要修复、预算、实测配置、证据尽量分开线性提交。未验证的逻辑修改不能沿用旧 SHA 通过结论。保留原包首轮失败，修复单独说明；不 reset/rebase/force push/amend 已推历史。不合并 main、不上传生产 Screeps。

完成后在本分支正常 commit/push（按执行会话已有仓库权限），提交 HEAD、最终验证 SHA、完整差异、实际测试数量与原始证据索引。若实机尚未运行，明确 LIVE_NOT_RUN；若出现真实失败，说明调用次数确定值或未知边界，不把“没有发现交易”写成“确定没调用”。
