# Treasury Terminal Integration I — implementation package

补丁基线：ceyirelehe47/screeps-bot，refactor/empire-treasury-rearchitecture，73142771a616a5a4ca466ac10752a79027f901bf。

先读 `AGENT-VERIFY.md`。本包含真实实现，不要求 Agent 从头重写：新增 test/lab/treasury-integration 的 adapter/coordinator/assembly、默认关闭入口、独立构建与验收；修复原停止工具批量进程确认。17 个修改目标（3 个修改、14 个新增），生产 src 和原 API/Slice0 不动。

- `changes.patch` / `files/`：待应用代码，manifest 记录输入输出身份。
- `apply_patch.py`：只对准确基线和干净工作树应用；可 --check-only。不执行 commit/push 或游戏动作。
- `validation/`：实际本地执行命令、日志、退出码与范围说明。
- `reference-sources/`：本地局部复跑使用的选定旧源码，不自动应用，不是完整仓库。

实际已跑：新 Node 117/117；受影响原工具 Node 48/48；真实 Linux 自建 launcher+6 子进程停止 smoke。另做 Node 语法检查、TypeScript 语法转译检查及补丁应用重放。完整类型检查、实际 kernel Jest、整个生产依赖图构建、全仓回归、Windows 和真实 Screeps 尚未在交付端执行，须 Agent 验证。局部 TypeScript 为5.8.3，不等于项目锁定版本。

`enabled.ts` 默认 false。没有已发送的新业务，没有新国库实机 PASS，没有生产上传。本地实验中确认的原 raw API 成功只是继承基线。

局部复跑（不把它说成完整仓库验证）：在单独空目录复制 reference-sources 后覆盖 files，用该目录为 cwd 运行三个新 spec 及 memory/stop/independent 三个旧 spec；需要可解析的 TypeScript。完整仓库应通过 apply_patch.py，并由 npm ci 提供项目依赖。不要把 reference-sources 整树覆盖到用户工作仓库。
