'use strict';
const fs=require('node:fs'),path=require('node:path'),cp=require('node:child_process'),ts=require('typescript');
const root=path.resolve(__dirname,'../repo');
const dirs=['test/lab/treasury-integration','test/lab/terminal-transfer/tools'];
const checks=[];
for(const dir of dirs)for(const name of fs.readdirSync(path.join(root,dir))){
 const rel=dir+'/'+name,p=path.join(root,rel);if(!fs.statSync(p).isFile())continue;
 if(name.endsWith('.cjs')){cp.execFileSync(process.execPath,['--check',p],{stdio:'pipe'});checks.push({file:rel,check:'node --check',pass:true});}
 else if(dir.endsWith('treasury-integration')&&name.endsWith('.ts')){
  const r=ts.transpileModule(fs.readFileSync(p,'utf8'),{fileName:p,reportDiagnostics:true,compilerOptions:{target:ts.ScriptTarget.ES2020,module:ts.ModuleKind.CommonJS}});
  if((r.diagnostics||[]).some(d=>d.category===ts.DiagnosticCategory.Error))throw Error('TS transpilation failed '+rel);
  checks.push({file:rel,check:'TypeScript syntax/transpile only (NOT project typecheck)',pass:true});
 }
}
console.log(JSON.stringify({typescript:ts.version,checks,projectTypecheckExecuted:false},null,2));
