#!/usr/bin/env node
'use strict';

const path=require('node:path');
const C=require('./common.cjs');
const S=require('./probe-session.cjs');
const R=require('./read-only-client.cjs');

async function main(argv) {
  const o=C.options(argv,['repo','secret','run'],['postflight']);
  C.required(o,'repo','secret','run');
  if(!o.postflight)C.fail('EXPLICIT_POSTFLIGHT_FLAG_REQUIRED');
  const repo=path.resolve(o.repo),run=path.resolve(o.run);
  if(C.git(repo,['rev-parse','HEAD'])!==C.PROBE_REFACTOR_BASE)C.fail('PROBE_REFACTOR_BASE_MISMATCH');
  if(C.git(repo,['status','--porcelain']))C.fail('PROBE_REFACTOR_WORKTREE_DIRTY');
  const session=S.loadProbeSession(run);
  if(process.env.DEST||process.env.DEPLOY_ALLOW_DIRTY)C.fail('UNSAFE_PROBE_ENVIRONMENT');
  const secret=C.loadSecret(path.resolve(o.secret));
  const guard=C.loadGuard(repo);
  const api=R.createReadOnlyClient(secret);
  R.assertReadOnlySurface(api);
  const after=await S.readOnlineBaselineResilient({api,guard,record:()=>{},redact:secret.redact});
  const result=S.writePostflight(run,after);
  console.log(secret.redact(JSON.stringify({...result,runId:session.runId})));
}

module.exports={main};
if(require.main===module)C.entrypoint(()=>main(process.argv.slice(2)));
