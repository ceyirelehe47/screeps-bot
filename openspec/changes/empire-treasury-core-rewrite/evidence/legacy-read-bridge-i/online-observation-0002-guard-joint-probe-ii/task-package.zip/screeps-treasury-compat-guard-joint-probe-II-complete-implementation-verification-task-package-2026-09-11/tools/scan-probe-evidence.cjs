#!/usr/bin/env node
'use strict';
const fs=require('node:fs');const path=require('node:path');const crypto=require('node:crypto');
function fail(code,details={}){const e=new Error(code);e.code=code;e.details=details;throw e;}
function opts(argv){const o={};for(let i=0;i<argv.length;i+=2){if(!argv[i]?.startsWith('--')||!argv[i+1])fail('INVALID_ARGUMENTS');o[argv[i].slice(2)]=argv[i+1];}for(const k of ['root','secret','out'])if(!o[k])fail('MISSING_ARGUMENT');return o;}
function walk(root){const out=[];for(const entry of fs.readdirSync(root,{withFileTypes:true})){const full=path.join(root,entry.name);if(entry.isDirectory())out.push(...walk(full));else if(entry.isFile())out.push(full);}return out;}
function loadToken(file){let value;try{value=JSON.parse(fs.readFileSync(file,'utf8'))?.main?.token;}catch{fail('CREDENTIAL_FILE_INVALID');}
  if(typeof value!=='string'||value.length<16||/[\s\r\n]/.test(value))fail('CREDENTIAL_FILE_INVALID');return value;}
function main(){const o=opts(process.argv.slice(2)),root=path.resolve(o.root),secret=path.resolve(o.secret),out=path.resolve(o.out);
  if(!fs.statSync(root).isDirectory()||fs.existsSync(out))fail('SCAN_ARGUMENT_INVALID');const token=loadToken(secret);
  const needles=[['raw-token',Buffer.from(token)],['url-encoded-token',Buffer.from(encodeURIComponent(token))],
    ['token-prefix-8',Buffer.from(token.slice(0,8))],['token-prefix-16',Buffer.from(token.slice(0,16))]];
  const hits=[];let filesScanned=0,totalBytes=0;
  for(const file of walk(root)){if(path.resolve(file)===out)continue;const bytes=fs.readFileSync(file);filesScanned++;totalBytes+=bytes.length;
    for(const [kind,needle] of needles)if(needle.length&&bytes.includes(needle))hits.push({file:path.relative(root,file).replace(/\\/g,'/'),kind});}
  const result={status:hits.length?'PROBE_EVIDENCE_SECRET_SCAN_FAILED':'PROBE_EVIDENCE_SECRET_SCAN_CLEAN',
    filesScanned,totalBytes,needleKinds:needles.map(x=>x[0]),hitCount:hits.length,hits};
  fs.writeFileSync(out,JSON.stringify(result,null,2)+'\n',{flag:'wx',mode:0o600});
  console.log(JSON.stringify({status:result.status,filesScanned,totalBytes,hitCount:hits.length}));if(hits.length)process.exitCode=2;}
try{main();}catch(error){process.stderr.write(JSON.stringify({error:error.code||String(error.message||'SCAN_FAILED'),details:error.details||{}})+'\n');process.exitCode=1;}
