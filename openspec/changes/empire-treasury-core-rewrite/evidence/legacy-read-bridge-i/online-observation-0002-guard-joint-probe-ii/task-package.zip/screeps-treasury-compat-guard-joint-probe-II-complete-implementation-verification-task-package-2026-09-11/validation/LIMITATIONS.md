# 制作方验证边界

制作方已实际执行：

- 56 项完整实现测试，包括专用 collector 子进程与加速的 Guard probe 完整进程循环；
- probe session 与正式 profile / 绝对 tick 窗口的解耦合同；
- materializer 的 25 文件映射及 tests/ 目录布局合同；
- 独立 probe verifier 的 session/preflight 绑定、约 25 分钟 heartbeat 时间跨度、时间通路计数对账、停止请求和残留 lock 拒绝反例；
- 全部 CJS 语法检查；
- 使用 16 个合成基底用例验证 `verify-toolkit` 的 72 项计数、名单及 overlay 字节合同；
- evidence 秘密扫描器的 CLEAN 正对照与含合成凭据负对照。

制作方未执行、必须由 Agent 完成：

- 从用户真实 Git 对象构造 25 个历史基底文件并运行真实 72 项完整 toolkit；
- Windows 实机文件锁、后台 shell 与实际进程退出文件路径；
- 官方服账号、活动分支、code 与 game/time 只读前检；
- 一次连续 25 分钟 collector + Guard 联合探针；
- 前后线上模块摘要实测；
- 使用用户当前真实 token 的 evidence 秘密扫描。

本包不包含任何真实凭据，也没有执行 Screeps POST、候选上传、恢复、console 注入或 Memory 写。
