'use strict';
const test=require('node:test');const assert=require('node:assert/strict');
const W=require('../probe-watch.cjs');const S=require('../probe-session.cjs');
const session={kind:S.SESSION_KIND,runId:'a'.repeat(32),userId:'u1',shard:'shard1'};

test('probe watch tracks authentication, console and cpu without a formal profile',()=>{
  const watch=W.createProbeWatch(session,42,1000);
  watch.opened(1100);
  assert.equal(watch.frame('auth ok',1200),'auth');
  assert.equal(watch.frame(JSON.stringify(['user:u1/console',{shard:'shard1',messages:{log:[],results:[]}}]),1300),'console');
  assert.equal(watch.frame(JSON.stringify(['user:u1/cpu',{cpu:12,memory:34}]),1400),'cpu');
  assert.equal(watch.state.lastConsoleAtMs,1300);assert.equal(watch.state.lastCpuAtMs,1400);
  assert.equal('profile' in watch.state,false);
});

test('a live bridge report on the old production baseline fails the control-plane probe',()=>{
  const watch=W.createProbeWatch(session,42,1000);watch.opened(1100);watch.frame('auth ok',1200);
  const report=JSON.stringify({kind:'treasury-legacy-read-bridge',tick:123});
  const frame=JSON.stringify(['user:u1/console',{shard:'shard1',messages:{log:[report],results:[]}}]);
  assert.equal(watch.frame(frame,1300),'console');
  assert.equal(watch.state.unexpectedBridgeReports,1);
  assert.equal(watch.state.stopReason,'unexpected_bridge_report_on_production_baseline');
});

test('wrong shard console and unrelated channels do not satisfy freshness',()=>{
  const watch=W.createProbeWatch(session,42,1000);watch.opened(1100);watch.frame('auth ok',1200);
  assert.equal(watch.frame(JSON.stringify(['user:u1/console',{shard:'shard0',messages:{log:[],results:[]}}]),1300),'ignored');
  assert.equal(watch.frame(JSON.stringify(['user:other/cpu',{cpu:1}]),1400),'ignored');
  assert.equal(watch.state.lastConsoleAtMs,null);assert.equal(watch.state.lastCpuAtMs,null);
});

test('terminal evidence preserves close and error classifications',()=>{
  const watch=W.createProbeWatch(session,42,1000);
  watch.terminal('socket_closed',{failed:true,close:{code:1006,reason:'lost',wasClean:false},error:{code:'ECONNRESET'}},1500);
  assert.equal(watch.state.state,'failed');assert.equal(watch.state.socketState,'closed');
  assert.equal(watch.state.closeCode,1006);assert.equal(watch.state.errorCode,'ECONNRESET');
});
