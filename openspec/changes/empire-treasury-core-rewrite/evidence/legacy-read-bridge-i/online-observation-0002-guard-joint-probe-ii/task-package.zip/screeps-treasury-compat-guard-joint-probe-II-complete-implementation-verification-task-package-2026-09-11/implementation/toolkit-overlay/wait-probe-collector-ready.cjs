#!/usr/bin/env node
'use strict';

const fs=require('node:fs');
const path=require('node:path');
const {performance}=require('node:perf_hooks');
const C=require('./common.cjs');
const S=require('./probe-session.cjs');
const G=require('./guard-control.cjs');

async function waitReady(run,{timeoutMs=30000,pause=C.pause,clock=()=>performance.now(),now=Date.now}={}) {
  const session=S.loadProbeSession(run,{forStart:true,now:now()});
  const file=name=>path.join(run,name);
  const end=clock()+timeoutMs;
  let lastReason='collector_not_started';
  while(clock()<end) {
    if(fs.existsSync(file('upload-attempt.json')))C.fail('PROBE_UPLOAD_ATTEMPT_PRESENT');
    if(fs.existsSync(file('collector-result.json')))C.fail('PROBE_COLLECTOR_EXITED_BEFORE_READY');
    const heartbeat=await G.readJsonArtifact(file('heartbeat.json'),16384);
    const lock=await G.readJsonArtifact(file('collector.lock'),16384);
    if(heartbeat&&lock) {
      const current=now();
      if(heartbeat.runId!==session.runId||lock.runId!==session.runId||heartbeat.pid!==lock.pid)lastReason='collector_identity_mismatch';
      else if(heartbeat.state!=='streaming'||heartbeat.socketState!=='open')lastReason='collector_not_streaming';
      else if(!Number.isFinite(heartbeat.lastConsoleAtMs)||current-heartbeat.lastConsoleAtMs>10000)lastReason='collector_console_not_fresh';
      else if(!Number.isFinite(heartbeat.lastCpuAtMs)||current-heartbeat.lastCpuAtMs>10000)lastReason='collector_cpu_not_fresh';
      else {
        const result={status:'PROBE_COLLECTOR_READY',runId:session.runId,pid:heartbeat.pid,
          readyAtMs:current,lastConsoleAtMs:heartbeat.lastConsoleAtMs,lastCpuAtMs:heartbeat.lastCpuAtMs};
        C.writeNew(file('collector-ready.json'),result);
        return result;
      }
    }
    await pause(250);
  }
  C.fail('PROBE_COLLECTOR_READY_TIMEOUT',{lastReason});
}

async function main(argv) {
  const o=C.options(argv,['run','timeout-ms'],['wait']);C.required(o,'run');
  if(!o.wait)C.fail('EXPLICIT_WAIT_FLAG_REQUIRED');
  const timeoutMs=o['timeout-ms']===undefined?30000:Number(o['timeout-ms']);
  C.integer(timeoutMs,1000,60000,'PROBE_READY_TIMEOUT_INVALID');
  const result=await waitReady(path.resolve(o.run),{timeoutMs});
  console.log(JSON.stringify(result));
}

module.exports={waitReady,main};
if(require.main===module)C.entrypoint(()=>main(process.argv.slice(2)));
