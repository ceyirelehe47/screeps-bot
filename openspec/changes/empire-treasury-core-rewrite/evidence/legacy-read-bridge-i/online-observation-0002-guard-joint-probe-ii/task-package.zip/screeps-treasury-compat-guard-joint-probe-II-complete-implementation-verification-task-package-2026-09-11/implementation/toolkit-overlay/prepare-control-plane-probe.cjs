#!/usr/bin/env node
'use strict';

const path=require('node:path');
const C=require('./common.cjs');
const S=require('./probe-session.cjs');
const R=require('./read-only-client.cjs');

async function main(argv) {
  const o=C.options(argv,['repo','secret','run','duration-ms'],['prepare']);
  C.required(o,'repo','secret','run','duration-ms');
  if(!o.prepare)C.fail('EXPLICIT_PREPARE_FLAG_REQUIRED');
  const repo=path.resolve(o.repo),run=path.resolve(o.run);
  const durationMs=Number(o['duration-ms']);
  C.integer(durationMs,S.MIN_DURATION_MS,S.MAX_DURATION_MS,'PROBE_DURATION_INVALID');
  if(process.env.DEST||process.env.DEPLOY_ALLOW_DIRTY)C.fail('UNSAFE_PROBE_ENVIRONMENT');
  const head=C.git(repo,['rev-parse','HEAD']);
  if(head!==C.PROBE_REFACTOR_BASE)C.fail('PROBE_REFACTOR_BASE_MISMATCH',{expected:C.PROBE_REFACTOR_BASE,actual:head});
  if(C.git(repo,['status','--porcelain']))C.fail('PROBE_REFACTOR_WORKTREE_DIRTY');
  const secret=C.loadSecret(path.resolve(o.secret));
  const guard=C.loadGuard(repo);
  const api=R.createReadOnlyClient(secret);
  R.assertReadOnlySurface(api);
  const baseline=await S.readOnlineBaselineResilient({api,guard,record:()=>{},redact:secret.redact});
  const session=S.createProbeSession({baseline,durationMs});
  S.writePreparedRun(run,session);
  console.log(secret.redact(JSON.stringify({
    status:'CONTROL_PLANE_PROBE_SESSION_PREPARED',runId:session.runId,durationMs,
    observedTick:baseline.observedTick,digestHash:baseline.digest.hash,
    formalProfileUsed:false,candidateSnapshotUsed:false,onlineWriteAuthorized:false,
  })));
}

module.exports={main};
if(require.main===module)C.entrypoint(()=>main(process.argv.slice(2)));
