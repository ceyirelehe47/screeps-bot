# Supersession boundary

本包只取代上一轮 v2 任务书中无法执行的“§6 联合无上传探针”步骤，不撤销已经验收并推送的结果：

- `c37b2c18762cc5a2e48f48e23900518e7d569a11`：证据整改；
- `eb00879a1ff71275ff32e310378d3590fc910e6a`：Guard 控制面完整实现离线验证与窗口过期记录；
- `fcfc125f0e5cd6c3370318b4fee0450f4d09af53`：兼容候选默认 OFF。

上一包把只读控制面探针 session 绑定到既有正式候选的绝对 tick 窗口 `73631900–73633000`。执行时线上 tick 已越过该窗口，故 session 永久无法合法构造。本包用专用 `guard-control-plane-probe-session/v2` 取代该耦合：

- 不读取或要求正式 profile；
- 不要求未来 `startTick`；
- 不生成 backup/candidate 快照；
- 不包含候选上传或恢复；
- 只以当前线上生产摘要、账号/分支/shard 身份与墙钟时长绑定一次探针。

不得重新执行已完成的 evidence remediation，也不得再使用旧的固定 profile commit 构造联合探针。
