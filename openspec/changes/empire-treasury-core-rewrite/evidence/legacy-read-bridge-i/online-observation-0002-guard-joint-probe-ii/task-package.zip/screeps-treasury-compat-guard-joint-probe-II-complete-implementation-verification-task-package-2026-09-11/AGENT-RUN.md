# Treasury Legacy Read Bridge I
## Guard Joint Probe II · Complete Implementation Verification Run

**本任务包已包含完整实现。Agent 只应用固定字节、运行固定测试、执行一次只读联合探针并归档证据。禁止 Agent 补写、修改、调参或“修绿”。**

任一步失败时保留原始输出并停止；不得现场修改本包或 materialized toolkit，不得换 session、重启拼接、放宽阈值或上传候选。

---

## 1. 固定基线

仓库：`ceyirelehe47/screeps-bot`

```text
refactor/empire-treasury-rearchitecture
  eb00879a1ff71275ff32e310378d3590fc910e6a

compat/treasury-read-bridge-i
  fcfc125f0e5cd6c3370318b4fee0450f4d09af53
```

启动后：

```bash
git -C "$REFACTOR_REPO" fetch origin
git -C "$COMPAT_REPO" fetch origin

node "$TASK/tools/verify-current-heads.cjs" \
  --refactor "$REFACTOR_REPO" \
  --compat "$COMPAT_REPO"
```

必须得到 `GUARD_JOINT_PROBE_BASELINE_VERIFIED`。两个工作树均须干净且本地/远端 SHA 完全一致。漂移时停止并报告 `BASELINE_DRIFT`；禁止 merge、rebase、reset、amend、cherry-pick 或 force-push。

本轮没有候选上传授权。compat 分支必须始终保持默认 OFF 且零提交。

---

## 2. 已完成实现

`implementation/toolkit-overlay/` 是完整实现，不是待办设计。核心新增入口：

```text
probe-session.cjs
read-only-client.cjs
prepare-control-plane-probe.cjs
probe-watch.cjs
probe-console-collector.cjs
wait-probe-collector-ready.cjs
guard-probe.cjs
postflight-control-plane-probe.cjs
verify-joint-probe.cjs
```

实现性质：

- 专用 session：`guard-control-plane-probe-session/v2`；
- session 只绑定当前线上生产摘要、账号/分支/shard 身份、runId 与 25 分钟墙钟时长；
- 不含 `profile`、`startTick/endTick`、`candidate`、`backup` 或 due ticks；
- read-only client 只暴露 `me/branches/code/time`，不暴露 `setCode`；
- 前检与后检只落摘要，不落模块正文；
- collector 独立使用 probe session，不导入正式 `session.cjs`；
- Guard 每 15 秒读一次 tick，每周期最多 3 次尝试，单次最多 2500ms，退避 250/750ms；
- 一个完整失败周期允许 degraded，第二个连续失败周期 fail-closed；
- collector PID、console、CPU、tick 单调性和线上代码摘要均由独立 verifier 核验；
- 正式 profile 窗口过期现在输出稳定错误码 `PROFILE_WINDOW_EXPIRED`，不再被掩码成普通消息。

Agent 不得编辑任何上述文件。

---

## 3. 包与实现验证

```bash
node "$TASK/tools/verify-package.cjs"
node "$TASK/tools/validate-materializer-layout.cjs"
node "$TASK/tools/validate-probe-decoupling.cjs"
node "$TASK/tools/verify-implementation-overlay.cjs"
```

必须取得：

```text
PACKAGE_INTEGRITY_VERIFIED
TOOL_BASE_LAYOUT_CONTRACT_VERIFIED
CONTROL_PLANE_PROBE_DECOUPLING_CONTRACT_VERIFIED
GUARD_JOINT_PROBE_IMPLEMENTATION_TESTS_VERIFIED
  tests=56
  pass=56
  fail=0
```

任一失败时停止并报告 `PACKAGE_OR_IMPLEMENTATION_VERIFICATION_FAILED`，不得修改包。

---

## 4. 构造固定完整 toolkit

必须在全部 Git 工作树外创建新目录：

```bash
TOOLKIT="/absolute/path/outside/git/guard-joint-probe-II-toolkit"

node "$TASK/tools/materialize-toolkit.cjs" \
  --repo "$REFACTOR_REPO" \
  --out "$TOOLKIT"

node "$TASK/tools/verify-toolkit.cjs" \
  --kit "$TOOLKIT"
```

materializer 从固定 Git tree 取 25 个历史基底文件，再覆盖本包完整实现。必须严格得到：

```text
GUARD_JOINT_PROBE_COMPLETE_IMPLEMENTATION_VERIFIED
  tests=72
  pass=72
  fail=0
```

其中历史基底 16 项、本轮完整实现 56 项。失败时停止，禁止 Agent 改代码。

---

## 5. 一次 25 分钟联合无上传探针

本节不使用 compat detached worktree，不使用 `104e47b…`，不读取正式 profile，也不构建 candidate。

设置全新的 Git 外路径：

```bash
PROBE_EXTERNAL="/absolute/path/outside/git/guard-joint-probe-II-run"
RUN="$PROBE_EXTERNAL/run"
mkdir "$PROBE_EXTERNAL"
```

### 5.1 只读前检并构造专用 session

```bash
node "$TOOLKIT/prepare-control-plane-probe.cjs" \
  --repo "$REFACTOR_REPO" \
  --secret "$SECRET" \
  --run "$RUN" \
  --duration-ms 1500000 \
  --prepare \
  > "$PROBE_EXTERNAL/prepare.stdout" \
  2> "$PROBE_EXTERNAL/prepare.stderr"
```

必须取得 `CONTROL_PLANE_PROBE_SESSION_PREPARED`。此时 `$RUN` 中只能有摘要与 probe session；不得出现 `session.json`、`backup.json`、`candidate.json` 或 `upload-attempt.json`。

### 5.2 启动专用 collector

```bash
(
  set +e
  node "$TOOLKIT/probe-console-collector.cjs" \
    --repo "$REFACTOR_REPO" \
    --secret "$SECRET" \
    --run "$RUN" \
    > "$RUN/collector.stdout" \
    2> "$RUN/collector.stderr"
  COLLECTOR_EXIT=$?
  printf '%s\n' "$COLLECTOR_EXIT" > "$RUN/collector.exit.txt"
  exit 0
) &
COLLECTOR_SHELL_PID=$!

node "$TOOLKIT/wait-probe-collector-ready.cjs" \
  --run "$RUN" \
  --timeout-ms 30000 \
  --wait \
  > "$RUN/collector-ready.stdout" \
  2> "$RUN/collector-ready.stderr"
```

必须取得 `PROBE_COLLECTOR_READY`，且 console/CPU 两通道均新鲜。不得重启 collector。

### 5.3 运行 Guard probe

```bash
set +e
node "$TOOLKIT/guard-probe.cjs" \
  --repo "$REFACTOR_REPO" \
  --secret "$SECRET" \
  --run "$RUN" \
  --probe \
  > "$RUN/guard-probe.stdout" \
  2> "$RUN/guard-probe.stderr"
GUARD_EXIT=$?
printf '%s\n' "$GUARD_EXIT" > "$RUN/guard-probe.exit.txt"
wait "$COLLECTOR_SHELL_PID"
set -e
```

正式探针必须是同一 runId、同一 collector PID 的连续 25 分钟。禁止重启、重连拼接或二次探针。

### 5.4 无论 Guard 成败都执行只读后检

```bash
node "$TOOLKIT/postflight-control-plane-probe.cjs" \
  --repo "$REFACTOR_REPO" \
  --secret "$SECRET" \
  --run "$RUN" \
  --postflight \
  > "$RUN/postflight.stdout" \
  2> "$RUN/postflight.stderr"
```

后检必须得到 `PROBE_ONLINE_STATE_UNCHANGED`。它只比较账号、活动分支、BUILD_COMMIT、模块摘要和单调 tick；不写 Screeps。

### 5.5 独立验证与秘密扫描

```bash
node "$TOOLKIT/verify-joint-probe.cjs" \
  --run "$RUN" \
  --out "$RUN/joint-probe-verification.json" \
  --verify

node "$TASK/tools/scan-probe-evidence.cjs" \
  --root "$PROBE_EXTERNAL" \
  --secret "$SECRET" \
  --out "$PROBE_EXTERNAL/secret-scan.json"
```

成功必须同时满足：

- 连续时长 `>=1500000ms`；
- 成功 tick 读取 `>=98`；
- 完整失败周期最多 1，结束时连续失败为 0；
- tick 不回退；
- collector PID/runId 全程不变；
- 约每 5 秒一条联合 heartbeat 证据，console/CPU 始终在 45 秒新鲜度内；
- collector 恰好一个 footer，`probe_complete`，exit 0；
- `upload-attempt.json` 从未出现；
- 无 formal session、backup/candidate、closing、restore 或 formal guard 产物；
- `codeWriteRequests=0`；
- before/after 线上 BUILD_COMMIT 与模块摘要完全一致；
- 秘密扫描 CLEAN。

任一失败时不得重复探针，只保存本次原件。

---

## 6. 归档与提交

新建且只使用：

```text
openspec/changes/empire-treasury-core-rewrite/evidence/legacy-read-bridge-i/
online-observation-0002-guard-joint-probe-ii/
```

归档：

- 本任务包 ZIP、SHA-256、`IMPLEMENTATION-MANIFEST.json`；
- 第 3–4 节全部 stdout/stderr/TAP/exit；
- `IMPLEMENTATION-APPLIED.json`；
- `$PROBE_EXTERNAL` 中的 probe session、前后摘要、collector/Guard 原始证据、独立验证和秘密扫描；
- 执行报告。

禁止归档：

- `.secret.json`、token 或 token 前缀；
- 完整线上模块正文；
- 任一 backup/candidate；
- 全量 Memory；
- 未脱敏 HTTP body/header；
- 全机器进程命令行。

提交前确认 staged path 全部位于上述新 evidence 目录。只允许 refactor 分支新增一个 evidence 提交；compat 零变化。推送后报告新 SHA。

---

## 7. 终态标签

全部通过：

```text
GUARD_JOINT_PROBE_COMPLETE_IMPLEMENTATION_VERIFIED
PROBE_SESSION_DECOUPLED_FROM_FORMAL_PROFILE
GUARD_COLLECTOR_CONTROL_PLANE_PROBE_VERIFIED
NOT_DEPLOYED
```

探针未启动：

```text
GUARD_JOINT_PROBE_COMPLETE_IMPLEMENTATION_VERIFIED
JOINT_PROBE_NOT_STARTED
NOT_DEPLOYED
```

探针启动后失败：

```text
GUARD_JOINT_PROBE_COMPLETE_IMPLEMENTATION_VERIFIED
GUARD_COLLECTOR_CONTROL_PLANE_PROBE_FAILED
NOT_DEPLOYED
```

任何结果都不得写成：

```text
ONLINE_COMPAT_READ_OBSERVED
TREASURY_PRODUCTION_READY
DEPLOYED
```
