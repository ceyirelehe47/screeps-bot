'use strict';
const test=require('node:test');const assert=require('node:assert/strict');
const fs=require('node:fs');const os=require('node:os');const path=require('node:path');
const C=require('../common.cjs');const S=require('../probe-session.cjs');

function baseline(tick=90000000,at=1000){return {
  kind:S.BASELINE_KIND,capturedAtMs:at,...C.EXPECTED,observedTick:tick,
  build:{commit:C.PRODUCTION_BASE,tree:C.PRODUCTION_TREE,dirty:'folded_out',deployBranch:C.EXPECTED.branch,
    tag:'2026.8.29-6+06ffedb@test'},digest:C.clone(C.ORIGINAL_DIGEST),moduleBodiesPersisted:false,
};}

test('dedicated probe session is wall-clock bounded and contains no formal rollout fields',()=>{
  const session=S.createProbeSession({baseline:baseline(),durationMs:1500000,preparedAtMs:2000,runId:'a'.repeat(32)});
  assert.equal(session.kind,S.SESSION_KIND);
  assert.equal(session.durationMs,1500000);
  assert.equal(session.wallLimitMs,1680000);
  assert.equal(session.formalProfileUsed,false);
  for(const key of ['profile','candidate','backup','dueTicks','startTick','endTick'])assert.equal(key in session,false);
  assert.equal(S.validateProbeSession(session,{now:session.startDeadlineAtMs,forStart:true}),session);
});

test('session validity does not depend on whether its observed game tick is in the past or future relative to later live ticks',()=>{
  const session=S.createProbeSession({baseline:baseline(1),durationMs:1500000,preparedAtMs:5000,runId:'b'.repeat(32)});
  assert.doesNotThrow(()=>S.validateProbeSession(session,{now:6000,forStart:true}));
  assert.equal(session.baseline.observedTick,1);
  assert.equal('requiredStartTickMinimum' in session,false);
});

test('probe session refuses injected formal profile or snapshot fields',()=>{
  const session=S.createProbeSession({baseline:baseline(),durationMs:1500000,preparedAtMs:2000,runId:'c'.repeat(32)});
  for(const [key,value] of [['profile',{}],['candidate',{}],['backup',{}],['startTick',1],['endTick',2]])
    assert.throws(()=>S.validateProbeSession({...session,[key]:value}));
});

test('probe session has a bounded start grace but remains readable after the 25-minute probe for postflight',()=>{
  const session=S.createProbeSession({baseline:baseline(),durationMs:1500000,preparedAtMs:10000,runId:'d'.repeat(32)});
  assert.throws(()=>S.validateProbeSession(session,{now:session.startDeadlineAtMs+1,forStart:true}),
    error=>error.code==='PROBE_SESSION_START_EXPIRED');
  assert.doesNotThrow(()=>S.validateProbeSession(session,{now:session.startDeadlineAtMs+2000000,forStart:false}));
});

test('baseline comparison requires identical build/digest and a non-regressing live tick',()=>{
  const before=baseline(100,1000),after=baseline(200,2000);
  assert.equal(S.compareBaselines(before,after).status,'PROBE_ONLINE_STATE_UNCHANGED');
  assert.throws(()=>S.compareBaselines(before,{...after,observedTick:99}),error=>error.code==='PROBE_ONLINE_TICK_REGRESSED');
  assert.throws(()=>S.compareBaselines(before,{...after,digest:{...after.digest,hash:'0'.repeat(64)}}));
});

test('prepared run persists summaries only and never creates backup/candidate/formal session files',()=>{
  const parent=fs.mkdtempSync(path.join(os.tmpdir(),'probe-session-')),run=path.join(parent,'run');
  try{
    const session=S.createProbeSession({baseline:baseline(),durationMs:1500000,preparedAtMs:2000,runId:'e'.repeat(32)});
    S.writePreparedRun(run,session);
    assert.deepEqual(fs.readdirSync(run).sort(),['preflight-before.json','probe-prepared.json','probe-session.json']);
    const persisted=JSON.parse(fs.readFileSync(path.join(run,'probe-session.json'),'utf8'));
    assert.equal(persisted.baseline.moduleBodiesPersisted,false);
    assert.equal('modules' in persisted.baseline,false);
  }finally{fs.rmSync(parent,{recursive:true,force:true});}
});

test('probe session source has no absolute profile tick gate and baseline reader returns summaries only',()=>{
  const source=fs.readFileSync(path.resolve(__dirname,'..','probe-session.cjs'),'utf8');
  assert.equal(source.includes('requiredStartTickMinimum'),false);
  assert.equal(source.includes('cfg.startTick'),false);
  assert.match(source,/moduleBodiesPersisted:false/);
  assert.match(source,/ONLINE_BASELINE_BYTES_CHANGED/);
});
