#!/usr/bin/env node
'use strict';
const fs=require('node:fs');const path=require('node:path');const cp=require('node:child_process');const crypto=require('node:crypto');
const ROOT=path.resolve(__dirname,'..'),KIT=path.join(ROOT,'implementation','toolkit-overlay');
const TESTS=Object.freeze(['tests/check-profile-errors.spec.cjs','tests/common-atomic.spec.cjs','tests/guard-control.spec.cjs',
  'tests/guard-probe.spec.cjs','tests/probe-baseline-reader.spec.cjs','tests/probe-collector-process.spec.cjs',
  'tests/probe-session.spec.cjs','tests/probe-watch.spec.cjs','tests/read-only-client.spec.cjs',
  'tests/verify-joint-probe.spec.cjs','tests/wait-ready.spec.cjs']);
const EXPECTED=56;
function fail(code,details={}){const e=new Error(code);e.code=code;e.details=details;throw e;}
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
function main(){const manifest=JSON.parse(fs.readFileSync(path.join(ROOT,'IMPLEMENTATION-MANIFEST.json'),'utf8'));
  for(const file of manifest.toolkitOverlay){const target=path.join(KIT,file.path);if(!fs.existsSync(target)||sha(fs.readFileSync(target))!==file.sha256)
    fail('IMPLEMENTATION_BYTES_MISMATCH',{path:file.path});cp.execFileSync(process.execPath,['--check',target],{stdio:'ignore'});}
  const result=cp.spawnSync(process.execPath,['--test',...TESTS.map(x=>path.join(KIT,x))],{encoding:'utf8',maxBuffer:32*1024*1024});
  if(result.status!==0)fail('IMPLEMENTATION_TESTS_FAILED',{status:result.status,stdoutBytes:Buffer.byteLength(result.stdout||''),stderrBytes:Buffer.byteLength(result.stderr||'')});
  const total=result.stdout.match(/# tests (\d+)/),passed=result.stdout.match(/# pass (\d+)/),failed=result.stdout.match(/# fail (\d+)/);
  if(!total||!passed||!failed||Number(total[1])!==EXPECTED||total[1]!==passed[1]||failed[1]!=='0')
    fail('IMPLEMENTATION_TEST_COUNT_INVALID',{expected:EXPECTED,tests:total?Number(total[1]):null});
  console.log(JSON.stringify({status:'GUARD_JOINT_PROBE_IMPLEMENTATION_TESTS_VERIFIED',tests:EXPECTED,passed:EXPECTED,failed:0,testFiles:TESTS.length}));}
try{main();}catch(error){process.stderr.write(JSON.stringify({error:error.code||String(error.message||'IMPLEMENTATION_VERIFY_FAILED'),details:error.details||{}})+'\n');process.exitCode=1;}
