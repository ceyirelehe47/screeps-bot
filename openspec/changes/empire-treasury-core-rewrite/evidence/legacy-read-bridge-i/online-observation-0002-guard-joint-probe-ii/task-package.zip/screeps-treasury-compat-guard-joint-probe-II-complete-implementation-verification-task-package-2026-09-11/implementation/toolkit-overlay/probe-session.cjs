'use strict';

const fs=require('node:fs');
const path=require('node:path');
const crypto=require('node:crypto');
const {performance}=require('node:perf_hooks');
const C=require('./common.cjs');
const G=require('./guard-control.cjs');

const BASELINE_KIND='guard-control-plane-probe-baseline/v2';
const SESSION_KIND='guard-control-plane-probe-session/v2';
const MIN_DURATION_MS=1200000;
const MAX_DURATION_MS=1800000;
const SESSION_START_GRACE_MS=5*60*1000;
const SESSION_WALL_MARGIN_MS=3*60*1000;
const PROBE_POLICY=Object.freeze({
  timeIntervalMs:15000,
  startupGraceMs:15000,
  channelSilenceMs:45000,
  minimumSuccessfulReadsFor25m:98,
  maximumTotalFailedCycles:1,
  requiredFinalConsecutiveFailedCycles:0,
});
const RETRYABLE_BASELINE_CODES=new Set([
  'HTTP_TRANSPORT_ERROR','HTTP_DEADLINE','HTTP_BODY_ABORTED','HTTP_BODY_ERROR',
  'HTTP_JSON_INVALID','HTTP_REQUEST_FAILED','OPERATION_DEADLINE',
]);

function same(left,right){return JSON.stringify(left)===JSON.stringify(right);}
function stableCode(error){return G.stableErrorCode(error);}
function randomRunId(){return crypto.randomBytes(16).toString('hex');}

function validateBaseline(value) {
  if(!C.obj(value)||value.kind!==BASELINE_KIND||!Number.isSafeInteger(value.capturedAtMs)||value.capturedAtMs<0
    ||value.server!==C.EXPECTED.server||value.username!==C.EXPECTED.username||value.userId!==C.EXPECTED.userId
    ||value.branch!==C.EXPECTED.branch||value.shard!==C.EXPECTED.shard
    ||!Number.isSafeInteger(value.observedTick)||value.observedTick<0||value.moduleBodiesPersisted!==false
    ||C.own(value,'modules'))C.fail('PROBE_BASELINE_INVALID');
  if(!C.obj(value.build)||value.build.commit!==C.PRODUCTION_BASE||value.build.tree!==C.PRODUCTION_TREE
    ||value.build.deployBranch!==C.EXPECTED.branch||!['false','folded_out'].includes(value.build.dirty)
    ||typeof value.build.tag!=='string'||!value.build.tag.length)C.fail('PROBE_BASELINE_BUILD_INVALID');
  if(!same(value.digest,C.ORIGINAL_DIGEST))C.fail('PROBE_BASELINE_DIGEST_INVALID');
  return value;
}

async function readOnlineBaselineOnce({api,guard,budgetMs=30000,now=Date.now,clock=()=>performance.now()}) {
  const P=require('./protocol.cjs');
  const R=require('./read-only-client.cjs');
  R.assertReadOnlySurface(api);
  if(!guard||typeof guard.computeModulesHash!=='function'||typeof guard.diffRemoteModules!=='function')
    C.fail('PROBE_GUARD_INVALID');
  if(!Number.isSafeInteger(budgetMs)||budgetMs<5000||budgetMs>60000)C.fail('PROBE_BASELINE_BUDGET_INVALID');
  const deadline=clock()+budgetMs;
  P.account(await api.me(C.remaining(deadline,clock)));
  const branch=P.activeBranch(await api.branches(C.remaining(deadline,clock)));
  const modules=P.modulesFromResponse(await api.code(branch,C.remaining(deadline,clock)));
  P.activeBranch(await api.branches(C.remaining(deadline,clock)),branch);
  const digest=P.describeModules(modules,guard);
  if(!same(digest,C.ORIGINAL_DIGEST))C.fail('ONLINE_BASELINE_BYTES_CHANGED');
  const build=P.buildIdentity(modules.main);
  if(build.commit!==C.PRODUCTION_BASE||build.tree!==C.PRODUCTION_TREE||build.deployBranch!==C.EXPECTED.branch
    ||!['false','folded_out'].includes(build.dirty))C.fail('ONLINE_BASELINE_CHANGED');
  const tick=await api.time(C.EXPECTED.shard,C.remaining(deadline,clock));
  if(!C.obj(tick)||tick.ok!==1||!Number.isSafeInteger(tick.time)||tick.time<0)C.fail('GAME_TICK_UNREADABLE');
  P.activeBranch(await api.branches(C.remaining(deadline,clock)),branch);
  return validateBaseline({
    kind:BASELINE_KIND,
    capturedAtMs:now(),
    ...C.EXPECTED,
    observedTick:tick.time,
    build,
    digest,
    moduleBodiesPersisted:false,
  });
}

async function readOnlineBaselineResilient({api,guard,budgetMs=30000,attempts=3,retryDelaysMs=[1000,3000],
  now=Date.now,clock=()=>performance.now(),pause=C.pause,record=()=>{},redact=C.redactor()}) {
  if(!Number.isSafeInteger(attempts)||attempts<1||attempts>4||!Array.isArray(retryDelaysMs)
    ||retryDelaysMs.length!==attempts-1||retryDelaysMs.some(x=>!Number.isSafeInteger(x)||x<0||x>10000))
    C.fail('PROBE_BASELINE_RETRY_POLICY_INVALID');
  let lastError;
  for(let attempt=1;attempt<=attempts;attempt++) {
    try {
      const baseline=await readOnlineBaselineOnce({api,guard,budgetMs,now,clock});
      record({kind:'probe-baseline-read-success',attempt,observedTick:baseline.observedTick,
        digestHash:baseline.digest.hash,capturedAtMs:baseline.capturedAtMs});
      return baseline;
    } catch(error) {
      lastError=error;
      const code=stableCode(error);
      record({kind:'probe-baseline-read-failure',attempt,code,
        diagnostic:G.safeGuardDiagnostic('game_time_read',error,redact)});
      if(!RETRYABLE_BASELINE_CODES.has(code)||attempt===attempts)break;
      await pause(retryDelaysMs[attempt-1]);
    }
  }
  if(lastError instanceof C.Failure)throw lastError;
  C.fail('PROBE_BASELINE_READ_FAILED',{lastCode:stableCode(lastError)});
}

function createProbeSession({baseline,durationMs,preparedAtMs=Date.now(),runId=randomRunId()}) {
  validateBaseline(baseline);
  C.integer(durationMs,MIN_DURATION_MS,MAX_DURATION_MS,'PROBE_DURATION_INVALID');
  C.integer(preparedAtMs,0,Number.MAX_SAFE_INTEGER,'PROBE_PREPARED_AT_INVALID');
  if(typeof runId!=='string'||!/^[a-f0-9]{32}$/.test(runId))C.fail('PROBE_RUN_ID_INVALID');
  return validateProbeSession({
    kind:SESSION_KIND,
    runId,
    preparedAtMs,
    startDeadlineAtMs:preparedAtMs+SESSION_START_GRACE_MS,
    durationMs,
    wallLimitMs:durationMs+SESSION_WALL_MARGIN_MS,
    ...C.EXPECTED,
    baseline:C.clone(baseline),
    policy:{...PROBE_POLICY},
    formalProfileUsed:false,
    candidateSnapshotUsed:false,
    backupSnapshotPersisted:false,
    onlineWriteAuthorized:false,
  },{now:preparedAtMs,forStart:false});
}

function validateProbeSession(value,{now=Date.now(),forStart=false}={}) {
  if(!C.obj(value)||value.kind!==SESSION_KIND||typeof value.runId!=='string'||!/^[a-f0-9]{32}$/.test(value.runId)
    ||!Number.isSafeInteger(value.preparedAtMs)||value.preparedAtMs<0
    ||value.startDeadlineAtMs!==value.preparedAtMs+SESSION_START_GRACE_MS
    ||!Number.isSafeInteger(value.durationMs)||value.durationMs<MIN_DURATION_MS||value.durationMs>MAX_DURATION_MS
    ||value.wallLimitMs!==value.durationMs+SESSION_WALL_MARGIN_MS
    ||value.server!==C.EXPECTED.server||value.username!==C.EXPECTED.username||value.userId!==C.EXPECTED.userId
    ||value.branch!==C.EXPECTED.branch||value.shard!==C.EXPECTED.shard
    ||!same(value.policy,PROBE_POLICY)||value.formalProfileUsed!==false||value.candidateSnapshotUsed!==false
    ||value.backupSnapshotPersisted!==false||value.onlineWriteAuthorized!==false)C.fail('PROBE_SESSION_INVALID');
  for(const forbidden of ['profile','candidate','backup','dueTicks','startTick','endTick'])
    if(C.own(value,forbidden))C.fail('PROBE_SESSION_FORMAL_FIELD_FORBIDDEN',{field:forbidden});
  validateBaseline(value.baseline);
  if(forStart) {
    if(!Number.isSafeInteger(now)||now<value.preparedAtMs-1000||now>value.startDeadlineAtMs)
      C.fail('PROBE_SESSION_START_EXPIRED',{preparedAtMs:value.preparedAtMs,startDeadlineAtMs:value.startDeadlineAtMs});
  }
  return value;
}

function loadProbeSession(run,{forStart=false,now=Date.now()}={}) {
  const file=path.join(run,'probe-session.json');
  return validateProbeSession(C.readJson(file,65536),{forStart,now});
}

function compareBaselines(before,after) {
  validateBaseline(before);validateBaseline(after);
  if(before.server!==after.server||before.username!==after.username||before.userId!==after.userId
    ||before.branch!==after.branch||before.shard!==after.shard)C.fail('PROBE_ONLINE_IDENTITY_CHANGED');
  if(!same(before.digest,after.digest)||!same(before.build,after.build))C.fail('PROBE_ONLINE_CODE_CHANGED');
  if(after.observedTick<before.observedTick)C.fail('PROBE_ONLINE_TICK_REGRESSED');
  return {
    status:'PROBE_ONLINE_STATE_UNCHANGED',
    beforeTick:before.observedTick,
    afterTick:after.observedTick,
    digestHash:after.digest.hash,
    buildCommit:after.build.commit,
  };
}

function writePreparedRun(run,session) {
  if(fs.existsSync(run))C.fail('OUTPUT_ALREADY_EXISTS');
  fs.mkdirSync(run,{recursive:false,mode:0o700});
  C.writeNew(path.join(run,'probe-session.json'),session);
  C.writeNew(path.join(run,'preflight-before.json'),session.baseline);
  C.writeNew(path.join(run,'probe-prepared.json'),{
    status:'CONTROL_PLANE_PROBE_SESSION_PREPARED',runId:session.runId,preparedAtMs:session.preparedAtMs,
    durationMs:session.durationMs,observedTick:session.baseline.observedTick,digestHash:session.baseline.digest.hash,
    formalProfileUsed:false,candidateSnapshotUsed:false,onlineWriteAuthorized:false,
  });
  return session;
}

function writePostflight(run,after) {
  const session=loadProbeSession(run);
  const comparison=compareBaselines(session.baseline,after);
  C.writeNew(path.join(run,'preflight-after.json'),after);
  C.writeNew(path.join(run,'online-state-verification.json'),comparison);
  return comparison;
}

module.exports={
  BASELINE_KIND,SESSION_KIND,MIN_DURATION_MS,MAX_DURATION_MS,SESSION_START_GRACE_MS,
  SESSION_WALL_MARGIN_MS,PROBE_POLICY,validateBaseline,readOnlineBaselineOnce,readOnlineBaselineResilient,
  createProbeSession,validateProbeSession,loadProbeSession,compareBaselines,writePreparedRun,writePostflight,
};
