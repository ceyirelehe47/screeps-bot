'use strict';

const C=require('./common.cjs');
const READ_METHODS=Object.freeze(['me','branches','code','time']);

function createReadOnlyClient(secret,options,clientFactory) {
  const factory=clientFactory||require('./transport.cjs').client;
  if(typeof factory!=='function')C.fail('READ_ONLY_TRANSPORT_SURFACE_INVALID');
  const base=factory(secret,options);
  const out={};
  for(const name of READ_METHODS) {
    if(typeof base[name]!=='function')C.fail('READ_ONLY_TRANSPORT_SURFACE_INVALID',{method:name});
    out[name]=(...args)=>base[name](...args);
  }
  return Object.freeze(out);
}

function assertReadOnlySurface(value) {
  if(!value||typeof value!=='object')C.fail('READ_ONLY_TRANSPORT_SURFACE_INVALID');
  const keys=Object.keys(value).sort();
  const expected=[...READ_METHODS].sort();
  if(JSON.stringify(keys)!==JSON.stringify(expected))C.fail('READ_ONLY_TRANSPORT_SURFACE_INVALID',{keys});
  for(const name of READ_METHODS)if(typeof value[name]!=='function')C.fail('READ_ONLY_TRANSPORT_SURFACE_INVALID',{method:name});
  for(const forbidden of ['setCode','queryToken','overview','upload','restore','deal','console']) {
    if(forbidden in value)C.fail('READ_ONLY_TRANSPORT_WRITE_SURFACE_EXPOSED',{method:forbidden});
  }
  return true;
}

module.exports={READ_METHODS,createReadOnlyClient,assertReadOnlySurface};
