'use strict';
const test=require('node:test');const assert=require('node:assert/strict');const Module=require('node:module');
const C=require('../common.cjs');const S=require('../probe-session.cjs');
const originalLoad=Module._load;
const fakeProtocol={
  account:value=>value,
  activeBranch:(value,expected=C.EXPECTED.branch)=>{assert.equal(value.ok,1);return expected;},
  modulesFromResponse:value=>value.modules,
  describeModules:()=>C.clone(C.ORIGINAL_DIGEST),
  buildIdentity:()=>({commit:C.PRODUCTION_BASE,tree:C.PRODUCTION_TREE,dirty:'folded_out',deployBranch:C.EXPECTED.branch,tag:'tag'}),
};
function withProtocol(fn){Module._load=function(request,parent,isMain){if(request==='./protocol.cjs'&&parent?.filename?.endsWith('probe-session.cjs'))return fakeProtocol;return originalLoad.apply(this,arguments);};
  return Promise.resolve().then(fn).finally(()=>{Module._load=originalLoad;});}
function api(overrides={}){return Object.freeze({
  me:async()=>({ok:1}),branches:async()=>({ok:1}),code:async()=>({ok:1,modules:{main:'x'}}),
  time:async()=>({ok:1,time:123}),...overrides,
});}
const guard={computeModulesHash(){},diffRemoteModules(){}};

test('online baseline reader persists identity/digest/tick summary but not module bodies',()=>withProtocol(async()=>{
  const value=await S.readOnlineBaselineOnce({api:api(),guard,budgetMs:5000,now:()=>1000});
  assert.equal(value.kind,S.BASELINE_KIND);assert.equal(value.observedTick,123);assert.equal(value.moduleBodiesPersisted,false);
  assert.equal('modules' in value,false);assert.deepEqual(value.digest,C.ORIGINAL_DIGEST);
}));

test('online baseline reader retries a bounded transport failure and records only stable diagnostics',()=>withProtocol(async()=>{
  let attempts=0;const records=[];
  const value=await S.readOnlineBaselineResilient({api:api({me:async()=>{attempts++;if(attempts===1)throw new C.Failure('HTTP_TRANSPORT_ERROR');return {ok:1};}}),
    guard,budgetMs:5000,pause:async()=>{},record:r=>records.push(r),redact:C.redactor()});
  assert.equal(value.observedTick,123);assert.equal(attempts,2);
  assert.equal(records[0].kind,'probe-baseline-read-failure');assert.equal(records[0].code,'HTTP_TRANSPORT_ERROR');
  assert.equal(records.some(r=>r.kind==='probe-baseline-read-success'),true);
}));
