'use strict';
const Module=require('node:module');const path=require('node:path');
const common=require(path.resolve(__dirname,'..','common.cjs'));
const originalLoad=Module._load;
const runId='a'.repeat(32),userId='u1',shard='shard1',token='TEST_SECRET_TOKEN_123456789';
const session={kind:'guard-control-plane-probe-session/v2',runId,userId,shard,durationMs:1500000,
  wallLimitMs:1680000};
const fakeCommon={...common,loadSecret:()=>({token,server:'https://screeps.com',redact:common.redactor([token])}),
  loadGuard:()=>({}),git:(_repo,args)=>args[0]==='rev-parse'?common.PROBE_REFACTOR_BASE:''};
Module._load=function(request,parent,isMain){
  if(parent&&parent.filename&&parent.filename.endsWith('probe-console-collector.cjs')){
    if(request==='./common.cjs')return fakeCommon;
    if(request==='./protocol.cjs')return {account:()=>({})};
    if(request==='./read-only-client.cjs')return {createReadOnlyClient:()=>({me:async()=>({ok:1,_id:userId,username:'forster'}),
      branches(){},code(){},time(){}}),assertReadOnlySurface:()=>true};
    if(request==='./probe-session.cjs')return {loadProbeSession:()=>session};
  }
  return originalLoad.apply(this,arguments);
};
class FakeWebSocket {
  constructor(){this.listeners=new Map();this.subscriptions=0;setImmediate(()=>this.emit('open',{}));}
  addEventListener(name,fn){if(!this.listeners.has(name))this.listeners.set(name,[]);this.listeners.get(name).push(fn);}
  emit(name,event){for(const fn of this.listeners.get(name)||[])fn(event);}
  send(text){
    if(text.startsWith('auth ')){setImmediate(()=>this.emit('message',{data:'auth ok'}));return;}
    if(text.startsWith('subscribe ')){
      this.subscriptions++;const channel=text.slice('subscribe '.length);
      if(channel.endsWith('/console'))setImmediate(()=>this.emit('message',{data:JSON.stringify([channel,{shard,messages:{log:[],results:[]}}])}));
      else if(channel.endsWith('/cpu'))setImmediate(()=>this.emit('message',{data:JSON.stringify([channel,{cpu:12.5}])}));
      if(this.subscriptions===2)this.scheduleTerminal();
    }
  }
  scheduleTerminal(){
    const mode=process.env.FAKE_PROBE_WS_MODE||'stop';
    if(mode==='close')setTimeout(()=>this.emit('close',{code:1006,reason:`lost token=${token}`,wasClean:false}),100);
    if(mode==='error')setTimeout(()=>{const error=new Error(`socket failed token=${token}`);error.code='ECONNRESET';
      this.emit('error',{type:'error',error});},100);
  }
  close(){this.closed=true;}
}
global.WebSocket=FakeWebSocket;
