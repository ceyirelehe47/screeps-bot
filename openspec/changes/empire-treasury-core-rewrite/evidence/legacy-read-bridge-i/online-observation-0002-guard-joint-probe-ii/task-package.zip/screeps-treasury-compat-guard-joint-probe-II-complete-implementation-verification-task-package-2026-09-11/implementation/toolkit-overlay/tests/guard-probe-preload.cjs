'use strict';
const Module=require('node:module');const fs=require('node:fs');const path=require('node:path');
const common=require(path.resolve(__dirname,'..','common.cjs'));const originalLoad=Module._load;
const run=process.env.FAKE_GUARD_PROBE_RUN,runId='a'.repeat(32),collectorPid=4242;
const SESSION_KIND='guard-control-plane-probe-session/v2';
const policy={timeIntervalMs:500,startupGraceMs:15000,channelSilenceMs:45000,
  minimumSuccessfulReadsFor25m:98,maximumTotalFailedCycles:1,requiredFinalConsecutiveFailedCycles:0};
const session={kind:SESSION_KIND,runId,durationMs:1000,wallLimitMs:181000,userId:'u1',shard:'shard1',policy};
const fakeCommon={...common,loadSecret:()=>({token:'TEST_SECRET_TOKEN_123456789',server:'https://screeps.com',
  redact:common.redactor(['TEST_SECRET_TOKEN_123456789'])}),git:(_repo,args)=>args[0]==='rev-parse'?common.PROBE_REFACTOR_BASE:''};
let tick=5000;
const fakeReadonly={createReadOnlyClient:()=>({me:async()=>({ok:1}),branches:async()=>({ok:1}),code:async()=>({ok:1}),
  time:async()=>({ok:1,time:tick++})}),assertReadOnlySurface:()=>true};
const fakeSession={SESSION_KIND,PROBE_POLICY:policy,loadProbeSession:()=>session};
Module._load=function(request,parent,isMain){
  if(parent&&parent.filename&&parent.filename.endsWith('guard-probe.cjs')){
    if(request==='./common.cjs')return fakeCommon;
    if(request==='./probe-session.cjs')return fakeSession;
    if(request==='./read-only-client.cjs')return fakeReadonly;
  }
  return originalLoad.apply(this,arguments);
};
function write(file,value){fs.writeFileSync(path.join(run,file),JSON.stringify(value,null,2)+'\n');}
const timer=setInterval(()=>{
  const now=Date.now(),stop=path.join(run,'collector-stop.json'),result=path.join(run,'collector-result.json');
  if(!fs.existsSync(stop)){
    write('heartbeat.json',{sessionKind:SESSION_KIND,runId,userId:'u1',shard:'shard1',pid:collectorPid,
      state:'streaming',socketState:'open',updatedAtMs:now,lastConsoleAtMs:now,lastCpuAtMs:now,
      stopReason:null,unexpectedBridgeReports:0});
  }else if(!fs.existsSync(result)){
    const request=JSON.parse(fs.readFileSync(stop,'utf8'));
    write('collector-result.json',{kind:'collector-result-v2',sessionKind:SESSION_KIND,runId,pid:collectorPid,
      status:'closed',reason:request.reason,exitCode:0,closedAtMs:now,footerWritten:true,lockRemoved:true});
  }
},10);timer.unref();
