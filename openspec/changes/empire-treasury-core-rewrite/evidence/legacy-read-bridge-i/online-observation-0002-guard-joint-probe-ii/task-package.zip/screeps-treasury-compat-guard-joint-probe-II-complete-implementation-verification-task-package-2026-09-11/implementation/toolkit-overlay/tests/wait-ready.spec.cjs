'use strict';
const test=require('node:test');const assert=require('node:assert/strict');
const fs=require('node:fs');const os=require('node:os');const path=require('node:path');
const C=require('../common.cjs');const S=require('../probe-session.cjs');const W=require('../wait-probe-collector-ready.cjs');
function baseline(){return {kind:S.BASELINE_KIND,capturedAtMs:1000,...C.EXPECTED,observedTick:1,
  build:{commit:C.PRODUCTION_BASE,tree:C.PRODUCTION_TREE,dirty:'folded_out',deployBranch:C.EXPECTED.branch,tag:'x'},
  digest:C.clone(C.ORIGINAL_DIGEST),moduleBodiesPersisted:false};}
function makeRun(){const parent=fs.mkdtempSync(path.join(os.tmpdir(),'probe-ready-')),run=path.join(parent,'run');
  const session=S.createProbeSession({baseline:baseline(),durationMs:1500000,preparedAtMs:1000,runId:'a'.repeat(32)});
  S.writePreparedRun(run,session);return {parent,run,session};}

test('ready waiter requires matching lock/pid plus fresh console and cpu channels',async()=>{
  const x=makeRun();try{
    const hb={sessionKind:S.SESSION_KIND,runId:x.session.runId,userId:x.session.userId,shard:x.session.shard,
      pid:42,state:'streaming',socketState:'open',lastConsoleAtMs:1999,lastCpuAtMs:1998};
    fs.writeFileSync(path.join(x.run,'heartbeat.json'),JSON.stringify(hb));
    fs.writeFileSync(path.join(x.run,'collector.lock'),JSON.stringify({runId:x.session.runId,pid:42}));
    const result=await W.waitReady(x.run,{timeoutMs:1000,now:()=>2000});
    assert.equal(result.status,'PROBE_COLLECTOR_READY');assert.equal(result.pid,42);
  }finally{fs.rmSync(x.parent,{recursive:true,force:true});}
});

test('ready waiter refuses any upload attempt artifact before the probe starts',async()=>{
  const x=makeRun();try{
    fs.writeFileSync(path.join(x.run,'upload-attempt.json'),'{}');
    await assert.rejects(()=>W.waitReady(x.run,{timeoutMs:1000,now:()=>2000}),error=>error.code==='PROBE_UPLOAD_ATTEMPT_PRESENT');
  }finally{fs.rmSync(x.parent,{recursive:true,force:true});}
});

test('ready waiter does not accept a stale channel merely because heartbeat state says streaming',async()=>{
  const x=makeRun();let clock=0;try{
    const hb={sessionKind:S.SESSION_KIND,runId:x.session.runId,userId:x.session.userId,shard:x.session.shard,
      pid:42,state:'streaming',socketState:'open',lastConsoleAtMs:1,lastCpuAtMs:1};
    fs.writeFileSync(path.join(x.run,'heartbeat.json'),JSON.stringify(hb));
    fs.writeFileSync(path.join(x.run,'collector.lock'),JSON.stringify({runId:x.session.runId,pid:42}));
    await assert.rejects(()=>W.waitReady(x.run,{timeoutMs:1000,now:()=>20000,clock:()=>clock,
      pause:async ms=>{clock+=ms;}}),error=>error.code==='PROBE_COLLECTOR_READY_TIMEOUT');
  }finally{fs.rmSync(x.parent,{recursive:true,force:true});}
});
