#!/usr/bin/env node
'use strict';
const fs=require('node:fs');const path=require('node:path');const cp=require('node:child_process');const crypto=require('node:crypto');
const ROOT=path.resolve(__dirname,'..');
const BASE_TESTS=Object.freeze(['tests/collector-process.spec.cjs','tests/diagnostics-watch.spec.cjs',
  'tests/probe-verifier.spec.cjs','tests/session-classification.spec.cjs']);
const IMPLEMENTATION_TESTS=Object.freeze(['tests/check-profile-errors.spec.cjs','tests/common-atomic.spec.cjs',
  'tests/guard-control.spec.cjs','tests/guard-probe.spec.cjs','tests/probe-baseline-reader.spec.cjs',
  'tests/probe-collector-process.spec.cjs','tests/probe-session.spec.cjs','tests/probe-watch.spec.cjs',
  'tests/read-only-client.spec.cjs','tests/verify-joint-probe.spec.cjs','tests/wait-ready.spec.cjs']);
const EXPECTED_TESTS=72;
function fail(code,details={}){const e=new Error(code);e.code=code;e.details=details;throw e;}
function arg(argv){const i=argv.indexOf('--kit');if(i<0||!argv[i+1])fail('MISSING_KIT');return path.resolve(argv[i+1]);}
const sha256=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
function main(){const kit=arg(process.argv.slice(2));const manifest=JSON.parse(fs.readFileSync(path.join(ROOT,'IMPLEMENTATION-MANIFEST.json'),'utf8'));
  for(const file of manifest.toolkitOverlay){const target=path.join(kit,file.path);if(!fs.existsSync(target)||sha256(fs.readFileSync(target))!==file.sha256)
    fail('IMPLEMENTATION_BYTES_MISMATCH',{path:file.path});cp.execFileSync(process.execPath,['--check',target],{stdio:'ignore'});}
  const probe=fs.readFileSync(path.join(kit,'guard-probe.cjs'),'utf8'),session=fs.readFileSync(path.join(kit,'probe-session.cjs'),'utf8'),
    collector=fs.readFileSync(path.join(kit,'probe-console-collector.cjs'),'utf8'),readonly=fs.readFileSync(path.join(kit,'read-only-client.cjs'),'utf8');
  if(probe.includes('.setCode(')||probe.includes('restore-modules')||probe.includes("require('./session.cjs')"))fail('PROBE_NOT_DECOUPLED_OR_READ_ONLY');
  if(collector.includes("require('./session.cjs')")||collector.includes('guard-result.json'))fail('PROBE_COLLECTOR_FORMAL_COUPLING_REMAINS');
  if(session.includes('cfg.startTick')||session.includes('requiredStartTickMinimum'))fail('PROBE_ABSOLUTE_TICK_GATE_REMAINS');
  if(!readonly.includes("['me','branches','code','time']"))fail('READ_ONLY_TRANSPORT_CONTRACT_MISSING');
  const tests=[...BASE_TESTS,...IMPLEMENTATION_TESTS].map(relative=>{const target=path.join(kit,relative);if(!fs.existsSync(target)||!fs.statSync(target).isFile())
    fail('TOOLKIT_TEST_MISSING',{path:relative});return target;});
  const result=cp.spawnSync(process.execPath,['--test',...tests],{encoding:'utf8',maxBuffer:32*1024*1024});
  if(result.status!==0)fail('TOOLKIT_TESTS_FAILED',{status:result.status,signal:result.signal||null,
    stdoutBytes:Buffer.byteLength(result.stdout||''),stderrBytes:Buffer.byteLength(result.stderr||'')});
  const total=result.stdout.match(/# tests (\d+)/),passed=result.stdout.match(/# pass (\d+)/),failed=result.stdout.match(/# fail (\d+)/);
  if(!total||!passed||!failed||Number(total[1])!==EXPECTED_TESTS||total[1]!==passed[1]||failed[1]!=='0')
    fail('TOOLKIT_TEST_COUNT_INVALID',{expected:EXPECTED_TESTS,tests:total?Number(total[1]):null,
      passed:passed?Number(passed[1]):null,failed:failed?Number(failed[1]):null});
  console.log(JSON.stringify({status:'GUARD_JOINT_PROBE_COMPLETE_IMPLEMENTATION_VERIFIED',tests:Number(total[1]),
    passed:Number(passed[1]),failed:0,baseTestFiles:BASE_TESTS.length,implementationTestFiles:IMPLEMENTATION_TESTS.length}));}
try{main();}catch(error){process.stderr.write(JSON.stringify({error:error.code||String(error.message||'VERIFY_TOOLKIT_FAILED'),details:error.details||{}})+'\n');process.exitCode=1;}
