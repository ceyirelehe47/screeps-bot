#!/usr/bin/env node
'use strict';

const fs=require('node:fs');
const path=require('node:path');
const C=require('./common.cjs');
const P=require('./protocol.cjs');
const R=require('./read-only-client.cjs');
const S=require('./probe-session.cjs');
const {createProbeWatch}=require('./probe-watch.cjs');
const D=require('./collector-diagnostics.cjs');

async function main(argv) {
  const o=C.options(argv,['repo','secret','run']);C.required(o,'repo','secret','run');
  const repo=path.resolve(o.repo),run=path.resolve(o.run);
  if(C.git(repo,['rev-parse','HEAD'])!==C.PROBE_REFACTOR_BASE)C.fail('PROBE_REFACTOR_BASE_MISMATCH');
  if(C.git(repo,['status','--porcelain']))C.fail('PROBE_REFACTOR_WORKTREE_DIRTY');
  const secret=C.loadSecret(path.resolve(o.secret));
  const session=S.loadProbeSession(run,{forStart:true});
  const api=R.createReadOnlyClient(secret);R.assertReadOnlySurface(api);
  P.account(await api.me());
  if(typeof WebSocket!=='function')C.fail('NODE_22_WEBSOCKET_REQUIRED');
  const file=name=>path.join(run,name),heartbeat=file('heartbeat.json'),raw=file('console.jsonl');
  const privateLog=file('collector-private.jsonl'),lock=file('collector.lock');
  C.writeNew(lock,{runId:session.runId,pid:process.pid,sessionKind:session.kind});
  const watch=createProbeWatch(session,process.pid);
  let bytes=0,closed=false,ws,timer,life,errorCloseTimer,opened=Date.now();
  let footerWritten=false,resultWritten=false,lastSocketError=null;
  const save=()=>C.atomicJson(heartbeat,{...watch.state,updatedAtMs:Date.now(),sessionKind:session.kind});
  const privateRecord=(kind,data={})=>D.auditPrivate(privateLog,{runId:session.runId,pid:process.pid,event:kind,...data},secret.redact);
  const publicDetails=details=>({close:details?.close??null,error:D.publicError(details?.error),diagnosticFile:'collector-private.jsonl'});
  function writeFooter(reason,code,details) {
    C.audit(raw,{kind:'collector-footer',runId:session.runId,pid:process.pid,reason,exitCode:code,
      totalLoggedBytes:bytes,sessionKind:session.kind,...publicDetails(details)},secret.redact);
    footerWritten=true;
  }
  function writeResult(reason,code,details,lockRemoved) {
    C.atomicJson(file('collector-result.json'),{kind:'collector-result-v2',runId:session.runId,pid:process.pid,
      status:code===0?'closed':'failed',reason,exitCode:code,closedAtMs:Date.now(),footerWritten,lockRemoved,
      sessionKind:session.kind,...publicDetails(details)});
    resultWritten=true;
  }
  function emergencyExitFooter(exitCode) {
    if(footerWritten&&resultWritten)return;
    const reason='process_exit_without_finish';
    try {
      if(!footerWritten){C.audit(raw,{kind:'collector-footer',runId:session.runId,pid:process.pid,reason,
        exitCode,totalLoggedBytes:bytes,emergency:true,sessionKind:session.kind},secret.redact);footerWritten=true;}
      if(!resultWritten){C.atomicJson(file('collector-result.json'),{kind:'collector-result-v2',runId:session.runId,
        pid:process.pid,status:'failed',reason,exitCode,closedAtMs:Date.now(),footerWritten,
        lockRemoved:!fs.existsSync(lock),emergency:true,sessionKind:session.kind});resultWritten=true;}
    } catch {/* A hard process or host failure may still prevent synchronous evidence. */}
  }
  function finish(reason,code=1,details={}) {
    if(closed)return;closed=true;clearInterval(timer);clearTimeout(life);clearTimeout(errorCloseTimer);
    const failed=code!==0;watch.terminal(reason,{failed,close:details.close,error:details.error});
    try{save();}catch{code=1;}
    try{privateRecord('finish',{reason,exitCode:code,close:details.close??null,error:details.error??null});}catch{code=1;}
    try{if(ws)ws.close();}catch{}
    let lockRemoved=true;try{fs.unlinkSync(lock);}catch{lockRemoved=false;code=1;}
    try{writeFooter(reason,code,details);}catch{code=1;}
    try{writeResult(reason,code,details,lockRemoved);}catch{code=1;}
    process.exitCode=code;
    setTimeout(()=>process.exit(code),300).unref();
  }
  const fatal=(reason,value)=>finish(reason,1,{error:D.safeError(value,secret.redact)});
  process.once('uncaughtException',error=>fatal('uncaught_exception',error));
  process.once('unhandledRejection',error=>fatal('unhandled_rejection',error));
  process.once('exit',code=>emergencyExitFooter(code));
  try {
    save();privateRecord('probe_collector_start',{sessionKind:session.kind});
    ws=new WebSocket('wss://screeps.com/socket/websocket');
    ws.addEventListener('open',()=>{
      try{watch.opened();privateRecord('socket_open');save();ws.send('auth '+secret.token);}
      catch(error){fatal('socket_open_handler_failure',error);}
    });
    ws.addEventListener('message',event=>{
      try {
        const text=typeof event.data==='string'?event.data:Buffer.from(event.data).toString('utf8');
        const inputBytes=Buffer.byteLength(text);
        if(inputBytes>1024*1024||bytes+inputBytes>64*1024*1024){finish('collector_size_bound');return;}
        const kind=watch.frame(text);
        if(kind==='auth') {
          C.audit(raw,{kind:'auth-confirmed',runId:session.runId,sessionKind:session.kind},secret.redact);
          ws.send(`subscribe user:${session.userId}/console`);
          ws.send(`subscribe user:${session.userId}/cpu`);
        } else {
          const sanitized=secret.redact(text);
          const line=JSON.stringify({kind:'ws-frame',runId:session.runId,receivedAt:new Date().toISOString(),
            bytes:inputBytes,redacted:sanitized!==text,text:sanitized})+'\n';
          fs.appendFileSync(raw,line,{mode:0o600});bytes+=Buffer.byteLength(line);
          if(kind==='auth-failure')finish('authentication_failed');
        }
        if(!closed)save();
      } catch(error){fatal('collector_parse_or_io_failure',error);}
    });
    ws.addEventListener('error',event=>{
      try {
        lastSocketError=D.safeError(event,secret.redact);watch.state.socketState='errored';
        watch.state.updatedAtMs=Date.now();privateRecord('socket_error',{error:lastSocketError});save();
        clearTimeout(errorCloseTimer);
        errorCloseTimer=setTimeout(()=>finish('socket_error_without_close',1,{error:lastSocketError}),2000);
      } catch(error){fatal('socket_error_handler_failure',error);}
    });
    ws.addEventListener('close',event=>finish('socket_closed',1,{close:D.safeClose(event,secret.redact),error:lastSocketError}));
    timer=setInterval(()=>{
      try {
        if(watch.state.state!=='streaming'&&Date.now()-opened>15000){finish('authentication_timeout');return;}
        if(watch.state.stopReason){finish(watch.state.stopReason);return;}
        if(fs.existsSync(file('collector-stop.json'))) {
          const stop=C.readJson(file('collector-stop.json'),16384);
          if(!D.validStopRequest(stop,session.runId)){finish('collector_stop_request_invalid');return;}
          finish(stop.reason,0);return;
        }
        save();
      } catch(error){fatal('heartbeat_io_failure',error);}
    },1000);
    life=setTimeout(()=>finish('collector_lifetime_ended',1),session.wallLimitMs);
    process.once('SIGTERM',()=>finish('operator_stop',0));
    process.once('SIGINT',()=>finish('operator_stop',0));
  } catch(error){fatal('collector_start_failed',error);}
}

module.exports={main};
if(require.main===module)C.entrypoint(()=>main(process.argv.slice(2)));
