#!/usr/bin/env node
'use strict';
const fs=require('node:fs');const path=require('node:path');
const ROOT=path.resolve(__dirname,'..'),KIT=path.join(ROOT,'implementation','toolkit-overlay');
const C=require(path.join(KIT,'common.cjs'));const S=require(path.join(KIT,'probe-session.cjs'));
function fail(code,details={}){const e=new Error(code);e.code=code;e.details=details;throw e;}
function baseline(){return {kind:S.BASELINE_KIND,capturedAtMs:1,...C.EXPECTED,observedTick:999999999,
  build:{commit:C.PRODUCTION_BASE,tree:C.PRODUCTION_TREE,dirty:'folded_out',deployBranch:C.EXPECTED.branch,tag:'maker'},
  digest:C.clone(C.ORIGINAL_DIGEST),moduleBodiesPersisted:false};}
function source(name){return fs.readFileSync(path.join(KIT,name),'utf8');}
function main(){const session=S.createProbeSession({baseline:baseline(),durationMs:1500000,preparedAtMs:1000,runId:'a'.repeat(32)});
  for(const key of ['profile','candidate','backup','dueTicks','startTick','endTick'])if(key in session)fail('FORMAL_FIELD_REMAINS',{key});
  const sessionSource=source('probe-session.cjs'),guard=source('guard-probe.cjs'),collector=source('probe-console-collector.cjs'),
    prepare=source('prepare-control-plane-probe.cjs'),post=source('postflight-control-plane-probe.cjs'),readonly=source('read-only-client.cjs');
  if(sessionSource.includes('cfg.startTick')||sessionSource.includes('requiredStartTickMinimum'))fail('PROBE_ABSOLUTE_TICK_GATE_REMAINS');
  if(guard.includes("require('./session.cjs')")||collector.includes("require('./session.cjs')"))fail('FORMAL_SESSION_IMPORT_REMAINS');
  for(const [name,text] of Object.entries({guard,collector,prepare,post})){
    if(text.includes('.setCode(')||text.includes('upload-once')||text.includes('restore-modules'))fail('PROBE_WRITE_PATH_REMAINS',{name});
    if(text.includes("require('./transport.cjs')")||text.includes("require('./check-profile.cjs')"))
      fail('PROBE_READONLY_OR_PROFILE_BYPASS_REMAINS',{name});
    if(text.includes('104e47b9d55adedc35f484045ef333fabb6073f4')||text.includes('73631900')||text.includes('73633000'))
      fail('EXPIRED_FORMAL_PROFILE_IDENTITY_REMAINS',{name});
    if(!text.includes("require('./read-only-client.cjs')")&&name!=='collector')
      fail('PROBE_READONLY_CLIENT_NOT_USED',{name});
  }
  if(!collector.includes("require('./read-only-client.cjs')"))fail('PROBE_READONLY_CLIENT_NOT_USED',{name:'collector'});
  if(!readonly.includes("['me','branches','code','time']")||!readonly.includes('READ_ONLY_TRANSPORT_WRITE_SURFACE_EXPOSED'))
    fail('READ_ONLY_TRANSPORT_CONTRACT_MISSING');
  let expired=false;try{require(path.join(KIT,'check-profile.cjs')).validateProfileLead({startTick:1,endTick:1101},100);}catch(error){expired=error.code==='PROFILE_WINDOW_EXPIRED';}
  if(!expired)fail('STABLE_PROFILE_EXPIRY_CODE_MISSING');
  console.log(JSON.stringify({status:'CONTROL_PLANE_PROBE_DECOUPLING_CONTRACT_VERIFIED',sessionKind:session.kind,
    formalFields:0,absoluteTickGate:false,readOnlyMethods:4,stableProfileExpiryCode:'PROFILE_WINDOW_EXPIRED'}));}
try{main();}catch(error){process.stderr.write(JSON.stringify({error:error.code||String(error.message||'DECOUPLING_VALIDATION_FAILED'),details:error.details||{}})+'\n');process.exitCode=1;}
