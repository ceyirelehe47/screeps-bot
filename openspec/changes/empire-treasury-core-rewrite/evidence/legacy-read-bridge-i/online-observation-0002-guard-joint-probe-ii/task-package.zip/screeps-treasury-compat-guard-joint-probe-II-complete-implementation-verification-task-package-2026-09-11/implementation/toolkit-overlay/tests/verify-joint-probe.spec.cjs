'use strict';
const test=require('node:test');const assert=require('node:assert/strict');
const fs=require('node:fs');const os=require('node:os');const path=require('node:path');
const C=require('../common.cjs');const S=require('../probe-session.cjs');const V=require('../verify-joint-probe.cjs');

function baseline(tick,at){return {kind:S.BASELINE_KIND,capturedAtMs:at,...C.EXPECTED,observedTick:tick,
  build:{commit:C.PRODUCTION_BASE,tree:C.PRODUCTION_TREE,dirty:'folded_out',deployBranch:C.EXPECTED.branch,tag:'tag'},
  digest:C.clone(C.ORIGINAL_DIGEST),moduleBodiesPersisted:false};}
function writeJson(file,value){fs.writeFileSync(file,JSON.stringify(value,null,2)+'\n');}
function makeValid(){
  const parent=fs.mkdtempSync(path.join(os.tmpdir(),'joint-verify-')),run=path.join(parent,'run');
  const preparedAtMs=2000,readyAtMs=3000,startedAtMs=4000,closedAtMs=1505000;
  const session=S.createProbeSession({baseline:baseline(100,1000),durationMs:1500000,preparedAtMs,runId:'a'.repeat(32)});
  S.writePreparedRun(run,session);S.writePostflight(run,baseline(300,1506000));
  writeJson(path.join(run,'collector-ready.json'),{status:'PROBE_COLLECTOR_READY',runId:session.runId,pid:42,
    readyAtMs,lastConsoleAtMs:2999,lastCpuAtMs:2998});
  writeJson(path.join(run,'collector-result.json'),{kind:'collector-result-v2',sessionKind:S.SESSION_KIND,
    runId:session.runId,pid:42,status:'closed',reason:'probe_complete',exitCode:0,footerWritten:true,
    lockRemoved:true,closedAtMs});
  writeJson(path.join(run,'heartbeat.json'),{sessionKind:S.SESSION_KIND,runId:session.runId,pid:42,
    state:'closed',socketState:'closed',stopReason:'probe_complete',unexpectedBridgeReports:0,closedAtMs});
  writeJson(path.join(run,'collector-stop.json'),{runId:session.runId,reason:'probe_complete',requestedAtMs:1504000,requestedByPid:7});
  writeJson(path.join(run,'guard-probe-result.json'),{kind:'guard-collector-control-plane-probe/v2',sessionKind:S.SESSION_KIND,
    status:'GUARD_COLLECTOR_CONTROL_PLANE_PROBE_VERIFIED',runId:session.runId,reason:'probe_complete',
    startedAtMs,durationMs:1500001,firstTick:1000,lastTick:1097,expectedMinimumTimeReads:98,
    timeChannel:{createdAtMs:startedAtMs,totalAttempts:101,totalSuccessfulReads:98,totalFailedCycles:1,
      consecutiveFailedCycles:0,lastSuccessAtMs:1459000,lastFailureAtMs:null,lastFailure:null},collectorTerminal:'ok',
    collectorPid:42,consoleChannelVerified:true,cpuChannelVerified:true,unexpectedBridgeReports:0,
    uploadAttemptPresent:false,codeWriteRequests:0,formalProfileUsed:false,candidateSnapshotUsed:false,
    backupSnapshotPersisted:false,auditFailed:false,failure:null});
  fs.writeFileSync(path.join(run,'collector.exit.txt'),'0\n');fs.writeFileSync(path.join(run,'guard-probe.exit.txt'),'0\n');
  fs.writeFileSync(path.join(run,'console.jsonl'),JSON.stringify({kind:'collector-footer',sessionKind:S.SESSION_KIND,
    runId:session.runId,pid:42,reason:'probe_complete',exitCode:0})+'\n');
  const lines=[{kind:'guard-probe-start',runId:session.runId,collectorPid:42,sessionKind:S.SESSION_KIND,
    durationMs:session.durationMs,formalProfileUsed:false,candidateSnapshotUsed:false}];
  for(let i=0;i<3;i++)lines.push({kind:'guard-time-read-attempt-failed',attempt:i+1});
  lines.push({kind:'guard-time-read-cycle-failed',terminal:false});
  for(let i=0;i<98;i++)lines.push({kind:'guard-time-read-success',time:1000+i,atMs:4000+i*(1455000/97)});
  lines[lines.length-1].atMs=1459000;
  for(let i=0;i<295;i++)lines.push({kind:'guard-probe-heartbeat',atMs:4000+i*5100,collectorPid:42,
    collectorState:'streaming',socketState:'open',consoleAgeMs:100,cpuAgeMs:100,unexpectedBridgeReports:0});
  fs.writeFileSync(path.join(run,'guard-probe.jsonl'),lines.map(JSON.stringify).join('\n')+'\n');
  return {parent,run,session};
}
function cleanup(x){fs.rmSync(x.parent,{recursive:true,force:true});}

test('independent verifier accepts complete dedicated-session evidence',()=>{const x=makeValid();try{
  const result=V.verifyRun(x.run);assert.equal(result.status,'GUARD_COLLECTOR_CONTROL_PLANE_PROBE_INDEPENDENTLY_VERIFIED');
  assert.equal(result.heartbeatEvidenceRows,295);assert.ok(result.heartbeatEvidenceSpanMs>=1490000);
  assert.equal(result.formalProfileUsed,false);
}finally{cleanup(x);}});

test('independent verifier rejects any formal session or residual lock artifact',()=>{const x=makeValid();try{
  fs.writeFileSync(path.join(x.run,'session.json'),'{}');assert.throws(()=>V.verifyRun(x.run),error=>error.code==='PROBE_FORBIDDEN_ARTIFACT_PRESENT');
  fs.unlinkSync(path.join(x.run,'session.json'));fs.writeFileSync(path.join(x.run,'collector.lock'),'{}');
  assert.throws(()=>V.verifyRun(x.run),error=>error.code==='PROBE_FORBIDDEN_ARTIFACT_PRESENT');
}finally{cleanup(x);}});

test('independent verifier rejects any upload attempt artifact',()=>{const x=makeValid();try{
  fs.writeFileSync(path.join(x.run,'upload-attempt.json'),'{}');assert.throws(()=>V.verifyRun(x.run),error=>error.code==='PROBE_FORBIDDEN_ARTIFACT_PRESENT');
}finally{cleanup(x);}});

test('independent verifier rejects collector pid changes and a compressed heartbeat timeline',()=>{let x=makeValid();try{
  const file=path.join(x.run,'guard-probe.jsonl'),lines=fs.readFileSync(file,'utf8').trim().split('\n').map(JSON.parse);
  lines.find(v=>v.kind==='guard-probe-heartbeat').collectorPid=43;fs.writeFileSync(file,lines.map(JSON.stringify).join('\n')+'\n');
  assert.throws(()=>V.verifyRun(x.run),error=>error.code==='PROBE_HEARTBEAT_TIMELINE_INVALID');
}finally{cleanup(x);}x=makeValid();try{
  const file=path.join(x.run,'guard-probe.jsonl'),lines=fs.readFileSync(file,'utf8').trim().split('\n').map(JSON.parse);
  let n=0;for(const line of lines)if(line.kind==='guard-probe-heartbeat')line.atMs=4000+(n++*1000);
  fs.writeFileSync(file,lines.map(JSON.stringify).join('\n')+'\n');
  assert.throws(()=>V.verifyRun(x.run),error=>error.code==='PROBE_HEARTBEAT_TIMELINE_INVALID');
}finally{cleanup(x);}});

test('independent verifier rejects session/preflight mismatch and changed postflight digest',()=>{let x=makeValid();try{
  const file=path.join(x.run,'preflight-before.json'),before=JSON.parse(fs.readFileSync(file,'utf8'));before.capturedAtMs++;
  writeJson(file,before);assert.throws(()=>V.verifyRun(x.run),error=>error.code==='PROBE_SESSION_BASELINE_MISMATCH');
}finally{cleanup(x);}x=makeValid();try{
  const file=path.join(x.run,'preflight-after.json'),after=JSON.parse(fs.readFileSync(file,'utf8'));
  after.digest.hash='0'.repeat(64);writeJson(file,after);assert.throws(()=>V.verifyRun(x.run));
}finally{cleanup(x);}});

test('independent verifier rejects duplicate collector footers or malformed stop evidence',()=>{let x=makeValid();try{
  const file=path.join(x.run,'console.jsonl'),line=fs.readFileSync(file,'utf8');fs.appendFileSync(file,line);
  assert.throws(()=>V.verifyRun(x.run),error=>error.code==='PROBE_COLLECTOR_FOOTER_INVALID');
}finally{cleanup(x);}x=makeValid();try{
  const file=path.join(x.run,'collector-stop.json'),stop=JSON.parse(fs.readFileSync(file,'utf8'));stop.reason='operator_stop';writeJson(file,stop);
  assert.throws(()=>V.verifyRun(x.run),error=>error.code==='PROBE_STOP_REQUEST_INVALID');
}finally{cleanup(x);}});

test('independent verifier rejects a regressing time-read timeline or inconsistent counters',()=>{let x=makeValid();try{
  const file=path.join(x.run,'guard-probe.jsonl'),lines=fs.readFileSync(file,'utf8').trim().split('\n').map(JSON.parse);
  const successes=lines.filter(v=>v.kind==='guard-time-read-success');successes[50].time=10;
  fs.writeFileSync(file,lines.map(JSON.stringify).join('\n')+'\n');
  assert.throws(()=>V.verifyRun(x.run),error=>error.code==='PROBE_TIME_TIMELINE_INVALID');
}finally{cleanup(x);}x=makeValid();try{
  const file=path.join(x.run,'guard-probe-result.json'),probe=JSON.parse(fs.readFileSync(file,'utf8'));probe.timeChannel.totalFailedCycles=0;writeJson(file,probe);
  assert.throws(()=>V.verifyRun(x.run),error=>error.code==='PROBE_TIME_TIMELINE_INVALID');
}finally{cleanup(x);}});
