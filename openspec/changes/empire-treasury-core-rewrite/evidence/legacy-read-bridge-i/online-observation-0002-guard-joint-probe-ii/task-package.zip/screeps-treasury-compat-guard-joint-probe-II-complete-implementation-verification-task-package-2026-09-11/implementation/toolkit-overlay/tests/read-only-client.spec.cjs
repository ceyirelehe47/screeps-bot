'use strict';
const test=require('node:test');const assert=require('node:assert/strict');
const R=require('../read-only-client.cjs');

test('read-only client exposes exactly four GET-oriented methods and no code-write surface',()=>{
  const calls=[];
  const base={
    me:(...a)=>{calls.push(['me',...a]);return 1;},
    branches:(...a)=>{calls.push(['branches',...a]);return 2;},
    code:(...a)=>{calls.push(['code',...a]);return 3;},
    time:(...a)=>{calls.push(['time',...a]);return 4;},
    setCode(){throw new Error('must not be reachable');},queryToken(){},overview(){},
  };
  const api=R.createReadOnlyClient({token:'x'},undefined,()=>base);
  assert.deepEqual(Object.keys(api).sort(),['branches','code','me','time']);
  assert.equal(R.assertReadOnlySurface(api),true);
  assert.equal(api.me(1),1);assert.equal(api.branches(2),2);assert.equal(api.code('default',3),3);assert.equal(api.time('shard1',4),4);
  assert.deepEqual(calls,[['me',1],['branches',2],['code','default',3],['time','shard1',4]]);
  assert.equal('setCode' in api,false);
});

test('read-only surface validator refuses extra or missing methods',()=>{
  assert.throws(()=>R.assertReadOnlySurface({me(){},branches(){},code(){},time(){},setCode(){}}));
  assert.throws(()=>R.assertReadOnlySurface({me(){},branches(){},code(){}}));
});
