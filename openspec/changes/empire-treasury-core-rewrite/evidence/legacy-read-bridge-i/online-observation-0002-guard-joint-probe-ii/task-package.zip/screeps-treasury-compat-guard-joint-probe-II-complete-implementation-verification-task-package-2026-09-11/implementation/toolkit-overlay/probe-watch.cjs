'use strict';

const C=require('./common.cjs');

function decodeLog(text) {
  return String(text).replace(/&quot;/g,'"').replace(/&#39;|&apos;/g,"'").replace(/&lt;/g,'<').replace(/&gt;/g,'>')
    .replace(/&#(\d+);/g,(_,n)=>{n=Number(n);return n<=0x10ffff?String.fromCodePoint(n):'\uFFFD';})
    .replace(/&amp;/g,'&');
}

function createProbeWatch(session,pid,at=Date.now()) {
  if(!session||session.kind!=='guard-control-plane-probe-session/v2'||!Number.isSafeInteger(pid)||pid<=0)
    C.fail('PROBE_WATCH_ARGUMENT_INVALID');
  const state={
    runId:session.runId,pid,userId:session.userId,shard:session.shard,
    state:'connecting',socketState:'connecting',updatedAtMs:at,connectedAtMs:null,authenticatedAtMs:null,
    lastFrameAtMs:null,lastConsoleAtMs:null,lastCpuAtMs:null,closedAtMs:null,closeCode:null,
    closeReason:null,closeWasClean:null,errorCode:null,stopReason:null,unexpectedBridgeReports:0,
  };
  function opened(now=Date.now()) {
    state.socketState='open';state.connectedAtMs=now;state.updatedAtMs=now;
  }
  function terminal(reason,{failed=true,close=null,error=null}={},now=Date.now()) {
    state.state=failed?'failed':'closed';state.socketState='closed';state.stopReason=reason;state.closedAtMs=now;
    if(close){state.closeCode=close.code;state.closeReason=close.reason;state.closeWasClean=close.wasClean;}
    if(error)state.errorCode=error.code??error.name??error.eventType??'unknown';
    state.updatedAtMs=now;
  }
  function inspectConsoleLog(line) {
    if(typeof line!=='string')return;
    try {
      const parsed=JSON.parse(decodeLog(line));
      if(C.obj(parsed)&&parsed.kind==='treasury-legacy-read-bridge') {
        state.unexpectedBridgeReports++;
        state.stopReason='unexpected_bridge_report_on_production_baseline';
      }
    } catch {/* Raw frame remains evidence; arbitrary application logs are not probe input. */}
  }
  function frame(text,now=Date.now()) {
    state.lastFrameAtMs=now;state.updatedAtMs=now;
    if(text==='auth ok'||String(text).startsWith('auth ok ')) {
      state.state='streaming';state.socketState='open';state.authenticatedAtMs=now;return 'auth';
    }
    if(String(text).startsWith('auth ')) {state.state='failed';state.stopReason='authentication_failed';return 'auth-failure';}
    let value;try{value=JSON.parse(text);}catch{return 'ignored';}
    if(!Array.isArray(value)||value.length!==2)return 'ignored';
    const [channel,data]=value;
    if(channel===`user:${session.userId}/console`&&C.obj(data)&&data.shard===session.shard&&C.obj(data.messages)
      &&Array.isArray(data.messages.log)&&Array.isArray(data.messages.results)) {
      if(state.state!=='streaming')return 'ignored';
      state.lastConsoleAtMs=now;
      for(const line of data.messages.log)inspectConsoleLog(line);
      return 'console';
    }
    if(channel===`user:${session.userId}/cpu`&&C.obj(data)
      &&Object.values(data).some(n=>typeof n==='number'&&Number.isFinite(n))) {
      if(state.state!=='streaming')return 'ignored';state.lastCpuAtMs=now;return 'cpu';
    }
    return 'ignored';
  }
  return {state,opened,terminal,frame};
}

module.exports={decodeLog,createProbeWatch};
