#!/usr/bin/env node
'use strict';
const cp=require('node:child_process');const path=require('node:path');
const EXPECTED={
  refactor:{branch:'refactor/empire-treasury-rearchitecture',sha:'eb00879a1ff71275ff32e310378d3590fc910e6a'},
  compat:{branch:'compat/treasury-read-bridge-i',sha:'fcfc125f0e5cd6c3370318b4fee0450f4d09af53'},
};
function fail(code,details={}){const e=new Error(code);e.code=code;e.details=details;throw e;}
function options(argv){const o={};for(let i=0;i<argv.length;i+=2){if(!argv[i]?.startsWith('--')||!argv[i+1])fail('INVALID_ARGUMENTS');o[argv[i].slice(2)]=argv[i+1];}if(!o.refactor||!o.compat)fail('MISSING_ARGUMENT');return o;}
function git(repo,args){try{return cp.execFileSync('git',['-C',repo,...args],{encoding:'utf8',stdio:['ignore','pipe','pipe'],timeout:30000}).trim();}catch{fail('GIT_CHECK_FAILED',{args});}}
function check(repo,expected){const head=git(repo,['rev-parse','HEAD']),remote=git(repo,['rev-parse',`origin/${expected.branch}`]),
  branch=git(repo,['branch','--show-current']),status=git(repo,['status','--porcelain']);
  if(head!==expected.sha||remote!==expected.sha||branch!==expected.branch||status)fail('BASELINE_DRIFT',{branch,head,remote,dirty:!!status});
  return {branch,head,remote,clean:true};}
function main(){const o=options(process.argv.slice(2));const result={status:'GUARD_JOINT_PROBE_BASELINE_VERIFIED',
  refactor:check(path.resolve(o.refactor),EXPECTED.refactor),compat:check(path.resolve(o.compat),EXPECTED.compat)};
  console.log(JSON.stringify(result));}
try{main();}catch(error){process.stderr.write(JSON.stringify({error:error.code||String(error.message||'BASELINE_VERIFY_FAILED'),details:error.details||{}})+'\n');process.exitCode=1;}
