'use strict';
const test=require('node:test');const assert=require('node:assert/strict');
const fs=require('node:fs');const os=require('node:os');const path=require('node:path');const {spawn}=require('node:child_process');
const collector=path.resolve(__dirname,'..','probe-console-collector.cjs');const preload=path.resolve(__dirname,'probe-collector-preload.cjs');
function run(mode,{stop=false}={}){return new Promise((resolve,reject)=>{
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'probe-collector-v2-'));
  const child=spawn(process.execPath,['--require',preload,collector,'--repo','unused','--secret','unused','--run',dir],
    {env:{...process.env,FAKE_PROBE_WS_MODE:mode},stdio:['ignore','pipe','pipe']});
  let stdout='',stderr='';child.stdout.on('data',b=>stdout+=b);child.stderr.on('data',b=>stderr+=b);let stopTimer;
  if(stop)stopTimer=setInterval(()=>{const hb=path.join(dir,'heartbeat.json');if(!fs.existsSync(hb))return;
    try{const state=JSON.parse(fs.readFileSync(hb,'utf8'));if(state.state==='streaming'&&Number.isFinite(state.lastConsoleAtMs)&&Number.isFinite(state.lastCpuAtMs)){
      clearInterval(stopTimer);fs.writeFileSync(path.join(dir,'collector-stop.json'),JSON.stringify({runId:'a'.repeat(32),
        reason:'probe_complete',requestedAtMs:Date.now()})+'\n',{flag:'wx'});}}catch{}},25);
  const timeout=setTimeout(()=>{child.kill('SIGKILL');reject(new Error(`collector timeout ${mode}`));},8000);
  child.once('close',(code,signal)=>{clearTimeout(timeout);clearInterval(stopTimer);resolve({dir,code,signal,stdout,stderr});});
});}
function evidence(dir){return {result:JSON.parse(fs.readFileSync(path.join(dir,'collector-result.json'),'utf8')),
  heartbeat:JSON.parse(fs.readFileSync(path.join(dir,'heartbeat.json'),'utf8')),
  lines:fs.readFileSync(path.join(dir,'console.jsonl'),'utf8').trim().split('\n').map(JSON.parse),
  privateText:fs.readFileSync(path.join(dir,'collector-private.jsonl'),'utf8')};}

test('dedicated probe collector records an abnormal close once and redacts detail',async()=>{const r=await run('close');try{
  assert.equal(r.code,1);const e=evidence(r.dir);assert.equal(e.result.sessionKind,'guard-control-plane-probe-session/v2');
  assert.equal(e.result.reason,'socket_closed');assert.equal(e.result.close.code,1006);assert.match(e.result.close.reason,/REDACTED/);
  assert.equal(e.lines.filter(x=>x.kind==='collector-footer').length,1);assert.ok(!JSON.stringify(e).includes('TEST_SECRET_TOKEN_123456789'));
}finally{fs.rmSync(r.dir,{recursive:true,force:true});}});

test('dedicated probe collector classifies socket error without close and keeps bounded diagnostics',async()=>{const r=await run('error');try{
  assert.equal(r.code,1);const e=evidence(r.dir);assert.equal(e.result.reason,'socket_error_without_close');
  assert.equal(e.result.error.code,'ECONNRESET');assert.equal(e.lines.filter(x=>x.kind==='collector-footer').length,1);
  assert.ok(!e.privateText.includes('TEST_SECRET_TOKEN_123456789'));
}finally{fs.rmSync(r.dir,{recursive:true,force:true});}});

test('dedicated probe collector accepts the run-bound file stop and never needs a formal session/profile',async()=>{const r=await run('stop',{stop:true});try{
  assert.equal(r.code,0);const e=evidence(r.dir);assert.equal(e.result.reason,'probe_complete');assert.equal(e.result.status,'closed');
  assert.equal(e.heartbeat.stopReason,'probe_complete');assert.equal(e.heartbeat.sessionKind,'guard-control-plane-probe-session/v2');
  assert.equal(fs.existsSync(path.join(r.dir,'session.json')),false);assert.equal(fs.existsSync(path.join(r.dir,'backup.json')),false);
}finally{fs.rmSync(r.dir,{recursive:true,force:true});}});
