'use strict';
const test=require('node:test');const assert=require('node:assert/strict');
const fs=require('node:fs');const os=require('node:os');const path=require('node:path');const {spawn}=require('node:child_process');
const P=require('../guard-probe.cjs');const S=require('../probe-session.cjs');

const session={kind:S.SESSION_KIND,runId:'a'.repeat(32),userId:'u1',shard:'shard1',policy:{...S.PROBE_POLICY}};

test('minimum time-read count keeps a small scheduling margin but requires sustained reads',()=>{
  assert.equal(P.expectedMinimumTimeReads(1200000),78);
  assert.equal(P.expectedMinimumTimeReads(1500000),98);
  assert.equal(P.advanceScheduledRead(0,15000,2000),15000);
  assert.equal(P.advanceScheduledRead(15000,15000,18000),30000);
  assert.equal(P.advanceScheduledRead(30000,15000,52000),52000);
});

test('collector probe terminal requires the dedicated session kind, exact run, clean reason, zero exit and footer',()=>{
  const ok={kind:'collector-result-v2',sessionKind:S.SESSION_KIND,runId:session.runId,status:'closed',
    reason:'probe_complete',exitCode:0,footerWritten:true};
  assert.equal(P.validateProbeTerminal(ok,session),true);
  assert.equal(P.validateProbeTerminal({...ok,sessionKind:'compat-online-run-v1'},session),false);
  assert.equal(P.validateProbeTerminal({...ok,runId:'b'.repeat(32)},session),false);
  assert.equal(P.validateProbeTerminal({...ok,exitCode:1},session),false);
  assert.equal(P.validateProbeTerminal({...ok,footerWritten:false},session),false);
});

test('probe heartbeat requires identity, stable pid, open socket and both fresh channels',()=>{
  const now=100000;
  const base={sessionKind:S.SESSION_KIND,runId:session.runId,userId:session.userId,shard:session.shard,
    pid:42,state:'streaming',socketState:'open',updatedAtMs:99999,lastConsoleAtMs:99998,lastCpuAtMs:99997,
    stopReason:null,unexpectedBridgeReports:0};
  assert.equal(P.probeHeartbeatReason(base,session,now,{expectedPid:42}),null);
  assert.equal(P.probeHeartbeatReason({...base,pid:43},session,now,{expectedPid:42}),'collector_pid_changed');
  assert.equal(P.probeHeartbeatReason({...base,lastCpuAtMs:null},session,now,{expectedPid:42}),'collector_cpu_never_seen');
  assert.equal(P.probeHeartbeatReason({...base,lastConsoleAtMs:40000},session,now,{expectedPid:42}),'collector_console_silent');
  assert.equal(P.probeHeartbeatReason({...base,unexpectedBridgeReports:1},session,now,{expectedPid:42}),
    'unexpected_bridge_report_on_production_baseline');
});

test('terminal collector result takes precedence over an otherwise fresh heartbeat',()=>{
  const now=100000,heartbeat={sessionKind:S.SESSION_KIND,runId:session.runId,userId:session.userId,
    shard:session.shard,pid:42,state:'streaming',socketState:'open',updatedAtMs:now,lastConsoleAtMs:now,
    lastCpuAtMs:now,stopReason:null,unexpectedBridgeReports:0};
  const result={kind:'collector-result-v2',sessionKind:S.SESSION_KIND,runId:session.runId,status:'failed',
    reason:'socket_closed',exitCode:1};
  assert.equal(P.probeHeartbeatReason(heartbeat,session,now,{collectorResult:result,expectedPid:42}),
    'collector_exit_socket_closed');
});

test('stop request is create-once and a conflicting existing request is rejected',()=>{
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'guard-probe-stop-')),file=path.join(dir,'collector-stop.json');
  try{
    assert.equal(P.requestCollectorStop(file,session,'probe_complete',1234),true);
    assert.equal(P.requestCollectorStop(file,session,'probe_complete',5678),false);
    const value=JSON.parse(fs.readFileSync(file,'utf8'));assert.equal(value.requestedAtMs,1234);
    value.reason='operator_stop';fs.writeFileSync(file,JSON.stringify(value));
    assert.throws(()=>P.requestCollectorStop(file,session,'probe_complete',9999));
  }finally{fs.rmSync(dir,{recursive:true,force:true});}
});

test('collector result waiter refuses malformed or unexpected terminal evidence',async()=>{
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'guard-probe-result-')),file=path.join(dir,'collector-result.json');
  try{
    fs.writeFileSync(file,'not json');
    assert.equal((await P.waitForCollectorResult(file,session,{timeoutMs:10})).status,'invalid');
    fs.writeFileSync(file,JSON.stringify({kind:'collector-result-v2',sessionKind:S.SESSION_KIND,
      runId:session.runId,status:'failed',reason:'operator_stop',exitCode:1,footerWritten:true}));
    assert.equal((await P.waitForCollectorResult(file,session,{timeoutMs:10})).status,'unexpected');
  }finally{fs.rmSync(dir,{recursive:true,force:true});}
});

test('probe implementation is structurally read-only and its complete process loop reaches a clean terminal',async()=>{
  const source=fs.readFileSync(path.resolve(__dirname,'..','guard-probe.cjs'),'utf8');
  assert.equal(source.includes('.setCode('),false);
  assert.equal(source.includes('restore-modules'),false);
  assert.equal(source.includes('upload-once'),false);
  assert.equal(source.includes("require('./session.cjs')"),false);
  assert.match(source,/loadProbeSession/);
  assert.match(source,/createReadOnlyClient/);
  assert.match(source,/advanceScheduledRead\(nextTimeReadAt/);
  assert.equal(source.includes('lastTimeRead=performance.now()'),false);
  assert.match(source,/codeWriteRequests:0/);
  assert.match(source,/formalProfileUsed:false/);
  assert.ok(source.indexOf("fs.unlinkSync(file('guard-probe.lock'))")
    <source.indexOf("C.writeNew(file('guard-probe-result.json')"));
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'guard-probe-process-'));
  try{
    fs.writeFileSync(path.join(dir,'collector-ready.json'),JSON.stringify({status:'PROBE_COLLECTOR_READY',
      runId:'a'.repeat(32),pid:4242})+'\n');
    const now=Date.now();fs.writeFileSync(path.join(dir,'heartbeat.json'),JSON.stringify({
      sessionKind:S.SESSION_KIND,runId:'a'.repeat(32),userId:'u1',shard:'shard1',pid:4242,state:'streaming',
      socketState:'open',updatedAtMs:now,lastConsoleAtMs:now,lastCpuAtMs:now,stopReason:null,unexpectedBridgeReports:0})+'\n');
    const preload=path.resolve(__dirname,'guard-probe-preload.cjs'),entry=path.resolve(__dirname,'..','guard-probe.cjs');
    const result=await new Promise((resolve,reject)=>{const child=spawn(process.execPath,['--require',preload,entry,
      '--repo','unused','--secret','unused','--run',dir,'--probe'],{env:{...process.env,FAKE_GUARD_PROBE_RUN:dir},stdio:['ignore','pipe','pipe']});
      let stdout='',stderr='';child.stdout.on('data',b=>stdout+=b);child.stderr.on('data',b=>stderr+=b);
      const timeout=setTimeout(()=>{child.kill('SIGKILL');reject(new Error('guard probe process timeout'));},5000);
      child.once('close',code=>{clearTimeout(timeout);resolve({code,stdout,stderr});});});
    assert.equal(result.code,0,result.stderr);const terminal=JSON.parse(fs.readFileSync(path.join(dir,'guard-probe-result.json'),'utf8'));
    assert.equal(terminal.status,'GUARD_COLLECTOR_CONTROL_PLANE_PROBE_VERIFIED');assert.equal(terminal.reason,'probe_complete');
    assert.ok(terminal.timeChannel.totalSuccessfulReads>=1);assert.equal(fs.existsSync(path.join(dir,'guard-probe.lock')),false);
  }finally{fs.rmSync(dir,{recursive:true,force:true});}
});

test('formal deadline guard still consumes classified resilient reads and drops the old generic label',()=>{
  const source=fs.readFileSync(path.resolve(__dirname,'..','deadline-guard.cjs'),'utf8');
  assert.match(source,/require\('\.\/guard-control\.cjs'\)/);
  assert.match(source,/readGameTimeResilient/);
  assert.equal(source.includes('guard_read_or_channel_failure'),false);
  assert.match(source,/failure,timeChannel/);
  assert.ok(source.indexOf("fs.unlinkSync(file('guard.lock'))")
    <source.indexOf("C.atomicJson(file('guard-result.json')"));
});
