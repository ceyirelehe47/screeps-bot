# Guard Joint Probe II — complete implementation verification package

本包提供已完成的专用只读 probe session、collector、Guard probe、前后线上摘要核对、独立 verifier、秘密扫描器及全部测试。执行 Agent 只负责在固定 Git 基线和真实 Windows/官方服环境中验证，不负责设计或修改实现。

入口：`AGENT-RUN.md`

硬边界：

- 零 Screeps code POST；
- 零正式候选上传；
- 零 restore；
- compat 分支零提交；
- probe session 不含 profile、candidate 或 backup；
- 一次 25 分钟联合探针，不重启、不拼接、不换 runId；
- 只允许在 refactor 分支追加 evidence 提交。
