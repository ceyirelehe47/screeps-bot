#!/usr/bin/env node
'use strict';

const fs=require('node:fs');
const path=require('node:path');
const {performance}=require('node:perf_hooks');
const C=require('./common.cjs');
const G=require('./guard-control.cjs');
const S=require('./probe-session.cjs');
const R=require('./read-only-client.cjs');

const COLLECTOR_CLOSE_WAIT_MS=15000;
const HEARTBEAT_EVIDENCE_INTERVAL_MS=5000;

function expectedMinimumTimeReads(durationMs,timeIntervalMs=S.PROBE_POLICY.timeIntervalMs) {
  return Math.max(1,Math.floor(durationMs/timeIntervalMs)-2);
}
function advanceScheduledRead(previousDueAt,timeIntervalMs,now) {
  if(!Number.isFinite(previousDueAt)||!Number.isSafeInteger(timeIntervalMs)||timeIntervalMs<1||!Number.isFinite(now))
    C.fail('PROBE_SCHEDULE_ARGUMENT_INVALID');
  return Math.max(previousDueAt+timeIntervalMs,now);
}

function validateProbeTerminal(result,session,reason='probe_complete') {
  return !!result&&result.kind==='collector-result-v2'&&result.runId===session.runId
    &&result.sessionKind===S.SESSION_KIND&&result.status==='closed'&&result.reason===reason
    &&result.exitCode===0&&result.footerWritten===true;
}

function collectorResultReason(result,session) {
  if(result===undefined||result===null)return null;
  if(!C.obj(result)||result.kind!=='collector-result-v2'||result.runId!==session.runId
    ||result.sessionKind!==S.SESSION_KIND||!['closed','failed'].includes(result.status)
    ||!Number.isSafeInteger(result.exitCode)||typeof result.reason!=='string'
    ||!/^[a-z0-9_]{1,96}$/.test(result.reason))return 'collector_result_invalid';
  return 'collector_exit_'+result.reason;
}

function probeHeartbeatReason(heartbeat,session,now,{collectorResult,expectedPid=null,maxAgeMs=10000,
  maxSilenceMs=session.policy.channelSilenceMs}={}) {
  const terminal=collectorResultReason(collectorResult,session);if(terminal)return terminal;
  if(!C.obj(heartbeat)||heartbeat.runId!==session.runId||heartbeat.sessionKind!==S.SESSION_KIND
    ||heartbeat.userId!==session.userId||heartbeat.shard!==session.shard
    ||!Number.isSafeInteger(heartbeat.pid)||heartbeat.pid<=0)return 'collector_heartbeat_missing_or_foreign';
  if(expectedPid!==null&&heartbeat.pid!==expectedPid)return 'collector_pid_changed';
  if(heartbeat.stopReason)return 'collector_reported_failure';
  if(heartbeat.unexpectedBridgeReports>0)return 'unexpected_bridge_report_on_production_baseline';
  if(heartbeat.state!=='streaming')return heartbeat.state==='closed'||heartbeat.state==='failed'
    ?'collector_terminal_without_result':'collector_not_streaming';
  if(heartbeat.socketState!=='open')return 'collector_socket_not_streaming';
  if(!Number.isFinite(heartbeat.updatedAtMs)||heartbeat.updatedAtMs>now+1000||now-heartbeat.updatedAtMs>maxAgeMs)
    return 'collector_heartbeat_stale';
  if(!Number.isFinite(heartbeat.lastConsoleAtMs))return 'collector_console_never_seen';
  if(heartbeat.lastConsoleAtMs>now+1000||now-heartbeat.lastConsoleAtMs>maxSilenceMs)return 'collector_console_silent';
  if(!Number.isFinite(heartbeat.lastCpuAtMs))return 'collector_cpu_never_seen';
  if(heartbeat.lastCpuAtMs>now+1000||now-heartbeat.lastCpuAtMs>maxSilenceMs)return 'collector_cpu_silent';
  return null;
}

function requestCollectorStop(file,session,reason,now=Date.now()) {
  const value={runId:session.runId,reason,requestedAtMs:now,requestedByPid:process.pid};
  if(fs.existsSync(file)) {
    const existing=C.readJson(file,16384);
    if(existing.runId!==value.runId||existing.reason!==reason)C.fail('COLLECTOR_STOP_REQUEST_CONFLICT');
    return false;
  }
  C.writeNew(file,value);return true;
}

async function waitForCollectorResult(file,session,{reason='probe_complete',timeoutMs=COLLECTOR_CLOSE_WAIT_MS,
  pause=C.pause,clock=()=>performance.now()}={}) {
  const end=clock()+timeoutMs;
  while(clock()<end) {
    if(fs.existsSync(file)) {
      let result;try{result=C.readJson(file,32768);}catch{return {status:'invalid',result:null};}
      return {status:validateProbeTerminal(result,session,reason)?'ok':'unexpected',result};
    }
    await pause(250);
  }
  return {status:'timeout',result:null};
}

async function runProbe({repo,secretPath,run}) {
  if(C.git(repo,['rev-parse','HEAD'])!==C.PROBE_REFACTOR_BASE)C.fail('PROBE_REFACTOR_BASE_MISMATCH');
  if(C.git(repo,['status','--porcelain']))C.fail('PROBE_REFACTOR_WORKTREE_DIRTY');
  const secret=C.loadSecret(secretPath),session=S.loadProbeSession(run,{forStart:true});
  const ready=C.readJson(path.join(run,'collector-ready.json'),16384);
  if(ready.status!=='PROBE_COLLECTOR_READY'||ready.runId!==session.runId||!Number.isSafeInteger(ready.pid)||ready.pid<=0)
    C.fail('PROBE_COLLECTOR_NOT_READY');
  const file=name=>path.join(run,name),api=R.createReadOnlyClient(secret);R.assertReadOnlySurface(api);
  if(fs.existsSync(file('upload-attempt.json')))C.fail('PROBE_UPLOAD_ATTEMPT_PRESENT');
  C.writeNew(file('guard-probe.lock'),{runId:session.runId,pid:process.pid,startedAtMs:Date.now(),sessionKind:session.kind});
  let auditFailed=false;
  const record=value=>{try{C.audit(file('guard-probe.jsonl'),value,secret.redact);}catch{auditFailed=true;}};
  const started=performance.now(),startedAtMs=Date.now(),timeChannel=G.createTimeChannelState(startedAtMs);
  let nextTimeReadAt=started,lastTick=null,firstTick=null,reason=null,failure=null,collectorResult=null;
  let lastHeartbeat=null,lastHeartbeatEvidence=-Infinity,stage='startup';
  const collectorPid=ready.pid;
  const signal=()=>{reason='operator_stop';};process.once('SIGINT',signal);process.once('SIGTERM',signal);
  record({kind:'guard-probe-start',runId:session.runId,pid:process.pid,durationMs:session.durationMs,
    collectorPid,sessionKind:session.kind,formalProfileUsed:false,candidateSnapshotUsed:false});
  try {
    while(!reason&&performance.now()-started<session.durationMs) {
      if(fs.existsSync(file('upload-attempt.json'))){reason='probe_upload_attempt_detected';break;}
      stage='heartbeat_read';
      const heartbeat=await G.readJsonArtifact(file('heartbeat.json'),16384,{required:true});
      lastHeartbeat=heartbeat;
      stage='collector_result_read';
      collectorResult=await G.readJsonArtifact(file('collector-result.json'),32768);
      const assessment=probeHeartbeatReason(heartbeat,session,Date.now(),{collectorResult,expectedPid:collectorPid});
      if(assessment){reason=assessment;break;}
      if(performance.now()-lastHeartbeatEvidence>=HEARTBEAT_EVIDENCE_INTERVAL_MS) {
        const now=Date.now();
        record({kind:'guard-probe-heartbeat',atMs:now,collectorPid:heartbeat.pid,
          collectorState:heartbeat.state,socketState:heartbeat.socketState,
          consoleAgeMs:now-heartbeat.lastConsoleAtMs,cpuAgeMs:now-heartbeat.lastCpuAtMs,
          unexpectedBridgeReports:heartbeat.unexpectedBridgeReports||0});
        lastHeartbeatEvidence=performance.now();
      }
      if(performance.now()>=nextTimeReadAt) {
        stage='game_time_read';
        const read=await G.readGameTimeResilient({api,shard:session.shard,budgetMs:8000,state:timeChannel,
          record,redact:secret.redact});
        nextTimeReadAt=advanceScheduledRead(nextTimeReadAt,session.policy.timeIntervalMs,performance.now());
        if(read.status==='terminal'){reason=read.failure.reason;failure={...read.failure,timeChannel:read.state};break;}
        if(read.status==='ok') {
          if(lastTick!==null&&read.time<lastTick){reason='game_tick_regressed';break;}
          if(firstTick===null)firstTick=read.time;
          lastTick=read.time;
        }
      }
      stage='guard_ready_write';
      C.atomicJson(file('guard-probe-ready.json'),{runId:session.runId,pid:process.pid,state:'running',
        sessionKind:session.kind,updatedAtMs:Date.now(),elapsedMs:Math.floor(performance.now()-started),
        firstTick,lastTick,collectorPid,controlPlane:timeChannel.consecutiveFailedCycles>0?'degraded':'healthy',
        timeChannel:G.timeChannelSnapshot(timeChannel)});
      await C.pause(500);
    }
    if(!reason&&performance.now()-started>=session.durationMs)reason='probe_complete';
  } catch(error) {
    const classified=G.classifyGuardFailure(stage,error);
    reason=classified.reason;
    failure={...classified,diagnostic:G.safeGuardDiagnostic(stage,error,secret.redact),
      timeChannel:G.timeChannelSnapshot(timeChannel)};
    record({kind:'guard-probe-control-failure',...failure});
  }

  const now=Date.now();
  const consoleFresh=!!lastHeartbeat&&Number.isFinite(lastHeartbeat.lastConsoleAtMs)
    &&now-lastHeartbeat.lastConsoleAtMs<=session.policy.channelSilenceMs;
  const cpuFresh=!!lastHeartbeat&&Number.isFinite(lastHeartbeat.lastCpuAtMs)
    &&now-lastHeartbeat.lastCpuAtMs<=session.policy.channelSilenceMs;
  const minimumReads=expectedMinimumTimeReads(session.durationMs,session.policy.timeIntervalMs);
  const successful=reason==='probe_complete'&&!auditFailed
    &&timeChannel.totalSuccessfulReads>=minimumReads
    &&timeChannel.totalFailedCycles<=session.policy.maximumTotalFailedCycles
    &&timeChannel.consecutiveFailedCycles===session.policy.requiredFinalConsecutiveFailedCycles
    &&firstTick!==null&&lastTick!==null&&lastTick>=firstTick
    &&consoleFresh&&cpuFresh
    &&lastHeartbeat?.pid===collectorPid
    &&(lastHeartbeat?.unexpectedBridgeReports||0)===0
    &&!fs.existsSync(file('upload-attempt.json'));
  const requestedStopReason=successful?'probe_complete':'operator_stop';
  let stopResult={status:'not_requested',result:null};
  stage='closing_write';
  try {
    requestCollectorStop(file('collector-stop.json'),session,requestedStopReason);
    stopResult=await waitForCollectorResult(file('collector-result.json'),session,{reason:requestedStopReason});
  } catch(error) {
    if(successful) {
      const classified=G.classifyGuardFailure('closing_write',error);
      reason=classified.reason;
      failure={...classified,diagnostic:G.safeGuardDiagnostic('closing_write',error,secret.redact)};
    }
  }
  const verified=successful&&stopResult.status==='ok';
  const terminal={
    kind:'guard-collector-control-plane-probe/v2',
    sessionKind:session.kind,
    status:verified?'GUARD_COLLECTOR_CONTROL_PLANE_PROBE_VERIFIED':'GUARD_COLLECTOR_CONTROL_PLANE_PROBE_FAILED',
    runId:session.runId,reason:verified?'probe_complete':reason,
    startedAtMs,durationMs:Math.floor(performance.now()-started),firstTick,lastTick,
    expectedMinimumTimeReads:minimumReads,timeChannel:G.timeChannelSnapshot(timeChannel),
    collectorTerminal:stopResult.status,collectorPid,consoleChannelVerified:consoleFresh,cpuChannelVerified:cpuFresh,
    collectorResult:stopResult.result?{status:stopResult.result.status,reason:stopResult.result.reason,
      exitCode:stopResult.result.exitCode,footerWritten:stopResult.result.footerWritten,pid:stopResult.result.pid}:null,
    unexpectedBridgeReports:lastHeartbeat?.unexpectedBridgeReports||0,
    uploadAttemptPresent:fs.existsSync(file('upload-attempt.json')),
    codeWriteRequests:0,formalProfileUsed:false,candidateSnapshotUsed:false,backupSnapshotPersisted:false,
    auditFailed,failure,
  };
  try{fs.unlinkSync(file('guard-probe.lock'));}
  catch(error){const classified=G.classifyGuardFailure('closing_write',error);
    terminal.status='GUARD_COLLECTOR_CONTROL_PLANE_PROBE_FAILED';terminal.auditFailed=true;
    if(terminal.reason==='probe_complete')terminal.reason=classified.reason;
    if(!terminal.failure)terminal.failure={...classified,diagnostic:G.safeGuardDiagnostic('closing_write',error,secret.redact)};
  }
  try{C.writeNew(file('guard-probe-result.json'),terminal);}
  catch(error){const classified=G.classifyGuardFailure('closing_write',error);
    terminal.status='GUARD_COLLECTOR_CONTROL_PLANE_PROBE_FAILED';terminal.auditFailed=true;
    if(terminal.reason==='probe_complete')terminal.reason=classified.reason;
    if(!terminal.failure)terminal.failure={...classified,diagnostic:G.safeGuardDiagnostic('closing_write',error,secret.redact)};
  }
  console.log(secret.redact(JSON.stringify(terminal)));
  return terminal;
}

async function main(argv) {
  const o=C.options(argv,['repo','secret','run'],['probe']);C.required(o,'repo','secret','run');
  if(!o.probe)C.fail('EXPLICIT_PROBE_FLAG_REQUIRED');
  const result=await runProbe({repo:path.resolve(o.repo),secretPath:path.resolve(o.secret),run:path.resolve(o.run)});
  process.exitCode=result.status==='GUARD_COLLECTOR_CONTROL_PLANE_PROBE_VERIFIED'?0:6;
}

module.exports={expectedMinimumTimeReads,advanceScheduledRead,validateProbeTerminal,collectorResultReason,probeHeartbeatReason,
  requestCollectorStop,waitForCollectorResult,runProbe,main};
if(require.main===module)C.entrypoint(()=>main(process.argv.slice(2)));
