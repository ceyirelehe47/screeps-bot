'use strict';
const test=require('node:test');const assert=require('node:assert/strict');
const fs=require('node:fs');const path=require('node:path');
const P=require('../check-profile.cjs');

test('expired formal profile reports a stable PROFILE_WINDOW_EXPIRED code with arithmetic',()=>{
  assert.throws(()=>P.validateProfileLead({startTick:100,endTick:1200},500),error=>{
    assert.equal(error.code,'PROFILE_WINDOW_EXPIRED');
    assert.deepEqual(error.details,{observedTick:500,startTick:100,endTick:1200,requiredStartTickMinimum:600});
    return true;
  });
});

test('fresh formal profile returns the minimum start tick without changing policy',()=>{
  assert.equal(P.validateProfileLead({startTick:600,endTick:1700},500),600);
});

test('formal profile validator uses common Failure codes rather than plain Error messages',()=>{
  const source=fs.readFileSync(path.resolve(__dirname,'..','check-profile.cjs'),'utf8');
  assert.match(source,/C\.fail\('PROFILE_WINDOW_EXPIRED'/);
  assert.match(source,/C\.entrypoint/);
  assert.equal(source.includes("throw new Error('insufficient pre-upload lead"),false);
});
