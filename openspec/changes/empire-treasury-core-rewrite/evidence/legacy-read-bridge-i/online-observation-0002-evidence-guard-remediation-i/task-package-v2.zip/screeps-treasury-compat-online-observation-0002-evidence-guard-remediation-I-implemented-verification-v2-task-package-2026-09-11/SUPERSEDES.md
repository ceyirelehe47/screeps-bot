# Supersession Notice

本包是 `implemented-verification-v2`，完整取代以下已作废包：

```text
screeps-treasury-compat-online-observation-0002-evidence-guard-remediation-I-
implemented-verification-task-package-2026-09-11.zip
SHA-256: a70d615bbddc22056172ce93b7674a868061769c8f607f58be470f2613583842
```

作废原因已经复现：旧包的 repository transform 会在纠错段落中逐字引用
`collector 的 WS 帧在关闭前中断`，而旧包 verifier 对 REPORT.md 做无语境
substring 禁止检查，因此固定 `apply` 产物必然被固定 `verify` 拒绝。

v2 的修复：

1. 改为不含禁用原串的间接转述；
2. `apply-repository-remediation.cjs` 在接触工作树前先用与最终 verifier 相同的
   policy 校验完整目标文本；
3. `validate-transforms.cjs` 对每个固定 replacement 实际执行内存变换，并用同一
   policy 校验目标，同时注入两项禁用串做反向对照；
4. `verify-repository-remediation.cjs` 与上述检查共享
   `tools/remediation-policy.cjs`，避免 apply/verify 规则漂移；
5. 修正另一个在旧包 §5 才会暴露的路径问题：归档 Git tree 中的测试文件名被扁平保存，
   但测试源码的相对路径明确要求它们恢复到 `tests/`。旧 materializer 直接落到 toolkit 根目录，
   旧 verifier 又只扫描 `tests/`，因此实际只能发现 25 个实现测试而不可能达到 41。
   v2 以 `references/TOOL-BASE-LAYOUT.json` 固定映射 25 个归档文件，将 4 个基底 spec 和
   `collector-preload.cjs` 恢复到 `tests/`，再严格运行 4 个基底 spec + 3 个实现 spec，要求 41/41；
6. detached probe worktree 命令显式使用 `git -C "$COMPAT_REPO" worktree add`，不依赖 Agent 当前目录。

旧包产生的 §1、§3 测试结果只能作为失败诊断原件；执行 v2 时仍须重新验证包完整性、
transform contract 与 25 项实现测试。旧包未产生提交或上传，不需要回滚 Git 历史。
