#!/usr/bin/env node
'use strict';

const fs = require('node:fs');
const path = require('node:path');
const cp = require('node:child_process');
const crypto = require('node:crypto');

const ROOT = path.resolve(__dirname, '..');
const LAYOUT = JSON.parse(fs.readFileSync(path.join(ROOT, 'references', 'TOOL-BASE-LAYOUT.json'), 'utf8'));
const REF = LAYOUT.sourceRef;
const BASE = 'openspec/changes/empire-treasury-core-rewrite/evidence/legacy-read-bridge-i/online-observation-0002-collector-reliability-i/02-tooling/as-shipped';
const TREE = LAYOUT.sourceTree;

function fail(code, details = {}) {
  const error = new Error(code);
  error.code = code;
  error.details = details;
  throw error;
}

function options(argv) {
  const result = {};
  for (let index = 0; index < argv.length; index += 2) {
    if (!argv[index]?.startsWith('--') || !argv[index + 1]) fail('INVALID_ARGUMENTS');
    result[argv[index].slice(2)] = argv[index + 1];
  }
  if (!result.repo || !result.out) fail('MISSING_ARGUMENT');
  return result;
}

function git(repo, args, { buffer = false } = {}) {
  return cp.execFileSync('git', ['-C', repo, ...args], {
    encoding: buffer ? null : 'utf8',
    stdio: ['ignore', 'pipe', 'pipe'],
    maxBuffer: 64 * 1024 * 1024,
  });
}

const sha256 = bytes => crypto.createHash('sha256').update(bytes).digest('hex');

function validateRelativePath(value) {
  return typeof value === 'string' && value.length > 0 && value.length <= 240 &&
    !path.isAbsolute(value) && !value.split(/[\\/]+/).includes('..') &&
    !/[\0\r\n]/.test(value);
}

function validateLayout(layout = LAYOUT) {
  if (!layout || layout.schema !== 'screeps-archived-tool-base-layout/v1' ||
      layout.sourceRef !== REF || layout.sourceTree !== TREE ||
      !Array.isArray(layout.files) || layout.files.length !== 25) {
    fail('TOOL_BASE_LAYOUT_INVALID');
  }
  const archives = new Set();
  const outputs = new Set();
  for (const item of layout.files) {
    if (!item || !validateRelativePath(item.archive) || !validateRelativePath(item.output) ||
        !item.archive.endsWith(layout.archiveSuffix) || archives.has(item.archive) || outputs.has(item.output)) {
      fail('TOOL_BASE_LAYOUT_INVALID', { item });
    }
    archives.add(item.archive);
    outputs.add(item.output);
  }
  for (const test of layout.baseTestFiles || []) {
    if (!outputs.has(test) || !test.startsWith('tests/') || !test.endsWith('.spec.cjs')) {
      fail('TOOL_BASE_TEST_LAYOUT_INVALID', { path: test });
    }
  }
  for (const support of layout.baseSupportFilesUnderTests || []) {
    if (!outputs.has(support) || !support.startsWith('tests/')) {
      fail('TOOL_BASE_TEST_LAYOUT_INVALID', { path: support });
    }
  }
  return { archives, outputs };
}

function copyTree(source, destination) {
  for (const entry of fs.readdirSync(source, { withFileTypes: true })) {
    const from = path.join(source, entry.name);
    const to = path.join(destination, entry.name);
    if (entry.isDirectory()) {
      fs.mkdirSync(to, { recursive: true, mode: 0o700 });
      copyTree(from, to);
    } else if (entry.isFile()) {
      fs.mkdirSync(path.dirname(to), { recursive: true, mode: 0o700 });
      fs.copyFileSync(from, to);
    }
  }
}

function main() {
  const requested = options(process.argv.slice(2));
  const repo = path.resolve(requested.repo);
  const out = path.resolve(requested.out);
  if (fs.existsSync(out)) fail('OUTPUT_ALREADY_EXISTS');

  const { archives } = validateLayout();
  const tree = git(repo, ['rev-parse', `${REF}:${BASE}`]).toString().trim();
  if (tree !== TREE) fail('TOOL_BASE_TREE_MISMATCH');

  const listed = git(repo, ['ls-tree', '-r', '--name-only', REF, '--', BASE])
    .toString().trim().split(/\r?\n/).filter(Boolean);
  const relativeArchives = listed.map(full => full.slice((BASE + '/').length));
  if (relativeArchives.length !== archives.size ||
      relativeArchives.some(name => !archives.has(name)) ||
      [...archives].some(name => !relativeArchives.includes(name))) {
    fail('TOOL_BASE_ARCHIVE_SET_MISMATCH', {
      expected: archives.size,
      actual: relativeArchives.length,
    });
  }

  fs.mkdirSync(out, { recursive: false, mode: 0o700 });
  const materialized = [];
  for (const item of LAYOUT.files) {
    const full = `${BASE}/${item.archive}`;
    const raw = git(repo, ['show', `${REF}:${full}`], { buffer: true });
    const normalized = Buffer.from(raw.toString('utf8').replace(/\r\n/g, '\n'), 'utf8');
    const destination = path.join(out, item.output);
    fs.mkdirSync(path.dirname(destination), { recursive: true, mode: 0o700 });
    fs.writeFileSync(destination, normalized, { mode: 0o600 });
    materialized.push(item.output);
  }

  copyTree(path.join(ROOT, 'implementation', 'toolkit-overlay'), out);
  const manifest = JSON.parse(fs.readFileSync(path.join(ROOT, 'IMPLEMENTATION-MANIFEST.json'), 'utf8'));
  for (const file of manifest.toolkitOverlay) {
    const bytes = fs.readFileSync(path.join(out, file.path));
    if (sha256(bytes) !== file.sha256) fail('TOOLKIT_OVERLAY_HASH_MISMATCH', { path: file.path });
  }

  fs.writeFileSync(path.join(out, 'IMPLEMENTATION-APPLIED.json'), JSON.stringify({
    status: 'COMPLETE_IMPLEMENTATION_MATERIALIZED',
    sourceRef: REF,
    sourceTree: TREE,
    baseFiles: materialized.length,
    overlayFiles: manifest.toolkitOverlay.length,
    baseTestFiles: LAYOUT.baseTestFiles,
    baseSupportFilesUnderTests: LAYOUT.baseSupportFilesUnderTests,
  }, null, 2) + '\n', { mode: 0o600 });

  console.log(JSON.stringify({
    status: 'COMPLETE_IMPLEMENTATION_MATERIALIZED',
    out,
    baseFiles: materialized.length,
    overlayFiles: manifest.toolkitOverlay.length,
    baseTestsMappedUnderTests: LAYOUT.baseTestFiles.length,
  }));
}

module.exports = { validateLayout };
if (require.main === module) {
  try {
    main();
  } catch (error) {
    process.stderr.write(JSON.stringify({
      error: error.code || String(error.message || 'MATERIALIZE_FAILED'),
      details: error.details || {},
    }) + '\n');
    process.exitCode = 1;
  }
}
