#!/usr/bin/env node
'use strict';

const fs = require('node:fs');
const path = require('node:path');
const cp = require('node:child_process');
const crypto = require('node:crypto');

const ROOT = path.resolve(__dirname, '..');
const BASE_TESTS = Object.freeze([
  'tests/collector-process.spec.cjs',
  'tests/diagnostics-watch.spec.cjs',
  'tests/probe-verifier.spec.cjs',
  'tests/session-classification.spec.cjs',
]);
const IMPLEMENTATION_TESTS = Object.freeze([
  'tests/common-atomic.spec.cjs',
  'tests/guard-control.spec.cjs',
  'tests/guard-probe.spec.cjs',
]);
const EXPECTED_TESTS = 41;

function fail(code, details = {}) {
  const error = new Error(code);
  error.code = code;
  error.details = details;
  throw error;
}

function kitArgument(argv) {
  const index = argv.indexOf('--kit');
  if (index < 0 || !argv[index + 1]) fail('MISSING_KIT');
  return path.resolve(argv[index + 1]);
}

const sha256 = bytes => crypto.createHash('sha256').update(bytes).digest('hex');

function main() {
  const kit = kitArgument(process.argv.slice(2));
  const manifest = JSON.parse(fs.readFileSync(path.join(ROOT, 'IMPLEMENTATION-MANIFEST.json'), 'utf8'));

  for (const file of manifest.toolkitOverlay) {
    const target = path.join(kit, file.path);
    if (!fs.existsSync(target) || sha256(fs.readFileSync(target)) !== file.sha256) {
      fail('IMPLEMENTATION_BYTES_MISMATCH', { path: file.path });
    }
    cp.execFileSync(process.execPath, ['--check', target], { stdio: 'ignore' });
  }

  const guard = fs.readFileSync(path.join(kit, 'deadline-guard.cjs'), 'utf8');
  const probe = fs.readFileSync(path.join(kit, 'guard-probe.cjs'), 'utf8');
  if (guard.includes('guard_read_or_channel_failure')) fail('GENERIC_GUARD_REASON_REMAINS');
  if (!guard.includes('readJsonArtifact')) fail('RESILIENT_ARTIFACT_READ_MISSING');
  if (probe.includes('.setCode(') || probe.includes('restore-modules')) fail('PROBE_NOT_READ_ONLY');

  const relativeTests = [...BASE_TESTS, ...IMPLEMENTATION_TESTS];
  const tests = relativeTests.map(relative => {
    const target = path.join(kit, relative);
    if (!fs.existsSync(target) || !fs.statSync(target).isFile()) {
      fail('TOOLKIT_TEST_MISSING', { path: relative });
    }
    return target;
  });

  const result = cp.spawnSync(process.execPath, ['--test', ...tests], {
    encoding: 'utf8',
    maxBuffer: 16 * 1024 * 1024,
  });
  if (result.status !== 0) {
    fail('TOOLKIT_TESTS_FAILED', {
      status: result.status,
      signal: result.signal || null,
      stdoutBytes: Buffer.byteLength(result.stdout || ''),
      stderrBytes: Buffer.byteLength(result.stderr || ''),
    });
  }

  const total = result.stdout.match(/# tests (\d+)/);
  const passed = result.stdout.match(/# pass (\d+)/);
  const failed = result.stdout.match(/# fail (\d+)/);
  if (!total || !passed || !failed || Number(total[1]) !== EXPECTED_TESTS ||
      total[1] !== passed[1] || failed[1] !== '0') {
    fail('TOOLKIT_TEST_COUNT_INVALID', {
      expected: EXPECTED_TESTS,
      tests: total ? Number(total[1]) : null,
      passed: passed ? Number(passed[1]) : null,
      failed: failed ? Number(failed[1]) : null,
    });
  }

  console.log(JSON.stringify({
    status: 'COMPLETE_IMPLEMENTATION_VERIFIED',
    tests: Number(total[1]),
    passed: Number(passed[1]),
    failed: 0,
    baseTestFiles: BASE_TESTS.length,
    implementationTestFiles: IMPLEMENTATION_TESTS.length,
  }));
}

try {
  main();
} catch (error) {
  process.stderr.write(JSON.stringify({
    error: error.code || String(error.message || 'VERIFY_TOOLKIT_FAILED'),
    details: error.details || {},
  }) + '\n');
  process.exitCode = 1;
}
