# Treasury Legacy Read Bridge I — Online Observation 0002
## Evidence & Guard Remediation I · Complete Implementation Verification Run v2

**本任务包已包含完整实现。执行 Agent 的角色仅为：应用固定字节、运行测试、执行只读联合探针、保存原始证据并报告结果。**

Agent 不负责设计、补写、改进或修复实现。任一步失败时，保留失败原件并停止；不得现场修改本包源码、添加测试以“修绿”、放宽门禁或重新打包。

本包完整取代两类旧包：先前“由 Agent 补齐实现”的版本，以及 SHA-256
`a70d615bbddc22056172ce93b7674a868061769c8f607f58be470f2613583842` 的首个完整实现版。
后者存在固定 transform 产物被自身 verifier 拒绝的确定性矛盾；详见 `SUPERSEDES.md`。
不得继续使用旧包。

---

## 1. 固定基线

仓库：`ceyirelehe47/screeps-bot`

```text
refactor/empire-treasury-rearchitecture
  d6445029e445a09237752cba205baa6b647a7ce0

compat/treasury-read-bridge-i
  fcfc125f0e5cd6c3370318b4fee0450f4d09af53

compat 默认 OFF tree
  cc2f08f676f28a329a78c971e7b066bb83b49658

只用于构造无上传探针 session 的既有 profile commit
  104e47b9d55adedc35f484045ef333fabb6073f4
```

启动后执行：

```bash
git -C "$REFACTOR_REPO" fetch origin
git -C "$COMPAT_REPO" fetch origin

git -C "$REFACTOR_REPO" rev-parse HEAD
git -C "$REFACTOR_REPO" rev-parse origin/refactor/empire-treasury-rearchitecture
git -C "$COMPAT_REPO" rev-parse HEAD
git -C "$COMPAT_REPO" rev-parse origin/compat/treasury-read-bridge-i

git -C "$REFACTOR_REPO" status --short
git -C "$COMPAT_REPO" status --short
```

两工作树必须干净且本地/远端 SHA 与上表一致。任一漂移，停止并报告 `BASELINE_DRIFT`。禁止 rebase、merge、reset、amend、cherry-pick 或 force-push。

本轮**没有任何候选上传授权**；compat 分支不得产生新提交。

---

## 2. 已完成实现的组成

### 2.1 Repository evidence remediation

`tools/apply-repository-remediation.cjs` 已完整实现并固定以下变更：

- 纠正 `REPORT.md` 与 `guard-failure-analysis.md` 中不受原始证据支持的网络/WS 根因表述；
- 明确 guard 只可判为“控制通路发生未分类异常，具体来源未知”；
- 纠正 refactor 分支起点/证据提交 SHA；
- 从当前树删除三份完整 `backup.json`，同时明确 Git 历史 blob 不会因线性删除消失；
- 如实保留上一轮 24 项测试源码未入库、无法从 Git 逆向恢复的证据缺口；
- 写入本轮完整 Guard 实现的独立测试源码和实现说明。

脚本按当前 Git blob 锁定输入；不接受模糊匹配或漂移后的文件。v2 中，applier 在写入前会先把
完整目标文本交给与最终 verifier 共用的 `tools/remediation-policy.cjs`；目标策略不通过时，
即使使用 `--apply` 也不会接触工作树。

### 2.2 Guard control-plane implementation

`implementation/toolkit-overlay/` 保存完整替换文件，不是设计稿：

```text
common.cjs
deadline-guard.cjs
guard-control.cjs
guard-probe.cjs
tests/common-atomic.spec.cjs
tests/guard-control.spec.cjs
tests/guard-probe.spec.cjs
```

实现包括：

- HTTP/tick 每周期最多 3 次尝试，单次最多 2500ms，退避 250ms / 750ms；
- 一个完整失败周期进入 `degraded`，第二个连续失败周期 fail-closed；
- 距最后成功 tick 读取超过 45 秒时 fail-closed；
- transport、deadline、payload、artifact read/write、restore dispatch、内部异常分别分类；
- heartbeat、collector-result、upload-attempt JSON 读取使用有限重试，不再静默吞掉读取异常；
- 诊断不保存原 message/stack，只保存稳定错误码、阶段、真实 UTF-8 字节上限内的脱敏摘要哈希；
- 联合探针要求 collector PID 不变、CPU 与 console 通道持续新鲜；
- 联合探针源码不包含 Screeps code 写、upload 或 restore；
- Guard 在写成功终态前先清理 lock，避免“文件声称成功但进程因 lock 清理失败退出”的矛盾证据；
- 上一轮 Windows `atomicJson` rename-over-open 修复已经合并进完整 `common.cjs`。

Agent 不需要也不允许重新应用或编辑补丁。

---

## 3. 包完整性、transform contract 与制作方实现测试

```bash
TASK="/absolute/path/to/this-package"
node "$TASK/tools/verify-package.cjs"
node "$TASK/tools/validate-transforms.cjs"
node "$TASK/tools/validate-materializer-layout.cjs"
node --test "$TASK/implementation/toolkit-overlay/tests"/*.spec.cjs
```

必须同时取得：

```text
PACKAGE_INTEGRITY_VERIFIED
REPOSITORY_TRANSFORM_CONTRACT_VERIFIED
  files=2
  replacements=11
  deletions=3
  reportPolicy=pass
  analysisPolicy=pass
  forbiddenMutantsRejected=2

TOOL_BASE_LAYOUT_CONTRACT_VERIFIED
  archivedFiles=25
  outputFiles=25
  baseTestsMappedUnderTests=4
  supportFilesMappedUnderTests=1
  flattenedMutantsRejected=1

25 tests
25 pass
0 fail
```

`validate-transforms.cjs` 会对 11 个固定 replacement 实际执行内存变换，再调用与最终
repository verifier 完全相同的 policy；并把两项禁用原串分别注入目标做反向对照。
`validate-materializer-layout.cjs` 会拒绝测试文件被扁平放到 toolkit 根目录。
任一结果不同，停止并报告 `PACKAGE_IMPLEMENTATION_TEST_FAILED`。不要修改实现。

---

## 4. 应用固定 Repository 整改字节

先只检查。该命令除了 Git HEAD/blob/工作树核验，还会对将要写入的完整 REPORT/analysis
目标文本执行最终 policy；输出必须包含 `targetPolicy:"pass"`：

```bash
node "$TASK/tools/apply-repository-remediation.cjs" \
  --repo "$REFACTOR_REPO"
```

预检通过后再应用：

```bash
node "$TASK/tools/apply-repository-remediation.cjs" \
  --repo "$REFACTOR_REPO" \
  --apply

node "$TASK/tools/verify-repository-remediation.cjs" \
  --repo "$REFACTOR_REPO"
```

随后使用本地真实凭据扫描三个历史 backup blob。输出只能写入新整改目录，不得输出或保存秘密值：

```bash
REMEDIATION_DIR="$REFACTOR_REPO/openspec/changes/empire-treasury-core-rewrite/evidence/legacy-read-bridge-i/online-observation-0002-collector-reliability-i/09-remediation"

node "$TASK/tools/scan-historical-backups.cjs" \
  --repo "$REFACTOR_REPO" \
  --secret "$SECRET" \
  --out "$REMEDIATION_DIR/historical-backup-secret-scan.json"
```

要求：

- 三份完整快照在当前树中均已删除；
- 报告明确披露历史 blob 仍存在；
- 扫描结果为 `HISTORICAL_BACKUP_SECRET_SCAN_CLEAN`；
- 不出现 token、token 前缀或匹配正文；
- `git diff --check` 通过。

真实秘密命中时停止，不提交，不自动轮换，只报告不含秘密值的类别与受影响 blob。

通过后做第一个线性提交，建议标题：

```text
evidence(compat): remediate observation-0002 history disclosure and unsupported causality
```

该提交只能落在既有 `legacy-read-bridge-i` evidence 路径下。记录其 SHA 为 `EVIDENCE_REMEDIATION_HEAD`。

---

## 5. 构造完整已实现 toolkit

本包不会让 Agent 应用实现补丁。materializer 从固定 Git tree 取出未改基底，再直接覆盖本包提供的完整实现文件，并按 SHA-256 校验每个输出字节。

```bash
TOOLKIT="/absolute/path/outside/all/git/worktrees/guard-remediation-implemented-toolkit"

node "$TASK/tools/materialize-toolkit.cjs" \
  --repo "$REFACTOR_REPO" \
  --out "$TOOLKIT"

node "$TASK/tools/verify-toolkit.cjs" \
  --kit "$TOOLKIT"
```

`materialize-toolkit.cjs` 会按 `references/TOOL-BASE-LAYOUT.json` 的 25 项固定映射恢复目录结构；4 个基底 spec 与 `collector-preload.cjs` 必须位于 `tests/`。`verify-toolkit` 随后按固定名单运行 `tests/` 下的 4 个基底 spec 与 3 个完整实现 spec。要求严格：

```text
41 tests
41 pass
0 fail
```

Windows 实机若暴露失败，保留 stdout/stderr/TAP 并停止，标签为 `IMPLEMENTATION_VERIFICATION_FAILED`；禁止 Agent 修代码。

---

## 6. 只读联合探针

只有第 3–5 节全部通过，才执行一次 25 分钟 collector + guard 联合无上传探针。

### 6.1 Detached 构建工作树

```bash
git -C "$COMPAT_REPO" worktree add --detach "$PROBE_BUILD" \
  104e47b9d55adedc35f484045ef333fabb6073f4
```

该 commit 只用于构造合法 session/candidate 快照，绝不上传。compat 主工作树必须始终停在 `fcfc125…`。

### 6.2 Git 外的新鲜前检与 session

```bash
PROBE_EXTERNAL="/absolute/path/outside/git/guard-probe-run"
mkdir "$PROBE_EXTERNAL"

node "$TOOLKIT/preflight-read.cjs" \
  --repo "$PROBE_BUILD" \
  --secret "$SECRET" \
  --out "$PROBE_EXTERNAL/preflight-before"

node "$TOOLKIT/prepare-session.cjs" \
  --repo "$PROBE_BUILD" \
  --preflight "$PROBE_EXTERNAL/preflight-before" \
  --run "$PROBE_EXTERNAL/run"
```

完整 `backup.json` 和 `candidate.json` 必须始终留在 Git 外。

### 6.3 Collector

```bash
(
  node "$TOOLKIT/console-collector.cjs" \
    --repo "$PROBE_BUILD" \
    --secret "$SECRET" \
    --run "$PROBE_EXTERNAL/run" \
    > "$PROBE_EXTERNAL/collector.stdout" \
    2> "$PROBE_EXTERNAL/collector.stderr"
  printf '%s\n' "$?" > "$PROBE_EXTERNAL/collector.exit.txt"
) &
printf '%s\n' "$!" > "$PROBE_EXTERNAL/collector.pid"
```

确认认证完成，console/CPU 均出现，且 `upload-attempt.json` 不存在。

### 6.4 已实现的联合 Guard probe

```bash
node "$TOOLKIT/guard-probe.cjs" \
  --repo "$PROBE_BUILD" \
  --secret "$SECRET" \
  --run "$PROBE_EXTERNAL/run" \
  --duration-ms 1500000 \
  --probe \
  > "$PROBE_EXTERNAL/guard-probe.stdout" \
  2> "$PROBE_EXTERNAL/guard-probe.stderr"

printf '%s\n' "$?" > "$PROBE_EXTERNAL/guard-probe.exit.txt"
```

禁止重启 collector、复用 runId、拼接多段数据或现场修改阈值。

### 6.5 探针后线上只读复核

```bash
node "$TOOLKIT/preflight-read.cjs" \
  --repo "$PROBE_BUILD" \
  --secret "$SECRET" \
  --out "$PROBE_EXTERNAL/preflight-after"

node "$TASK/tools/verify-joint-probe.cjs" \
  --run "$PROBE_EXTERNAL/run" \
  --before "$PROBE_EXTERNAL/preflight-before/preflight.json" \
  --after "$PROBE_EXTERNAL/preflight-after/preflight.json" \
  --out "$PROBE_EXTERNAL/joint-probe-verification.json"
```

独立验证要求：

- 持续时间至少 1,500,000ms；
- 成功 tick 读取不少于 98 次；
- 完整失败周期最多 1 次，结束时连续失败为 0；
- tick 不回退；
- collector PID/runId 全程不变；
- CPU 与 console 通道持续新鲜；
- collector 恰好一个 footer，`probe_complete`，exit 0；
- `upload-attempt.json` 从未出现；
- `codeWriteRequests=0`；
- 无 formal guard、restore 或 closing 产物；
- before/after 线上模块摘要、BUILD_COMMIT 完全一致。

探针失败时不得换窗口或重跑拼接，只保存失败原件。

---

## 7. 归档测试证据

新建：

```text
openspec/changes/empire-treasury-core-rewrite/evidence/legacy-read-bridge-i/
online-observation-0002-evidence-guard-remediation-i/
```

归档：

- 本任务包 ZIP、SHA-256、`IMPLEMENTATION-MANIFEST.json`；
- package verify、transform contract、materializer layout contract、25 项固定实现测试、完整 toolkit 测试的 stdout/stderr/TAP/exit；
- `IMPLEMENTATION-APPLIED.json`；
- 联合探针 collector/guard-probe stdout、stderr、PID、exit；
- heartbeat、console、collector-result、guard-probe-result、guard-probe JSONL；
- before/after **preflight.json 摘要**；
- `joint-probe-verification.json`；
- 最终秘密扫描和执行报告。

不要归档：

- 任一完整 `backup.json` 或 `candidate.json`；
- `.secret.json`；
- token 或任何 token 前缀；
- 全量 Memory；
- 未脱敏 HTTP header/body；
- 全机器进程命令行。

第二个线性提交只允许 evidence 路径变化，建议标题：

```text
evidence(compat): verify completed guard remediation implementation with joint no-upload probe
```

compat 分支不得提交任何变化。

---

## 8. 终态

全部通过：

```text
EVIDENCE_REMEDIATED
GUARD_CONTROL_PLANE_IMPLEMENTATION_VERIFIED
GUARD_COLLECTOR_CONTROL_PLANE_PROBE_VERIFIED
NOT_DEPLOYED
```

实现离线/Windows 验证失败：

```text
EVIDENCE_REMEDIATED
IMPLEMENTATION_VERIFICATION_FAILED
NOT_DEPLOYED
```

联合探针失败：

```text
EVIDENCE_REMEDIATED
GUARD_CONTROL_PLANE_IMPLEMENTATION_VERIFIED
GUARD_COLLECTOR_CONTROL_PLANE_PROBE_FAILED
NOT_DEPLOYED
```

任何结果都不得写成：

```text
ONLINE_COMPAT_READ_OBSERVED
TREASURY_PRODUCTION_READY
DEPLOYED
```

Agent 的职责是验证本包已完成实现，而不是继续开发。
