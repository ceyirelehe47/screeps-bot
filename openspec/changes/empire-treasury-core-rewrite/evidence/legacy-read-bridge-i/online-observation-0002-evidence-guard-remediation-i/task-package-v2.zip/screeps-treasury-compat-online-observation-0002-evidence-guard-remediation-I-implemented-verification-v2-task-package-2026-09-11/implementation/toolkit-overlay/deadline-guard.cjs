#!/usr/bin/env node
'use strict';
const fs=require('node:fs');const path=require('node:path');const {performance}=require('node:perf_hooks');
const C=require('./common.cjs');const {client}=require('./transport.cjs');
const {loadSession,triggerReason,heartbeatReason}=require('./session.cjs');const {runBounded}=require('./bounded-child.cjs');
const G=require('./guard-control.cjs');
async function main(argv) {
  const o=C.options(argv,['repo','secret','run'],['execute']);C.required(o,'repo','secret','run');
  if(!o.execute)C.fail('EXPLICIT_EXECUTE_REQUIRED_FOR_GUARD');
  const secret=C.loadSecret(o.secret),g=C.loadGuard(o.repo),s=loadSession(o.run,g);
  const file=n=>path.join(o.run,n),api=client(secret);
  C.writeNew(file('guard.lock'),{runId:s.runId,pid:process.pid});
  const begun=performance.now();let reason=null,lastTimeRead=-Infinity,tick,seenAttemptAt=null,attemptStart=null,initialElapsedMs=0;
  let auditFailed=false,lastCollectorAssessment=null,lastCollectorResult=null,stage='startup',failure=null;
  const timeChannel=G.createTimeChannelState();
  const record=x=>{try{C.audit(file('guard.jsonl'),x,secret.redact);}catch{auditFailed=true;}};
  const signal=()=>{reason='operator_stop';};process.once('SIGINT',signal);process.once('SIGTERM',signal);
  record({kind:'guard-start',runId:s.runId,pid:process.pid});
  try {
    while(!reason) {
      let h,attempt,collectorResult;
      stage='heartbeat_read';
      h=await G.readJsonArtifact(file('heartbeat.json'),16384);
      stage='collector_result_read';
      collectorResult=await G.readJsonArtifact(file('collector-result.json'),32768);
      stage='upload_attempt_read';
      if(fs.existsSync(file('upload-attempt.json'))) {
        attempt=await G.readJsonArtifact(file('upload-attempt.json'),16384,{required:true});
        if(attempt.runId!==s.runId||attempt.candidateHash!==s.candidate.digest.hash||!Number.isSafeInteger(attempt.startedAtMs)||attempt.startedAtMs>Date.now()+1000){reason='attempt_record_invalid';break;}
        if(seenAttemptAt===null){seenAttemptAt=performance.now();attemptStart=attempt.startedAtMs;initialElapsedMs=Math.max(0,Date.now()-attempt.startedAtMs);}
        if(attemptStart!==attempt.startedAtMs){reason='attempt_record_changed';break;}
      }
      if(auditFailed){reason='audit_io_failure';break;}
      stage='internal';
      const assessment=heartbeatReason(h,s,Date.now(),{collectorResult});
      const resultReason=collectorResult&&typeof collectorResult.reason==='string'?collectorResult.reason:null;
      if(assessment!==lastCollectorAssessment||resultReason!==lastCollectorResult){
        record({kind:'collector-health',assessment:assessment||'healthy',collectorState:h?.state??null,
          socketState:h?.socketState??null,collectorResult:resultReason});
        lastCollectorAssessment=assessment;lastCollectorResult=resultReason;
      }
      // Startup is bounded; no guard-ready is published before valid console activity.
      if(!attempt&&assessment&&performance.now()-begun<15000&&!assessment.startsWith('collector_exit_')
        &&assessment!=='collector_result_invalid'){await C.pause(250);continue;}
      const elapsed=seenAttemptAt===null?0:initialElapsedMs+performance.now()-seenAttemptAt;
      reason=triggerReason({session:s,heartbeat:h,collectorResult,now:Date.now(),attempt,
        elapsedSinceAttemptMs:elapsed,tick,closing:fs.existsSync(file('closing.json'))});
      if(reason)break;
      // Keep the tick watchdog fresh, but tolerate one bounded failed read cycle.
      if(attempt && performance.now()-lastTimeRead>=15000) {
        const budget=Math.max(1,Math.min(8000,s.wallLimitMs-(Date.now()-attempt.startedAtMs),s.wallLimitMs-elapsed));
        stage='game_time_read';
        const read=await G.readGameTimeResilient({api,shard:s.shard,budgetMs:budget,state:timeChannel,
          record,redact:secret.redact});
        lastTimeRead=performance.now();
        if(read.status==='terminal'){failure={...read.failure,timeChannel:read.state};reason=read.failure.reason;break;}
        if(read.status==='ok') {
          if(tick!==undefined&&read.time<tick){reason='game_tick_regressed';break;}
          tick=read.time;
          reason=triggerReason({session:s,heartbeat:h,collectorResult,now:Date.now(),attempt,
            elapsedSinceAttemptMs:elapsed,tick});if(reason)break;
        }
      }
      stage='guard_ready_write';
      C.atomicJson(file('guard-ready.json'),{runId:s.runId,pid:process.pid,updatedAtMs:Date.now(),state:'ready',
        collectorState:h.state,socketState:h.socketState??'legacy',
        controlPlane:timeChannel.consecutiveFailedCycles>0?'degraded':'healthy',
        timeChannel:G.timeChannelSnapshot(timeChannel)});
      await C.pause(500);
    }
  }catch(error){
    const classified=G.classifyGuardFailure(stage,error);
    failure={...classified,atMs:Date.now(),diagnostic:G.safeGuardDiagnostic(stage,error,secret.redact),
      timeChannel:G.timeChannelSnapshot(timeChannel)};
    reason=classified.reason;
    record({kind:'guard-control-failure',...failure});
  }
  record({kind:'close-trigger',reason,collectorResult:lastCollectorResult,failure});
  stage='closing_write';
  try{C.atomicJson(file('closing.json'),{runId:s.runId,reason,atMs:Date.now(),failure});}
  catch(error){auditFailed=true;if(!failure){const c=G.classifyGuardFailure(stage,error);
    failure={...c,atMs:Date.now(),diagnostic:G.safeGuardDiagnostic(stage,error,secret.redact)};}}
  try{C.atomicJson(file('guard-ready.json'),{runId:s.runId,pid:process.pid,state:'closing',updatedAtMs:Date.now(),
    controlPlane:'closing',timeChannel:G.timeChannelSnapshot(timeChannel),failure});}
  catch(error){auditFailed=true;if(!failure){const c=G.classifyGuardFailure(stage,error);
    failure={...c,atMs:Date.now(),diagnostic:G.safeGuardDiagnostic(stage,error,secret.redact)};}}
  stage='restore_dispatch';
  let outcome;
  try{outcome=await runBounded(process.execPath,[path.join(__dirname,'restore-modules.cjs'),'--repo',path.resolve(o.repo),
    '--secret',path.resolve(o.secret),'--run',path.resolve(o.run),'--execute'],{redact:secret.redact});}
  catch(error){const c=G.classifyGuardFailure(stage,error);
    failure={...c,atMs:Date.now(),diagnostic:G.safeGuardDiagnostic(stage,error,secret.redact)};
    outcome={code:null,childClosed:false,timedOut:false,killRequested:false,elapsedMs:0,stdout:''};}
  let result;try{result=JSON.parse(outcome.stdout.trim().split('\n').pop());}catch{}
  const restored=outcome.code===0&&outcome.childClosed&&!outcome.timedOut&&result?.confirmed===true
    &&['RESTORED_AND_VERIFIED','ALREADY_RESTORED'].includes(result.status)&&!result.auditFailed;
  record({kind:'guard-result',reason,restored,childClosed:outcome.childClosed,timedOut:outcome.timedOut,
    killRequested:outcome.killRequested,elapsedMs:outcome.elapsedMs,restoreStatus:result?.status||'NO_VALID_RESULT',
    collectorResult:lastCollectorResult,failure,timeChannel:G.timeChannelSnapshot(timeChannel)});
  try{fs.unlinkSync(file('guard.lock'));}
  catch(error){auditFailed=true;if(!failure){const c=G.classifyGuardFailure('closing_write',error);
    failure={...c,atMs:Date.now(),diagnostic:G.safeGuardDiagnostic('closing_write',error,secret.redact)};}}
  const terminal={status:restored&&!auditFailed?'ONLINE_BYTES_RESTORED':'ONLINE_CLOSE_UNCONFIRMED',
    runId:s.runId,reason,collectorResult:lastCollectorResult,restored,auditFailed,
    childClosed:outcome.childClosed,timedOut:outcome.timedOut,failure,
    timeChannel:G.timeChannelSnapshot(timeChannel)};
  try{C.atomicJson(file('guard-result.json'),terminal);}catch{terminal.auditFailed=true;terminal.status='ONLINE_CLOSE_UNCONFIRMED';}
  console.log(secret.redact(JSON.stringify(terminal)));
  process.exitCode=terminal.status==='ONLINE_BYTES_RESTORED'?0:6;
}
module.exports={main};if(require.main===module)C.entrypoint(()=>main(process.argv.slice(2)));
