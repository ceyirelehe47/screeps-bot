#!/usr/bin/env node
'use strict';

const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const ROOT = path.resolve(__dirname, '..');
const INTEGRITY_PATH = path.join(ROOT, 'INTEGRITY.json');

function fail(code, details = {}) {
  const error = new Error(code);
  error.code = code;
  error.details = details;
  throw error;
}

function walk(directory, prefix = '') {
  const files = [];
  for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
    const relative = prefix ? `${prefix}/${entry.name}` : entry.name;
    const absolute = path.join(directory, entry.name);
    if (entry.isDirectory()) files.push(...walk(absolute, relative));
    else if (entry.isFile() && relative !== 'INTEGRITY.json') files.push(relative);
  }
  return files.sort();
}

function main() {
  const data = JSON.parse(fs.readFileSync(INTEGRITY_PATH, 'utf8'));
  if (!data || data.schema !== 'screeps-task-package-integrity/v2' ||
      data.packageKind !== 'completed-implementation-verification' ||
      data.packageVersion !== 2 || data.implementationStatus !== 'complete' ||
      data.agentRole !== 'verification-only' || !Array.isArray(data.files)) {
    fail('PACKAGE_INTEGRITY_SCHEMA_INVALID');
  }

  const listed = data.files.map(file => file.path);
  if (new Set(listed).size !== listed.length || listed.some(value =>
      typeof value !== 'string' || !value || path.isAbsolute(value) || value.split('/').includes('..'))) {
    fail('PACKAGE_INTEGRITY_FILE_LIST_INVALID');
  }

  const actual = walk(ROOT);
  const expected = [...listed].sort();
  if (JSON.stringify(actual) !== JSON.stringify(expected)) {
    fail('PACKAGE_FILE_SET_MISMATCH', {
      missing: expected.filter(file => !actual.includes(file)),
      extra: actual.filter(file => !expected.includes(file)),
    });
  }

  for (const file of data.files) {
    const target = path.join(ROOT, file.path);
    const bytes = fs.readFileSync(target);
    if (!Number.isSafeInteger(file.bytes) || file.bytes < 0 || bytes.length !== file.bytes ||
        typeof file.sha256 !== 'string' || !/^[a-f0-9]{64}$/.test(file.sha256) ||
        crypto.createHash('sha256').update(bytes).digest('hex') !== file.sha256) {
      fail('PACKAGE_INTEGRITY_MISMATCH', { path: file.path });
    }
  }

  console.log(JSON.stringify({
    status: 'PACKAGE_INTEGRITY_VERIFIED',
    files: data.files.length,
    implementationStatus: 'complete',
    agentRole: 'verification-only',
    packageVersion: 2,
    exactFileSet: true,
  }));
}

try {
  main();
} catch (error) {
  process.stderr.write(JSON.stringify({
    error: error.code || String(error.message || 'PACKAGE_VERIFY_FAILED'),
    details: error.details || {},
  }) + '\n');
  process.exitCode = 1;
}
