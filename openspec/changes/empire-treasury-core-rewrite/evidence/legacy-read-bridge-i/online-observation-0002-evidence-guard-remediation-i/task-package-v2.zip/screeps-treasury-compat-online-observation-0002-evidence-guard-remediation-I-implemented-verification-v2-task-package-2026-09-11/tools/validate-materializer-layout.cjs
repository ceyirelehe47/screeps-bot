#!/usr/bin/env node
'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { validateLayout } = require('./materialize-toolkit.cjs');

const ROOT = path.resolve(__dirname, '..');
const layout = JSON.parse(fs.readFileSync(path.join(ROOT, 'references', 'TOOL-BASE-LAYOUT.json'), 'utf8'));

function fail(code, details = {}) {
  const error = new Error(code);
  error.code = code;
  error.details = details;
  throw error;
}

function main() {
  const { archives, outputs } = validateLayout(layout);
  const expectedTests = [
    'tests/collector-process.spec.cjs',
    'tests/diagnostics-watch.spec.cjs',
    'tests/probe-verifier.spec.cjs',
    'tests/session-classification.spec.cjs',
  ];
  const expectedSupport = ['tests/collector-preload.cjs'];
  for (const file of [...expectedTests, ...expectedSupport]) {
    if (!outputs.has(file)) fail('EXPECTED_TEST_MAPPING_MISSING', { file });
  }
  for (const forbidden of [
    'collector-process.spec.cjs',
    'diagnostics-watch.spec.cjs',
    'probe-verifier.spec.cjs',
    'session-classification.spec.cjs',
    'collector-preload.cjs',
  ]) {
    if (outputs.has(forbidden)) fail('FLATTENED_TEST_MAPPING_REMAINS', { file: forbidden });
  }

  const mutant = JSON.parse(JSON.stringify(layout));
  const mutated = mutant.files.find(item => item.archive === 'collector-process.spec.cjs.original-as-shipped');
  mutated.output = 'collector-process.spec.cjs';
  let flattenedMutantRejected = false;
  try {
    validateLayout(mutant);
  } catch (error) {
    flattenedMutantRejected = error && error.code === 'TOOL_BASE_TEST_LAYOUT_INVALID';
  }
  if (!flattenedMutantRejected) fail('FLATTENED_LAYOUT_NEGATIVE_CONTROL_FAILED');

  console.log(JSON.stringify({
    status: 'TOOL_BASE_LAYOUT_CONTRACT_VERIFIED',
    archivedFiles: archives.size,
    outputFiles: outputs.size,
    baseTestsMappedUnderTests: expectedTests.length,
    supportFilesMappedUnderTests: expectedSupport.length,
    flattenedMutantsRejected: 1,
  }));
}

try {
  main();
} catch (error) {
  process.stderr.write(JSON.stringify({
    error: error.code || String(error.message || 'LAYOUT_VALIDATION_FAILED'),
    details: error.details || {},
  }) + '\n');
  process.exitCode = 1;
}
