#!/usr/bin/env node
'use strict';
const fs=require('node:fs');const path=require('node:path');const {performance}=require('node:perf_hooks');
const C=require('./common.cjs');const G=require('./guard-control.cjs');

const MIN_PROBE_MS=1200000;
const MAX_PROBE_MS=1800000;
const TIME_INTERVAL_MS=15000;
const STARTUP_GRACE_MS=15000;
const COLLECTOR_CLOSE_WAIT_MS=15000;

function expectedMinimumTimeReads(durationMs) {
  return Math.max(1,Math.floor(durationMs/TIME_INTERVAL_MS)-2);
}
function validateProbeTerminal(result,session,reason='probe_complete') {
  return !!result&&result.kind==='collector-result-v2'&&result.runId===session.runId
    &&result.status==='closed'&&result.reason===reason&&result.exitCode===0&&result.footerWritten===true;
}
function additionalJointHeartbeatReason(heartbeat,now,{expectedPid=null,maxSilenceMs=45000}={}) {
  if(!heartbeat||typeof heartbeat!=='object')return null;
  if(expectedPid!==null&&heartbeat.pid!==expectedPid)return 'collector_pid_changed';
  if(!Number.isFinite(heartbeat.lastCpuAtMs))return 'collector_cpu_never_seen';
  if(heartbeat.lastCpuAtMs>now+1000||now-heartbeat.lastCpuAtMs>maxSilenceMs)return 'collector_cpu_silent';
  return null;
}
function requestCollectorStop(file,session,reason,now=Date.now()) {
  const value={runId:session.runId,reason,requestedAtMs:now,requestedByPid:process.pid};
  if(fs.existsSync(file)) {
    const existing=C.readJson(file,16384);
    if(existing.runId!==value.runId||existing.reason!==reason)C.fail('COLLECTOR_STOP_REQUEST_CONFLICT');
    return false;
  }
  C.writeNew(file,value);
  return true;
}
async function waitForCollectorResult(file,session,{timeoutMs=COLLECTOR_CLOSE_WAIT_MS,pause=C.pause,clock=()=>performance.now()}={}) {
  const end=clock()+timeoutMs;
  while(clock()<end) {
    if(fs.existsSync(file)) {
      let result;
      try{result=C.readJson(file,32768);}catch{return {status:'invalid',result:null};}
      return {status:validateProbeTerminal(result,session)?'ok':'unexpected',result};
    }
    await pause(250);
  }
  return {status:'timeout',result:null};
}
async function runProbe({repo,secretPath,run,durationMs}) {
  const {client}=require('./transport.cjs');
  const {loadSession,heartbeatReason}=require('./session.cjs');
  const secret=C.loadSecret(secretPath),guard=C.loadGuard(repo),session=loadSession(run,guard);
  const file=name=>path.join(run,name),api=client(secret);
  if(fs.existsSync(file('upload-attempt.json')))C.fail('PROBE_UPLOAD_ATTEMPT_PRESENT');
  C.writeNew(file('guard-probe.lock'),{runId:session.runId,pid:process.pid,startedAtMs:Date.now()});
  let auditFailed=false;
  const record=value=>{try{C.audit(file('guard-probe.jsonl'),value,secret.redact);}catch{auditFailed=true;}};
  const started=performance.now(),startedAtMs=Date.now(),timeChannel=G.createTimeChannelState(startedAtMs);
  let lastTimeRead=-Infinity,lastTick=null,reason=null,failure=null,collectorResult=null;
  let collectorPid=null,lastHeartbeat=null,stage='startup';
  const signal=()=>{reason='operator_stop';};
  process.once('SIGINT',signal);process.once('SIGTERM',signal);
  record({kind:'guard-probe-start',runId:session.runId,pid:process.pid,durationMs});
  try {
    while(!reason&&performance.now()-started<durationMs) {
      if(fs.existsSync(file('upload-attempt.json'))){reason='probe_upload_attempt_detected';break;}
      stage='heartbeat_read';
      const heartbeat=await G.readJsonArtifact(file('heartbeat.json'),16384);
      lastHeartbeat=heartbeat||lastHeartbeat;
      stage='collector_result_read';
      collectorResult=await G.readJsonArtifact(file('collector-result.json'),32768);
      let assessment=heartbeatReason(heartbeat,session,Date.now(),{collectorResult});
      if(!assessment)assessment=additionalJointHeartbeatReason(heartbeat,Date.now(),{expectedPid:collectorPid});
      if(!assessment&&collectorPid===null)collectorPid=heartbeat.pid;
      if(assessment) {
        if(performance.now()-started<STARTUP_GRACE_MS&&!assessment.startsWith('collector_exit_')
          &&assessment!=='collector_result_invalid'){await C.pause(250);continue;}
        reason=assessment;break;
      }
      if(performance.now()-lastTimeRead>=TIME_INTERVAL_MS) {
        stage='game_time_read';
        const read=await G.readGameTimeResilient({api,shard:session.shard,budgetMs:8000,state:timeChannel,
          record,redact:secret.redact});
        lastTimeRead=performance.now();
        if(read.status==='terminal'){reason=read.failure.reason;failure={...read.failure,timeChannel:read.state};break;}
        if(read.status==='ok') {
          if(lastTick!==null&&read.time<lastTick){reason='game_tick_regressed';break;}
          lastTick=read.time;
        }
      }
      stage='guard_ready_write';
      C.atomicJson(file('guard-probe-ready.json'),{runId:session.runId,pid:process.pid,state:'running',
        updatedAtMs:Date.now(),elapsedMs:Math.floor(performance.now()-started),lastTick,
        controlPlane:timeChannel.consecutiveFailedCycles>0?'degraded':'healthy',
        timeChannel:G.timeChannelSnapshot(timeChannel)});
      await C.pause(500);
    }
    if(!reason&&performance.now()-started>=durationMs)reason='probe_complete';
  } catch(error) {
    const classified=G.classifyGuardFailure(stage,error);
    reason=classified.reason;
    failure={...classified,diagnostic:G.safeGuardDiagnostic(stage,error,secret.redact),
      timeChannel:G.timeChannelSnapshot(timeChannel)};
    record({kind:'guard-probe-control-failure',...failure});
  }

  const cpuFresh=!!lastHeartbeat&&Number.isFinite(lastHeartbeat.lastCpuAtMs)
    &&Date.now()-lastHeartbeat.lastCpuAtMs<=45000;
  const successful=reason==='probe_complete'&&!auditFailed
    &&timeChannel.totalSuccessfulReads>=expectedMinimumTimeReads(durationMs)
    &&timeChannel.totalFailedCycles<=1
    &&timeChannel.consecutiveFailedCycles===0
    &&lastTick!==null
    &&Number.isSafeInteger(collectorPid)&&collectorPid>0
    &&cpuFresh
    &&!fs.existsSync(file('upload-attempt.json'));
  let stopResult={status:'not_requested',result:null};
  stage='closing_write';
  try {
    requestCollectorStop(file('collector-stop.json'),session,successful?'probe_complete':'operator_stop');
    stopResult=await waitForCollectorResult(file('collector-result.json'),session);
  } catch(error) {
    if(successful) {
      const classified=G.classifyGuardFailure('closing_write',error);
      reason=classified.reason;
      failure={...classified,diagnostic:G.safeGuardDiagnostic('closing_write',error,secret.redact)};
    }
  }
  const verified=successful&&stopResult.status==='ok';
  const terminal={
    kind:'guard-collector-control-plane-probe/v1',
    status:verified?'GUARD_COLLECTOR_CONTROL_PLANE_PROBE_VERIFIED':'GUARD_COLLECTOR_CONTROL_PLANE_PROBE_FAILED',
    runId:session.runId,reason:verified?'probe_complete':reason,
    startedAtMs,durationMs:Math.floor(performance.now()-started),lastTick,
    expectedMinimumTimeReads:expectedMinimumTimeReads(durationMs),
    timeChannel:G.timeChannelSnapshot(timeChannel),collectorTerminal:stopResult.status,
    collectorPid,cpuChannelVerified:cpuFresh,
    collectorResult:stopResult.result?{status:stopResult.result.status,reason:stopResult.result.reason,
      exitCode:stopResult.result.exitCode,footerWritten:stopResult.result.footerWritten}:null,
    uploadAttemptPresent:fs.existsSync(file('upload-attempt.json')),
    codeWriteRequests:0,auditFailed,failure,
  };
  try{fs.unlinkSync(file('guard-probe.lock'));}
  catch(error){const classified=G.classifyGuardFailure('closing_write',error);
    terminal.status='GUARD_COLLECTOR_CONTROL_PLANE_PROBE_FAILED';terminal.auditFailed=true;
    if(terminal.reason==='probe_complete')terminal.reason=classified.reason;
    if(!terminal.failure)terminal.failure={...classified,diagnostic:G.safeGuardDiagnostic('closing_write',error,secret.redact)};
  }
  try{C.writeNew(file('guard-probe-result.json'),terminal);}
  catch(error){const classified=G.classifyGuardFailure('closing_write',error);
    terminal.status='GUARD_COLLECTOR_CONTROL_PLANE_PROBE_FAILED';terminal.auditFailed=true;
    if(terminal.reason==='probe_complete')terminal.reason=classified.reason;
    if(!terminal.failure)terminal.failure={...classified,diagnostic:G.safeGuardDiagnostic('closing_write',error,secret.redact)};
  }
  console.log(secret.redact(JSON.stringify(terminal)));
  return terminal;
}
async function main(argv) {
  const o=C.options(argv,['repo','secret','run','duration-ms'],['probe']);
  C.required(o,'repo','secret','run','duration-ms');
  if(!o.probe)C.fail('EXPLICIT_PROBE_FLAG_REQUIRED');
  const durationMs=Number(o['duration-ms']);
  C.integer(durationMs,MIN_PROBE_MS,MAX_PROBE_MS,'PROBE_DURATION_INVALID');
  const result=await runProbe({repo:path.resolve(o.repo),secretPath:path.resolve(o.secret),
    run:path.resolve(o.run),durationMs});
  process.exitCode=result.status==='GUARD_COLLECTOR_CONTROL_PLANE_PROBE_VERIFIED'?0:6;
}
module.exports={expectedMinimumTimeReads,validateProbeTerminal,additionalJointHeartbeatReason,requestCollectorStop,waitForCollectorResult,runProbe,main};
if(require.main===module)C.entrypoint(()=>main(process.argv.slice(2)));
