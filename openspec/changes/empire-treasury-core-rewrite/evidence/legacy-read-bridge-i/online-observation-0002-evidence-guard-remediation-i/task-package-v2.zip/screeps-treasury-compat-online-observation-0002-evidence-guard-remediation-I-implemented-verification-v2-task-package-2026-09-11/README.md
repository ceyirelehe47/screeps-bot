# Evidence & Guard Remediation I — Completed Implementation Package v2

此包采用“实现者交付固定实现，执行 Agent 只做验证”的分工，并完整取代 SHA-256
`a70d615b…3842` 的旧版包。作废原因与修复见 `SUPERSEDES.md`。

v2 新增了 repository transform 的同策略全链契约检查：固定 replacement 的目标文本
必须先通过与最终 repository verifier 完全相同的 policy，才允许接触用户工作树。

包内已提供：

- 完整 Guard 控制面实现及固定测试源码；
- 确定性 repository 证据整改程序；
- 共享的 apply/verify remediation policy；
- transform 正向契约与禁用串反向对照；
- 固定 25 文件 archive→toolkit 路径映射，并将 4 个基底 spec 与 preload 恢复到 `tests/`；
- `tests/` 下 4 个基底 spec + 3 个实现 spec 的严格 41/41 toolkit 验证；
- 联合无上传探针与结果验证器。

Agent 发现任何失败时只能保存证据并停止，不能现场修复、放宽门禁或上传候选。
本轮不授权 Screeps 候选上传。完整说明见 `AGENT-RUN.md`。
