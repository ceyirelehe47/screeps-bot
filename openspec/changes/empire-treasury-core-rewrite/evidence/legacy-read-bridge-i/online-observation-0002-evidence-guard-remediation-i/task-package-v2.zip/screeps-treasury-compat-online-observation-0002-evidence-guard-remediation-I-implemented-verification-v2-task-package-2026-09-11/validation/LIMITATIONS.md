# 制作方验证边界（v2）

制作方已经完成 Guard 控制面源码、联合探针、确定性 Repository 整改程序与 25 项测试的实现。

针对旧包暴露的矛盾，v2 已额外完成：

- 复现旧 transform 目标与旧 verifier 的必然冲突；
- 让 repository applier 在写入前调用最终 verifier 共用的 remediation policy；
- 对 11 个固定 replacement 逐项实际执行内存变换；
- 将组合目标交给同一 policy 校验；
- 注入两项禁用串并确认均被同一 policy 拒绝；
- 核对固定 Git tree 的 25 个归档文件名，使用显式 archive→output 映射恢复 `tests/` 目录；
- 用该真实输出布局构造合成 toolkit，确认 `tests/` 下 4 个基底 spec 与 3 个实现 spec 合计严格 41/41。

以下项目仍故意留给执行 Agent 作为实机测验与取证，不代表实现责任仍在 Agent：

- 在用户真实 Git 工作树上核验 pinned blob 并执行整改；
- Windows 文件锁与进程行为复测；
- 使用当前本地凭据扫描三个历史 backup blob；
- 官方服 25 分钟 collector + guard 联合无上传探针；
- 将测试输出和在线只读摘要归档为新的 evidence 提交。

执行 Agent 不得修改实现；失败即报告。
