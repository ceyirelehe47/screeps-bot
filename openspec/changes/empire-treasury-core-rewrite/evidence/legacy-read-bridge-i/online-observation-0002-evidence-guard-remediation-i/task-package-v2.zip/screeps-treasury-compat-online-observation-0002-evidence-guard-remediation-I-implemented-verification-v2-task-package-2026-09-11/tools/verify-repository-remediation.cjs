#!/usr/bin/env node
'use strict';

const fs = require('node:fs');
const path = require('node:path');
const cp = require('node:child_process');
const POLICY = require('./remediation-policy.cjs');

const ROOT = path.resolve(__dirname, '..');
const SPEC = JSON.parse(fs.readFileSync(path.join(ROOT, 'implementation', 'repository', 'transforms.json'), 'utf8'));

function fail(code, details = {}) {
  const error = new Error(code);
  error.code = code;
  error.details = details;
  throw error;
}

function repoArgument(argv) {
  const index = argv.indexOf('--repo');
  if (index < 0 || !argv[index + 1]) fail('MISSING_REPO');
  return path.resolve(argv[index + 1]);
}

function git(repo, args) {
  return cp.execFileSync('git', ['-C', repo, ...args], {
    encoding: 'utf8',
    stdio: ['ignore', 'pipe', 'pipe'],
  }).trim();
}

function main() {
  const repo = repoArgument(process.argv.slice(2));

  for (const item of SPEC.deletions) {
    if (fs.existsSync(path.join(repo, item.path))) fail('FULL_BACKUP_STILL_PRESENT', { path: item.path });
  }

  const report = fs.readFileSync(path.join(repo, SPEC.files[0].path), 'utf8');
  const analysis = fs.readFileSync(path.join(repo, SPEC.files[1].path), 'utf8');
  POLICY.assertReportText(report);
  POLICY.assertAnalysisText(analysis);

  const add = path.join(repo, SPEC.addRoot);
  const requiredAdditions = [
    'IMPLEMENTATION.md',
    'IMPLEMENTATION-MANIFEST.json',
    'guard-verification-tests/common-atomic.spec.cjs',
    'guard-verification-tests/guard-control.spec.cjs',
    'guard-verification-tests/guard-probe.spec.cjs',
  ];
  for (const name of requiredAdditions) {
    if (!fs.existsSync(path.join(add, name))) fail('REMEDIATION_ADDITION_MISSING', { path: name });
  }

  cp.execFileSync('git', ['-C', repo, 'diff', '--check'], { stdio: ['ignore', 'pipe', 'pipe'] });
  console.log(JSON.stringify({
    status: 'REPOSITORY_REMEDIATION_VERIFIED',
    baseHead: SPEC.pinnedHead,
    currentHead: git(repo, ['rev-parse', 'HEAD']),
    deleted: SPEC.deletions.length,
    newTestFiles: 3,
    reportPolicy: 'pass',
    analysisPolicy: 'pass',
  }));
}

try {
  main();
} catch (error) {
  process.stderr.write(JSON.stringify({
    error: error.code || String(error.message || 'VERIFY_FAILED'),
    details: error.details || {},
  }) + '\n');
  process.exitCode = 1;
}
