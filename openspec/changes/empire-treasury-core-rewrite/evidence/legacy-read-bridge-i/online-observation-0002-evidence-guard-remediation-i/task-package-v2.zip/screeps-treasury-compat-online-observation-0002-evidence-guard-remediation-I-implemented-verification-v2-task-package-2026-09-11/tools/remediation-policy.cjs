'use strict';

const REPORT_REQUIRED_MARKERS = Object.freeze([
  '未分类控制通路异常',
  'collector 在 guard 触发关闭后仍持续收到 WebSocket 帧',
  '相关 blob 仍存在于 Git 历史',
]);

const REPORT_FORBIDDEN_CLAIMS = Object.freeze([
  '因外部网络中断 fail-closed',
  'collector 的 WS 帧在关闭前中断',
]);

const ANALYSIS_REQUIRED_MARKERS = Object.freeze([
  '具体来源未知',
  '10:21:35 – 10:21:56',
]);

function failure(code, details = {}) {
  const error = new Error(code);
  error.code = code;
  error.details = details;
  return error;
}

function assertReportText(report) {
  if (typeof report !== 'string') throw failure('REPORT_TEXT_INVALID');
  for (const marker of REPORT_REQUIRED_MARKERS) {
    if (!report.includes(marker)) throw failure('REPORT_REMEDIATION_MARKER_MISSING', { marker });
  }
  for (const forbidden of REPORT_FORBIDDEN_CLAIMS) {
    if (report.includes(forbidden)) throw failure('REPORT_FORBIDDEN_CLAIM_REMAINS', { forbidden });
  }
  return true;
}

function assertAnalysisText(analysis) {
  if (typeof analysis !== 'string') throw failure('ANALYSIS_TEXT_INVALID');
  for (const marker of ANALYSIS_REQUIRED_MARKERS) {
    if (!analysis.includes(marker)) throw failure('ANALYSIS_REMEDIATION_MISSING', { marker });
  }
  return true;
}

module.exports = {
  REPORT_REQUIRED_MARKERS,
  REPORT_FORBIDDEN_CLAIMS,
  ANALYSIS_REQUIRED_MARKERS,
  assertReportText,
  assertAnalysisText,
};
