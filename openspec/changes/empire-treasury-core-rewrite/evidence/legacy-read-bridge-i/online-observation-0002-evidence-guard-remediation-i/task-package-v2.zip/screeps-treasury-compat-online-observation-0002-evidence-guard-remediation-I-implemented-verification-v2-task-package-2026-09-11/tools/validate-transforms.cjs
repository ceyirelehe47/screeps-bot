#!/usr/bin/env node
'use strict';

const fs = require('node:fs');
const path = require('node:path');
const POLICY = require('./remediation-policy.cjs');

const ROOT = path.resolve(__dirname, '..');
const SPEC = JSON.parse(fs.readFileSync(path.join(ROOT, 'implementation', 'repository', 'transforms.json'), 'utf8'));

function fail(code, details = {}) {
  const error = new Error(code);
  error.code = code;
  error.details = details;
  throw error;
}

function replaceOne(text, oldValue, newValue, file) {
  const first = text.indexOf(oldValue);
  if (first < 0) fail('EXPECTED_SOURCE_TEXT_MISSING', { file });
  if (text.indexOf(oldValue, first + oldValue.length) >= 0) fail('EXPECTED_SOURCE_TEXT_NOT_UNIQUE', { file });
  return text.slice(0, first) + newValue + text.slice(first + oldValue.length);
}

function applySyntheticFile(file) {
  // Exercise every exact pinned source fragment independently with the same
  // uniqueness rule used by the repository applier, then verify the combined
  // deterministic target text with the production remediation policy.
  return file.replacements.map((replacement, index) => {
    const source = `<!-- package-contract-fragment-${index} -->\n${replacement.old}\n<!-- package-contract-end-${index} -->`;
    const transformed = replaceOne(source, replacement.old, replacement.new, file.path);
    if (!transformed.includes(replacement.new)) fail('TARGET_FRAGMENT_MISSING_AFTER_TRANSFORM', { file: file.path });
    return transformed;
  }).join('\n\n');
}

function expectPolicyRejection(text, forbidden) {
  let rejected = false;
  try {
    POLICY.assertReportText(text + '\n' + forbidden);
  } catch (error) {
    rejected = error && error.code === 'REPORT_FORBIDDEN_CLAIM_REMAINS';
  }
  if (!rejected) fail('REPORT_POLICY_NEGATIVE_CONTROL_FAILED', { forbidden });
}

function main() {
  if (!SPEC || SPEC.schema !== 'screeps-repository-remediation-transforms/v1') fail('TRANSFORM_SCHEMA_INVALID');
  const paths = new Set();
  const rendered = new Map();

  for (const file of SPEC.files) {
    if (paths.has(file.path) || typeof file.gitBlob !== 'string' || !file.gitBlob ||
      !Array.isArray(file.replacements) || file.replacements.length === 0) {
      fail('TRANSFORM_INVALID', { file: file.path });
    }
    paths.add(file.path);
    const oldFragments = new Set();
    for (const replacement of file.replacements) {
      if (typeof replacement.old !== 'string' || !replacement.old ||
        typeof replacement.new !== 'string' || replacement.old === replacement.new ||
        oldFragments.has(replacement.old)) {
        fail('TRANSFORM_INVALID', { file: file.path });
      }
      oldFragments.add(replacement.old);
    }
    rendered.set(file.path, applySyntheticFile(file));
  }

  for (const deletion of SPEC.deletions) {
    if (paths.has(deletion.path) || typeof deletion.gitBlob !== 'string' || !deletion.gitBlob) {
      fail('DELETION_INVALID', { file: deletion.path });
    }
    paths.add(deletion.path);
  }

  const reportFile = SPEC.files.find(file => file.path.endsWith('/REPORT.md'));
  const analysisFile = SPEC.files.find(file => file.path.endsWith('/guard-failure-analysis.md'));
  if (!reportFile || !analysisFile) fail('TRANSFORM_TARGETS_MISSING');

  const report = rendered.get(reportFile.path);
  const analysis = rendered.get(analysisFile.path);
  POLICY.assertReportText(report);
  POLICY.assertAnalysisText(analysis);

  for (const forbidden of POLICY.REPORT_FORBIDDEN_CLAIMS) expectPolicyRejection(report, forbidden);

  console.log(JSON.stringify({
    status: 'REPOSITORY_TRANSFORM_CONTRACT_VERIFIED',
    files: SPEC.files.length,
    replacements: SPEC.files.reduce((count, file) => count + file.replacements.length, 0),
    deletions: SPEC.deletions.length,
    reportPolicy: 'pass',
    analysisPolicy: 'pass',
    forbiddenMutantsRejected: POLICY.REPORT_FORBIDDEN_CLAIMS.length,
  }));
}

try {
  main();
} catch (error) {
  process.stderr.write(JSON.stringify({
    error: error.code || String(error.message || 'TRANSFORM_VALIDATION_FAILED'),
    details: error.details || {},
  }) + '\n');
  process.exitCode = 1;
}
