#!/usr/bin/env node
'use strict';
const fs=require('node:fs');const path=require('node:path');const cp=require('node:child_process');
const ROOT=path.resolve(__dirname,'..');
const POLICY=require('./remediation-policy.cjs');
const SPEC=JSON.parse(fs.readFileSync(path.join(ROOT,'implementation','repository','transforms.json'),'utf8'));
function fail(code,details={}){const e=new Error(code);e.code=code;e.details=details;throw e;}
function args(argv){const out={apply:false};for(let i=0;i<argv.length;i++){const k=argv[i];if(k==='--apply'){out.apply=true;continue;}if(k==='--repo'&&argv[i+1]){out.repo=argv[++i];continue;}fail('INVALID_ARGUMENTS');}if(!out.repo)fail('MISSING_REPO');return out;}
function git(repo,a,{buffer=false}={}){try{return cp.execFileSync('git',['-C',repo,...a],{encoding:buffer?null:'utf8',stdio:['ignore','pipe','pipe'],maxBuffer:64*1024*1024}).toString().trim();}catch{fail('GIT_COMMAND_FAILED',{args:a});}}
function hashObject(repo,rel){return git(repo,['hash-object','--',rel]);}
function replaceOne(text,oldValue,newValue,file){const first=text.indexOf(oldValue);if(first<0)fail('EXPECTED_SOURCE_TEXT_MISSING',{file});if(text.indexOf(oldValue,first+oldValue.length)>=0)fail('EXPECTED_SOURCE_TEXT_NOT_UNIQUE',{file});return text.slice(0,first)+newValue+text.slice(first+oldValue.length);}
function copyTree(src,dst){for(const entry of fs.readdirSync(src,{withFileTypes:true})){const a=path.join(src,entry.name),b=path.join(dst,entry.name);if(entry.isDirectory()){fs.mkdirSync(b,{recursive:true,mode:0o700});copyTree(a,b);}else if(entry.isFile()){fs.mkdirSync(path.dirname(b),{recursive:true,mode:0o700});fs.copyFileSync(a,b);}}}
function main(){const o=args(process.argv.slice(2)),repo=path.resolve(o.repo);
  if(git(repo,['rev-parse','HEAD'])!==SPEC.pinnedHead)fail('BASELINE_DRIFT');
  if(git(repo,['branch','--show-current'])!==SPEC.branch)fail('WRONG_BRANCH');
  if(git(repo,['status','--porcelain']))fail('WORKTREE_NOT_CLEAN');
  const outputs=[];
  for(const file of SPEC.files){const abs=path.join(repo,file.path);if(!fs.existsSync(abs))fail('SOURCE_FILE_MISSING',{file:file.path});if(hashObject(repo,file.path)!==file.gitBlob)fail('SOURCE_BLOB_MISMATCH',{file:file.path});let text=fs.readFileSync(abs,'utf8');for(const r of file.replacements)text=replaceOne(text,r.old,r.new,file.path);outputs.push({path:file.path,text});}
  const reportOutput=outputs.find(item=>item.path.endsWith('/REPORT.md'));
  const analysisOutput=outputs.find(item=>item.path.endsWith('/guard-failure-analysis.md'));
  if(!reportOutput||!analysisOutput)fail('REMEDIATION_TARGETS_MISSING');
  POLICY.assertReportText(reportOutput.text);POLICY.assertAnalysisText(analysisOutput.text);
  const deletionBackups=[];
  for(const item of SPEC.deletions){const abs=path.join(repo,item.path);if(!fs.existsSync(abs))fail('DELETE_SOURCE_MISSING',{file:item.path});if(hashObject(repo,item.path)!==item.gitBlob)fail('DELETE_BLOB_MISMATCH',{file:item.path});deletionBackups.push({path:item.path,bytes:fs.readFileSync(abs)});}
  const addSrc=path.join(ROOT,'implementation','repository','add','09-remediation');const addDst=path.join(repo,SPEC.addRoot);if(fs.existsSync(addDst))fail('REMEDIATION_DIRECTORY_ALREADY_EXISTS');
  if(!o.apply){console.log(JSON.stringify({status:'REPOSITORY_REMEDIATION_CHECKED',head:SPEC.pinnedHead,files:outputs.map(x=>x.path),deletions:SPEC.deletions.map(x=>x.path),addRoot:SPEC.addRoot,targetPolicy:'pass'}));return;}
  const originals=SPEC.files.map(file=>({path:file.path,bytes:fs.readFileSync(path.join(repo,file.path))}));
  let mutated=false;
  try{
    for(const out of outputs){fs.writeFileSync(path.join(repo,out.path),out.text,{mode:0o600});mutated=true;}
    copyTree(addSrc,addDst);mutated=true;
    fs.copyFileSync(path.join(ROOT,'IMPLEMENTATION-MANIFEST.json'),path.join(addDst,'IMPLEMENTATION-MANIFEST.json'));
    for(const item of SPEC.deletions){fs.unlinkSync(path.join(repo,item.path));mutated=true;}
    const status=git(repo,['status','--porcelain']);if(!status)fail('REMEDIATION_PRODUCED_NO_DIFF');
    try{cp.execFileSync('git',['-C',repo,'diff','--check'],{stdio:['ignore','pipe','pipe']});}catch{fail('GIT_DIFF_CHECK_FAILED');}
    console.log(JSON.stringify({status:'REPOSITORY_REMEDIATION_APPLIED',head:SPEC.pinnedHead,changed:status.split(/\r?\n/)}));
  }catch(error){
    if(mutated){for(const f of originals){fs.mkdirSync(path.dirname(path.join(repo,f.path)),{recursive:true});fs.writeFileSync(path.join(repo,f.path),f.bytes);}for(const f of deletionBackups){fs.mkdirSync(path.dirname(path.join(repo,f.path)),{recursive:true});fs.writeFileSync(path.join(repo,f.path),f.bytes);}fs.rmSync(addDst,{recursive:true,force:true});}
    throw error;
  }
}
try{main();}catch(e){process.stderr.write(JSON.stringify({error:e.code||'UNEXPECTED_FAILURE',details:e.details||{}})+'\n');process.exitCode=1;}
