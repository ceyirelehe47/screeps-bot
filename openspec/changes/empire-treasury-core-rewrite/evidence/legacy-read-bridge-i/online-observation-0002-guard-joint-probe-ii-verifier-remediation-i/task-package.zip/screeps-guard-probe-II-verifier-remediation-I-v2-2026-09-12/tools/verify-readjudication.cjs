#!/usr/bin/env node
'use strict';
const fs=require('node:fs');
const path=require('node:path');
const T=require('./tool-common.cjs');
const ROOT=path.resolve(__dirname,'..');
const PIN=T.readJson(path.join(ROOT,'references','PINNED-EVIDENCE.json'));

function readLines(file){const text=fs.readFileSync(file,'utf8').trim();return text?text.split(/\r?\n/).map((line,index)=>{try{return JSON.parse(line);}catch{T.fail('JSONL_INVALID',{file:path.basename(file),line:index+1});}}):[];}
function eventTime(value){if(Number.isSafeInteger(value?.atMs)&&value.atMs>=0)return value.atMs;const parsed=Date.parse(value?.at);return Number.isFinite(parsed)&&parsed>=0?parsed:null;}
function nearest(values,p){const sorted=[...values].sort((a,b)=>a-b);return sorted[Math.max(0,Math.ceil(sorted.length*p)-1)];}
function verifySource(materialized,manifest){
  if(manifest.status!=='PINNED_GUARD_JOINT_PROBE_EVIDENCE_MATERIALIZED'||manifest.sourceCommit!==PIN.sourceCommit
    ||manifest.probeRunTree!==PIN.probeRunTree||manifest.runTree!==PIN.runTree||manifest.files!==30
    ||!Array.isArray(manifest.entries)||manifest.entries.length!==30)T.fail('SOURCE_MANIFEST_INVALID');
  for(const entry of manifest.entries){const file=path.join(materialized,'source',...T.normalizeRelative(entry.path).split('/'));
    if(!fs.statSync(file).isFile()||fs.statSync(file).size!==entry.bytes||T.sha256File(file)!==entry.sha256)T.fail('SOURCE_MATERIALIZATION_CHANGED',{path:entry.path});}
}
function computeHeartbeat(run){
  const lines=readLines(path.join(run,'guard-probe.jsonl'));
  const probe=T.readJson(path.join(run,'guard-probe-result.json'));
  const health=lines.filter(line=>line.kind==='guard-probe-heartbeat');
  const times=health.map(line=>line.atMs);
  if(times.length!==PIN.expectedObservedMetrics.heartbeatRows||times.some(t=>!Number.isSafeInteger(t)||t<0))T.fail('HEARTBEAT_ROWS_INVALID');
  for(let i=1;i<times.length;i++)if(!(times[i]>times[i-1]))T.fail('HEARTBEAT_ORDER_INVALID',{index:i});
  const gaps=times.slice(1).map((time,index)=>time-times[index]);
  const span=times.at(-1)-times[0],maximum=Math.max(...gaps),p95=nearest(gaps,0.95);
  const extended=gaps.map((gap,index)=>({gap,index,from:times[index],to:times[index+1]})).filter(item=>item.gap>8000);
  if(span!==PIN.expectedObservedMetrics.heartbeatSpanMs||maximum!==PIN.expectedObservedMetrics.heartbeatMaximumGapMs
    ||p95>8000||extended.length!==1||times[0]-probe.startedAtMs>10000
    ||probe.startedAtMs+1500000-times.at(-1)>10000)T.fail('HEARTBEAT_CONTINUITY_INVALID',{span,maximum,p95,extended:extended.length});
  if(health.some(line=>line.collectorPid!==probe.collectorPid||line.collectorState!=='streaming'||line.socketState!=='open'
    ||line.consoleAgeMs<0||line.consoleAgeMs>45000||line.cpuAgeMs<0||line.cpuAgeMs>45000||line.unexpectedBridgeReports!==0))
    T.fail('HEARTBEAT_STATE_INVALID');
  const cycles=lines.filter(line=>line.kind==='guard-time-read-cycle-failed'),attempts=lines.filter(line=>line.kind==='guard-time-read-attempt-failed');
  const gap=extended[0],matchingCycles=cycles.filter(line=>{const at=eventTime(line);return at>gap.from&&at<=gap.to;});
  if(matchingCycles.length!==1)T.fail('HEARTBEAT_RETRY_CORRELATION_INVALID');
  const cycleAt=eventTime(matchingCycles[0]);
  const inGap=attempts.filter(line=>{const at=eventTime(line);return at>gap.from&&at<=cycleAt;});
  if(JSON.stringify(inGap.map(line=>line.attempt))!=='[1,2,3]')T.fail('HEARTBEAT_RETRY_CORRELATION_INVALID');
  return {rows:health.length,firstAtMs:times[0],lastAtMs:times.at(-1),spanMs:span,
    minimumGapMs:Math.min(...gaps),p95GapMs:p95,maximumGapMs:maximum,extendedGapCount:extended.length,
    extendedGap:{fromAtMs:gap.from,toAtMs:gap.to,gapMs:gap.gap,cycleAtMs:cycleAt,attempts:[1,2,3]}};
}
function verify(materialized,adjudication,out){
  if(fs.existsSync(out))T.fail('OUTPUT_ALREADY_EXISTS');
  const manifest=T.readJson(path.join(materialized,'SOURCE-EVIDENCE-MANIFEST.json'),4*1024*1024);verifySource(materialized,manifest);
  const result=T.readJson(path.join(adjudication,'joint-probe-verification.json'),2*1024*1024);
  const remediation=T.readJson(path.join(adjudication,'VERIFIER-REMEDIATION.json'),256*1024);
  if(result.status!=='GUARD_COLLECTOR_CONTROL_PLANE_PROBE_INDEPENDENTLY_VERIFIED'
    ||result.verifierVersion!=='guard-joint-probe-existing-evidence-verifier/v2'
    ||result.sourceEvidence?.commit!==PIN.sourceCommit||result.sourceEvidence?.probeRunTree!==PIN.probeRunTree
    ||result.sourceEvidence?.runTree!==PIN.runTree||result.onlineState?.beforeTick!==PIN.expectedObservedMetrics.beforeTick
    ||result.onlineState?.afterTick!==PIN.expectedObservedMetrics.afterTick||result.formalProfileUsed!==false
    ||result.candidateSnapshotUsed!==false||result.codeWriteRequests!==0)T.fail('READJUDICATION_RESULT_INVALID');
  if(remediation.status!=='GUARD_JOINT_PROBE_VERIFIER_REMEDIATION_APPLIED'||remediation.rawProbeEvidenceModified!==false
    ||remediation.probeRerun!==false||remediation.networkUsed!==false||remediation.onlineCodeWriteRequests!==0
    ||remediation.oldVerifierFalseNegative?.errorCode!==PIN.oldVerifierFailure.errorCode)T.fail('REMEDIATION_RECORD_INVALID');
  const computed=computeHeartbeat(path.join(materialized,'source','run'));
  const reported=result.heartbeatEvidence;
  if(reported.rows!==computed.rows||reported.firstAtMs!==computed.firstAtMs||reported.lastAtMs!==computed.lastAtMs
    ||reported.spanMs!==computed.spanMs||reported.maximumGapMs!==computed.maximumGapMs
    ||reported.p95GapMs!==computed.p95GapMs||reported.extendedGapCount!==computed.extendedGapCount)
    T.fail('READJUDICATION_HEARTBEAT_METRICS_MISMATCH',{computed,reported});
  const run=path.join(materialized,'source','run');
  for(const name of ['upload-attempt.json','backup.json','candidate.json','session.json','closing.json','guard-result.json',
    'restore-result.json','restore.jsonl','run-upload-result.json','run-restore-result.json','collector.lock','guard-probe.lock','action.lock'])
    if(fs.existsSync(path.join(run,name)))T.fail('FORBIDDEN_SOURCE_ARTIFACT_PRESENT',{name});
  verifySource(materialized,manifest);
  const verdict={status:'EXISTING_GUARD_JOINT_PROBE_EVIDENCE_INDEPENDENTLY_READJUDICATED',
    sourceCommit:PIN.sourceCommit,probeRunTree:PIN.probeRunTree,runTree:PIN.runTree,
    verifierVersion:result.verifierVersion,probeStatus:result.status,heartbeat:computed,
    oldVerifierFalseNegative:PIN.oldVerifierFailure,rawProbeEvidenceModified:false,probeRerun:false,
    networkUsed:false,onlineCodeWriteRequests:0,notDeployed:true,
    jointProbeVerificationSha256:T.sha256File(path.join(adjudication,'joint-probe-verification.json'))};
  T.writeNew(out,verdict);return verdict;
}
function main(argv){const o=T.options(argv,['materialized','adjudication','out'],['verify']);T.required(o,'materialized','adjudication','out');if(!o.verify)T.fail('EXPLICIT_VERIFY_REQUIRED');
  const result=verify(path.resolve(o.materialized),path.resolve(o.adjudication),path.resolve(o.out));console.log(JSON.stringify(result));}
module.exports={readLines,eventTime,computeHeartbeat,verify,main};if(require.main===module)T.entrypoint(()=>main(process.argv.slice(2)));
