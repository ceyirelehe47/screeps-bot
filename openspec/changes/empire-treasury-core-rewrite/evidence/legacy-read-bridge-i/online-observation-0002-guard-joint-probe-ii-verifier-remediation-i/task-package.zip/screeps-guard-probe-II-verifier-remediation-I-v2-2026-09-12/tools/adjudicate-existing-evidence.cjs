#!/usr/bin/env node
'use strict';
const fs=require('node:fs');
const path=require('node:path');
const T=require('./tool-common.cjs');
const ROOT=path.resolve(__dirname,'..');
const PIN=T.readJson(path.join(ROOT,'references','PINNED-EVIDENCE.json'));
const V=require('../implementation/verifier-runtime/verify-joint-probe.cjs');

function verifyMaterialized(root,manifest){
  if(manifest.status!=='PINNED_GUARD_JOINT_PROBE_EVIDENCE_MATERIALIZED'||manifest.sourceCommit!==PIN.sourceCommit
    ||manifest.probeRunTree!==PIN.probeRunTree||manifest.runTree!==PIN.runTree||!Array.isArray(manifest.entries)
    ||manifest.entries.length!==manifest.files)T.fail('SOURCE_EVIDENCE_MANIFEST_INVALID');
  let total=0;
  for(const entry of manifest.entries){
    const file=path.join(root,'source',...T.normalizeRelative(entry.path).split('/'));
    const stat=fs.statSync(file);if(!stat.isFile()||stat.size!==entry.bytes||T.sha256File(file)!==entry.sha256)T.fail('SOURCE_EVIDENCE_MATERIALIZATION_CHANGED',{path:entry.path});
    total+=stat.size;
  }
  if(total!==manifest.totalBytes)T.fail('SOURCE_EVIDENCE_MATERIALIZATION_CHANGED',{total,expected:manifest.totalBytes});
}
function verifyOldFalseNegative(source){
  const run=path.join(source,'run');
  const exit=fs.readFileSync(path.join(run,'verify-joint-probe.exit.txt'),'utf8').trim();
  const stdout=fs.readFileSync(path.join(run,'verify-joint-probe.stdout'),'utf8');
  const stderr=fs.readFileSync(path.join(run,'verify-joint-probe.stderr'),'utf8');
  const expected=PIN.oldVerifierFailure;
  if(exit!=='1'||stdout.trim()!==''||!stderr.includes(expected.errorCode)
    ||!stderr.includes(`expectedAtLeast: ${expected.expectedAtLeast}`)||!stderr.includes(`actual: ${expected.actual}`))
    T.fail('OLD_VERIFIER_FALSE_NEGATIVE_EVIDENCE_INVALID');
  return {exitCode:1,errorCode:expected.errorCode,expectedAtLeast:expected.expectedAtLeast,actual:expected.actual,
    stderrSha256:T.sha256(Buffer.from(stderr))};
}
function assertObservedMetrics(result){
  const expected=PIN.expectedObservedMetrics;
  const actual={durationMs:result.durationMs,successfulTimeReads:result.timeChannel.totalSuccessfulReads,
    failedCycles:result.timeChannel.totalFailedCycles,finalConsecutiveFailedCycles:result.timeChannel.consecutiveFailedCycles,
    heartbeatRows:result.heartbeatEvidence.rows,heartbeatSpanMs:result.heartbeatEvidence.spanMs,
    heartbeatMaximumGapMs:result.heartbeatEvidence.maximumGapMs,collectorPid:result.collectorPid,
    firstTick:result.firstTick,lastTick:result.lastTick,beforeTick:result.onlineState?.beforeTick,afterTick:result.onlineState?.afterTick,
    codeWriteRequests:result.codeWriteRequests};
  for(const [key,value] of Object.entries(expected)){
    if(actual[key]!==value)T.fail('READJUDICATION_METRIC_MISMATCH',{key,expected:value,actual:actual[key]});
  }
}
function adjudicate(materialized,out){
  T.ensureDirectoryAbsent(out);
  const manifest=T.readJson(path.join(materialized,'SOURCE-EVIDENCE-MANIFEST.json'),4*1024*1024);
  verifyMaterialized(materialized,manifest);
  const oldFailure=verifyOldFalseNegative(path.join(materialized,'source'));
  const run=path.join(materialized,'source','run');
  const result=V.verifyRun(run,{sourceManifest:manifest});
  if(result.status!=='GUARD_COLLECTOR_CONTROL_PLANE_PROBE_INDEPENDENTLY_VERIFIED')T.fail('READJUDICATION_NOT_VERIFIED');
  assertObservedMetrics(result);
  fs.mkdirSync(out,{recursive:false,mode:0o700});
  T.writeNew(path.join(out,'joint-probe-verification.json'),result);
  const remediation={
    status:'GUARD_JOINT_PROBE_VERIFIER_REMEDIATION_APPLIED',
    sourceEvidence:{commit:PIN.sourceCommit,probeRunTree:PIN.probeRunTree,runTree:PIN.runTree},
    oldVerifierFalseNegative:oldFailure,
    replacementVerifier:{version:result.verifierVersion,
      heartbeatDecisionBasis:['start-boundary','end-boundary','coverage-span','strict-time-order','maximum-gap',
        'p95-gap','retry-cycle-correlation','collector-state','console-freshness','cpu-freshness'],
      fixedHeartbeatRowQuota:null,
    },
    rawProbeEvidenceModified:false,probeRerun:false,networkUsed:false,onlineCodeWriteRequests:0,
  };
  T.writeNew(path.join(out,'VERIFIER-REMEDIATION.json'),remediation);
  verifyMaterialized(materialized,manifest);
  return {status:'EXISTING_GUARD_JOINT_PROBE_EVIDENCE_READJUDICATED',verification:result.status,
    verifierVersion:result.verifierVersion,heartbeatRows:result.heartbeatEvidence.rows,
    heartbeatSpanMs:result.heartbeatEvidence.spanMs,maximumGapMs:result.heartbeatEvidence.maximumGapMs,
    oldFalseNegative:oldFailure.errorCode,rawProbeEvidenceModified:false,probeRerun:false,notDeployed:true};
}
function main(argv){const o=T.options(argv,['materialized','out'],['adjudicate']);T.required(o,'materialized','out');if(!o.adjudicate)T.fail('EXPLICIT_ADJUDICATE_REQUIRED');
  const result=adjudicate(path.resolve(o.materialized),path.resolve(o.out));console.log(JSON.stringify(result));}
module.exports={verifyMaterialized,verifyOldFalseNegative,assertObservedMetrics,adjudicate,main};
if(require.main===module)T.entrypoint(()=>main(process.argv.slice(2)));
