#!/usr/bin/env node
'use strict';
const fs=require('node:fs');
const path=require('node:path');
const T=require('./tool-common.cjs');
const ROOT=path.resolve(__dirname,'..');
const PIN=T.readJson(path.join(ROOT,'references','PINNED-EVIDENCE.json'));
const EXPECTED_FILES=30;

function parseLsTree(buffer){
  const entries=[];
  for(const raw of buffer.toString('utf8').split('\0')){
    if(!raw)continue;
    const tab=raw.indexOf('\t');if(tab<0)T.fail('GIT_LS_TREE_INVALID');
    const meta=raw.slice(0,tab).split(' '),file=raw.slice(tab+1);
    if(meta.length!==3)T.fail('GIT_LS_TREE_INVALID');
    entries.push({mode:meta[0],type:meta[1],blob:meta[2],path:file});
  }
  return entries;
}
function materialize(repo,out,policy=PIN){
  T.ensureDirectoryAbsent(out);
  const probeTree=T.gitText(repo,['rev-parse',`${policy.sourceCommit}:${policy.probeRunPath}`]);
  const runTree=T.gitText(repo,['rev-parse',`${policy.sourceCommit}:${policy.probeRunPath}/run`]);
  if(probeTree!==policy.probeRunTree||runTree!==policy.runTree)T.fail('PINNED_EVIDENCE_TREE_MISMATCH',{probeTree,runTree});
  const raw=T.git(repo,['ls-tree','-r','-z','--full-tree',policy.sourceCommit,'--',policy.probeRunPath],{encoding:null});
  const entries=parseLsTree(raw);
  if(entries.length!==EXPECTED_FILES)T.fail('PINNED_EVIDENCE_FILE_SET_MISMATCH',{expected:EXPECTED_FILES,actual:entries.length});
  const source=path.join(out,'source');fs.mkdirSync(source,{recursive:true,mode:0o700});
  const manifest=[];let totalBytes=0;
  const prefix=policy.probeRunPath+'/';
  for(const entry of entries){
    if(entry.mode!=='100644'||entry.type!=='blob'||!entry.path.startsWith(prefix))T.fail('PINNED_EVIDENCE_ENTRY_INVALID',{path:entry.path,mode:entry.mode,type:entry.type});
    const relative=T.normalizeRelative(entry.path.slice(prefix.length));
    const bytes=T.git(repo,['cat-file','blob',entry.blob],{encoding:null,maxBuffer:128*1024*1024});
    const destination=path.join(source,...relative.split('/'));fs.mkdirSync(path.dirname(destination),{recursive:true,mode:0o700});
    fs.writeFileSync(destination,bytes,{flag:'wx',mode:0o600});
    totalBytes+=bytes.length;manifest.push({path:relative,blob:entry.blob,bytes:bytes.length,sha256:T.sha256(bytes)});
  }
  for(const [relative,expectedBlob] of Object.entries(policy.criticalBlobs||{})){
    const item=manifest.find(entry=>entry.path===relative);
    if(!item||item.blob!==expectedBlob)T.fail('PINNED_CRITICAL_BLOB_MISMATCH',{path:relative,actual:item?.blob??null,expected:expectedBlob});
  }
  const expectedNames=['prepare.stderr','prepare.stdout','secret-scan.json','run/probe-session.json','run/guard-probe.jsonl',
    'run/guard-probe-result.json','run/collector-result.json','run/heartbeat.json','run/online-state-verification.json',
    'run/verify-joint-probe.exit.txt','run/verify-joint-probe.stderr','run/verify-joint-probe.stdout'];
  for(const name of expectedNames)if(!manifest.some(entry=>entry.path===name))T.fail('PINNED_EVIDENCE_REQUIRED_FILE_MISSING',{name});
  const result={status:'PINNED_GUARD_JOINT_PROBE_EVIDENCE_MATERIALIZED',sourceCommit:policy.sourceCommit,
    probeRunPath:policy.probeRunPath,probeRunTree:probeTree,runTree,files:manifest.length,totalBytes,entries:manifest};
  T.writeNew(path.join(out,'SOURCE-EVIDENCE-MANIFEST.json'),result);
  return result;
}
function main(argv){const o=T.options(argv,['repo','out'],['materialize']);T.required(o,'repo','out');if(!o.materialize)T.fail('EXPLICIT_MATERIALIZE_REQUIRED');
  const result=materialize(path.resolve(o.repo),path.resolve(o.out));console.log(JSON.stringify({...result,entries:undefined}));}
module.exports={EXPECTED_FILES,parseLsTree,materialize,main};if(require.main===module)T.entrypoint(()=>main(process.argv.slice(2)));
