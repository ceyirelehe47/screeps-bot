#!/usr/bin/env node
'use strict';
const fs=require('node:fs');
const path=require('node:path');
const T=require('./tool-common.cjs');
const ROOT=path.resolve(__dirname,'..');
const HEADS=T.readJson(path.join(ROOT,'references','CURRENT-HEADS.json'));
const PIN=T.readJson(path.join(ROOT,'references','PINNED-EVIDENCE.json'));
const TARGET_REL='openspec/changes/empire-treasury-core-rewrite/evidence/legacy-read-bridge-i/online-observation-0002-guard-joint-probe-ii-verifier-remediation-i';
function copyTree(source,destination){for(const relative of T.listFiles(source))T.copyFileNew(path.join(source,...relative.split('/')),path.join(destination,...relative.split('/')));}
function renderReport(result,verdict,packageHash){
  const h=result.heartbeatEvidence;
  return `# Guard Joint Probe II · Verifier Remediation & Existing Evidence Re-adjudication I\n\n`+
`- Source evidence commit: \`${PIN.sourceCommit}\`\n`+
`- Source probe-run tree: \`${PIN.probeRunTree}\`\n`+
`- Source run tree: \`${PIN.runTree}\`\n`+
`- Task package SHA-256: \`${packageHash}\`\n`+
`- This round is offline re-adjudication only: no collector restart, no 25-minute rerun, no Screeps API call, no upload, no restore.\n\n`+
`## Final status\n\n\`\`\`text\n`+
`GUARD_JOINT_PROBE_COMPLETE_IMPLEMENTATION_VERIFIED\n`+
`PROBE_SESSION_DECOUPLED_FROM_FORMAL_PROFILE\n`+
`GUARD_COLLECTOR_CONTROL_PLANE_PROBE_INDEPENDENTLY_VERIFIED\n`+
`EXISTING_EVIDENCE_READJUDICATED\n`+
`NOT_DEPLOYED\n\`\`\`\n\n`+
`## Why the previous verifier failed\n\n`+
`The original verifier rejected the completed run solely because it required at least 295 heartbeat rows and observed 287. `+
`That fixed row quota assumed nearly exact 5-second scheduling and did not model Windows timer drift or the one allowed three-attempt HTTP deadline cycle. `+
`The raw failure artifact remains unchanged and is pinned by Git blob identity.\n\n`+
`## Replacement decision basis\n\n`+
`The completed verifier uses wall-clock coverage and continuity rather than a fixed row count. It checks both run boundaries, strict timestamp order, `+
`coverage span, ordinary and retry-explained maximum gaps, p95 gap, exact correlation of an extended gap with the recorded 1/2/3 retry attempts, `+
`collector PID/state, and console/CPU freshness.\n\n`+
`## Re-adjudicated evidence\n\n`+
`| Item | Result |\n|---|---:|\n`+
`| Probe duration | ${result.durationMs} ms |\n`+
`| Successful time reads | ${result.timeChannel.totalSuccessfulReads} |\n`+
`| Failed cycles | ${result.timeChannel.totalFailedCycles} |\n`+
`| Final consecutive failures | ${result.timeChannel.consecutiveFailedCycles} |\n`+
`| Heartbeat rows | ${h.rows} |\n`+
`| Heartbeat span | ${h.spanMs} ms |\n`+
`| Median heartbeat gap | ${h.medianGapMs} ms |\n`+
`| p95 heartbeat gap | ${h.p95GapMs} ms |\n`+
`| Maximum heartbeat gap | ${h.maximumGapMs} ms |\n`+
`| Retry-explained extended gaps | ${h.extendedGapCount} |\n`+
`| Collector PID | ${result.collectorPid} |\n`+
`| Tick range | ${result.firstTick} → ${result.lastTick} |\n`+
`| Code write requests | ${result.codeWriteRequests} |\n\n`+
`The single extended heartbeat gap is accepted only because the immutable timeline contains the matching failed cycle and exactly three failed attempts numbered 1, 2, and 3.\n\n`+
`## Immutable-source and process boundaries\n\n`+
`The source probe files were materialized from \`${PIN.sourceCommit}\` and rechecked against \`${PIN.probeRunTree}\` / \`${PIN.runTree}\`. `+
`The re-adjudication writes results outside the materialized source and verifies every source file hash before and after. No raw probe evidence is copied into this new evidence directory.\n\n`+
`The source execution report disclosed that the external toolkit directory was rebuilt once while the already-running processes continued from loaded modules. `+
`This remains recorded as a non-material procedural deviation; this re-adjudication does not erase or reinterpret that disclosure.\n\n`+
`Independent re-adjudication status: \`${verdict.status}\`.\n`;
}
function assemble({repo,packageDir,packageZip,testResults,executionLogs,materialized,adjudication,independentVerdict},policy={heads:HEADS,pin:PIN,targetRel:TARGET_REL}){
  const head=T.gitText(repo,['rev-parse','HEAD']),status=T.gitText(repo,['status','--porcelain']);
  if(head!==policy.heads.refactorHead||status)T.fail('ASSEMBLY_REQUIRES_PINNED_CLEAN_HEAD',{head,clean:status.length===0});
  const target=path.join(repo,...policy.targetRel.split('/'));T.ensureDirectoryAbsent(target);
  const result=T.readJson(path.join(adjudication,'joint-probe-verification.json'),2*1024*1024);
  const verdict=T.readJson(independentVerdict,2*1024*1024);
  if(result.status!=='GUARD_COLLECTOR_CONTROL_PLANE_PROBE_INDEPENDENTLY_VERIFIED'
    ||verdict.status!=='EXISTING_GUARD_JOINT_PROBE_EVIDENCE_INDEPENDENTLY_READJUDICATED')T.fail('ASSEMBLY_INPUT_NOT_VERIFIED');
  const manifest=T.readJson(path.join(materialized,'SOURCE-EVIDENCE-MANIFEST.json'),4*1024*1024);
  const packageHash=T.sha256File(packageZip);
  fs.mkdirSync(target,{recursive:true,mode:0o700});
  T.copyFileNew(packageZip,path.join(target,'task-package.zip'));
  T.writeTextNew(path.join(target,'task-package.sha256'),packageHash+'\n');
  T.copyFileNew(path.join(packageDir,'IMPLEMENTATION-MANIFEST.json'),path.join(target,'IMPLEMENTATION-MANIFEST.json'));
  T.copyFileNew(path.join(materialized,'SOURCE-EVIDENCE-MANIFEST.json'),path.join(target,'SOURCE-EVIDENCE-MANIFEST.json'));
  T.copyFileNew(path.join(adjudication,'joint-probe-verification.json'),path.join(target,'joint-probe-verification.json'));
  T.copyFileNew(path.join(adjudication,'VERIFIER-REMEDIATION.json'),path.join(target,'VERIFIER-REMEDIATION.json'));
  T.copyFileNew(independentVerdict,path.join(target,'READJUDICATION-VERIFIED.json'));
  copyTree(path.join(packageDir,'implementation'),path.join(target,'implementation'));
  copyTree(testResults,path.join(target,'test-results'));
  copyTree(executionLogs,path.join(target,'execution-logs'));
  T.writeNew(path.join(target,'READJUDICATION-SUMMARY.json'),{
    status:'GUARD_JOINT_PROBE_EXISTING_EVIDENCE_READJUDICATION_COMPLETE',sourceCommit:policy.pin.sourceCommit,
    sourceProbeRunTree:policy.pin.probeRunTree,sourceRunTree:policy.pin.runTree,sourceFiles:manifest.files,
    verifierStatus:result.status,independentStatus:verdict.status,heartbeatEvidence:result.heartbeatEvidence,
    rawProbeEvidenceModified:false,probeRerun:false,networkUsed:false,onlineCodeWriteRequests:0,notDeployed:true,
  });
  T.writeTextNew(path.join(target,'EXECUTION-REPORT.md'),renderReport(result,verdict,packageHash));
  return {status:'READJUDICATION_EVIDENCE_ASSEMBLED',target:policy.targetRel,files:T.listFiles(target).length,packageSha256:packageHash};
}
function main(argv){const o=T.options(argv,['repo','package','package-zip','test-results','execution-logs','materialized','adjudication','independent-verdict'],['assemble']);
  T.required(o,'repo','package','package-zip','test-results','execution-logs','materialized','adjudication','independent-verdict');if(!o.assemble)T.fail('EXPLICIT_ASSEMBLE_REQUIRED');
  const result=assemble({repo:path.resolve(o.repo),packageDir:path.resolve(o.package),packageZip:path.resolve(o['package-zip']),
    testResults:path.resolve(o['test-results']),executionLogs:path.resolve(o['execution-logs']),materialized:path.resolve(o.materialized),adjudication:path.resolve(o.adjudication),
    independentVerdict:path.resolve(o['independent-verdict'])});console.log(JSON.stringify(result));}
module.exports={TARGET_REL,renderReport,assemble,main};if(require.main===module)T.entrypoint(()=>main(process.argv.slice(2)));
