# Agent Run — Guard Joint Probe II Verifier Remediation I · v2 跨平台夹具修正版

## 版本与恢复位置

本包替代 SHA-256 `b9d924994dd3f5d52f50406bad2d323c8e604ec036f28c92e268b4063fb464a4` 的旧包。

本次仅修正 `implementation/tests/assembly.spec.cjs` 的文件名碰撞夹具；四个 verifier runtime 文件、九个执行工具、heartbeat 判据、固定证据与 Git 基线均与旧包逐字节一致。不得把本包误当成新探针任务。

上一轮 Windows 的 29/30 和 WSL 的 30/30 均作为历史结果保留。本轮使用**原 Windows Node/NTFS 环境**重新完成 30 项测试；不要求转到 WSL、不启用目录大小写敏感、不跳过用例、不修改 verifier。测试文件和测试名集合不变。

步骤 4–10 的真实原始证据重裁决仍须执行。旧 WSL 30/30 只证明旧包测试在那个环境通过，不能当成真实重裁决已完成。

## 0. 任务性质

这是**完整实现交付后的验证任务**。包内实现、门禁、测试、报告生成和证据装配均已完成。

Agent 只负责运行固定字节并报告结果。不得：

- 编写、修改或“优化” verifier；
- 调整任何时间阈值、间隔、重试或通过条件；
- 新增测试来改变结论；
- 修改 `64d9271…` 中的原始 probe evidence；
- 重新运行 collector、Guard probe 或 25 分钟探针；
- 连接 Screeps API、读取 token、上传代码或执行 restore；
- 修改 `compat/treasury-read-bridge-i`；
- 修改生产源码、Treasury 内核或 compat reader/config；
- 把原始报告披露的 toolkit 运行中重建事项删除或降格为“未发生”。

任一步失败：保存 stdout、stderr 和退出码，保留 Git 外工作目录与全部旧轮证据，不提交，不现场修包。只有本轮工具已经创建新 TARGET 时，先把失败现场保存在 Git 外，再撤销本轮自己的新增目录；不得 reset、删除或覆盖其他工作。

## 1. 固定基线

```text
repository: ceyirelehe47/screeps-bot

refactor/empire-treasury-rearchitecture
64d92713352826fb547a0860a963b11b4de4f440

compat/treasury-read-bridge-i
fcfc125f0e5cd6c3370318b4fee0450f4d09af53

source probe-run tree
f6660ce8aafd6e28ce01993c21a233845609f35a

source run tree
9469e42799ace7e2ec40a4656bfc9b4f84b53328
```

开始前允许一次 `git fetch --all --prune` 以刷新 GitHub 远端引用。此后本轮不需要、也不允许访问 Screeps。

## 2. 目录约定

以下示例适用于 Git Bash；PowerShell 可使用等价路径写法。

```bash
set -euo pipefail

REPO='D:/code/screeps/screeps-bot'
PKG='D:/path/to/extracted/screeps-guard-probe-II-verifier-remediation-I-v2-2026-09-12'
ZIP='D:/path/to/screeps-guard-probe-II-verifier-remediation-I-v2-2026-09-12.zip'
WORK='D:/code/screeps/guard-joint-probe-II-verifier-remediation-I-v2-run'
TARGET_REL='openspec/changes/empire-treasury-core-rewrite/evidence/legacy-read-bridge-i/online-observation-0002-guard-joint-probe-ii-verifier-remediation-i'
TARGET="$REPO/$TARGET_REL"

# 保留旧轮现场；本轮用全新目录，存在时停止，不自动删除。
if [ -e "$WORK" ]; then
  printf '%s\n' 'WORK_ALREADY_EXISTS: preserve it and use a fresh empty work path.' >&2
  exit 1
fi
mkdir -p "$WORK/execution-logs"

# 固定日志封装：set -e 开启时也先记录失败退出码，再停止。
run_step() {
  local stem="$1" rc
  shift
  if "$@" > "${stem}.stdout" 2> "${stem}.stderr"; then rc=0; else rc=$?; fi
  printf '%s\n' "$rc" > "${stem}.exit.txt"
  return "$rc"
}
```

`WORK` 必须位于 Git 工作树外。`TARGET` 在开始时必须不存在。

## 3. 基线与包完整性

```bash
git -C "$REPO" fetch --all --prune

run_step "$WORK/execution-logs/01-verify-current-heads" \
  node "$PKG/tools/verify-current-heads.cjs" \
    --repo "$REPO" --verify

run_step "$WORK/execution-logs/02-verify-package" \
  node "$PKG/tools/verify-package.cjs" \
    --package "$PKG" --verify
```

预期：

```text
VERIFIER_REMEDIATION_BASELINE_VERIFIED
PACKAGE_INTEGRITY_VERIFIED
```

上面的 `run_step` 已提供完整错误日志封装；非零退出立即停止，不允许用管道或其他命令覆盖失败退出码。请把 ZIP 的 SHA-256 与包外 `.sha256.txt` 再核对一次。

## 4. 完整实现测试

```bash
run_step "$WORK/execution-logs/03-run-implementation-tests" \
  node "$PKG/tools/run-implementation-tests.cjs" \
    --out "$WORK/implementation-tests" --run
```

必须得到：

```text
VERIFIER_REMEDIATION_COMPLETE_IMPLEMENTATION_VERIFIED
30 / 30 PASS（Windows 原环境，skip=0）
```

测试覆盖：

- 不发生大小写折叠碰撞的两文件夹具，正反两种固定乱序清单、错大小写清单/多余文件/改内容负对照；
- 287 行真实形态正对照；
- 少于 295 行但连续覆盖的正对照；
- 行数很多但中间有长空洞的反例；
- 压缩时间线、时间倒退、重复时间；
- PID 变化、console/CPU 过期；
- 未被失败周期解释的延长间隔；
- 缺少 1/2/3 完整重试证据；
- session、前后检、footer、stop、tick 与禁止产物；
- 固定 Git tree 物化、原始证据防篡改；
- 完整 adjudicate → independent verify → evidence assemble 链。

## 5. 从固定 Git 对象物化原始证据

```bash
run_step "$WORK/execution-logs/04-materialize-pinned-evidence" \
  node "$PKG/tools/materialize-pinned-evidence.cjs" \
    --repo "$REPO" \
    --out "$WORK/materialized" \
    --materialize
```

工具必须核验 commit、`probe-run` tree、`run` tree、30 个文件和关键 blob，再逐 blob 复制到 Git 外目录。禁止从当前工作目录手工复制 evidence。

预期：

```text
PINNED_GUARD_JOINT_PROBE_EVIDENCE_MATERIALIZED
```

## 6. 对既有证据执行修复后的 verifier

```bash
run_step "$WORK/execution-logs/05-adjudicate-existing-evidence" \
  node "$PKG/tools/adjudicate-existing-evidence.cjs" \
    --materialized "$WORK/materialized" \
    --out "$WORK/adjudication" \
    --adjudicate
```

该步骤必须：

- 先验证原 verifier 的失败原件确实是 `295` 对 `287`；
- 对每个 materialized 文件做前后 hash 复核；
- 不写入 `source/`；
- 生成 `joint-probe-verification.json` 和 `VERIFIER-REMEDIATION.json`；
- 不产生网络访问。

预期：

```text
EXISTING_GUARD_JOINT_PROBE_EVIDENCE_READJUDICATED
GUARD_COLLECTOR_CONTROL_PLANE_PROBE_INDEPENDENTLY_VERIFIED
```

## 7. 独立重算与交叉验收

```bash
run_step "$WORK/execution-logs/06-verify-readjudication" \
  node "$PKG/tools/verify-readjudication.cjs" \
    --materialized "$WORK/materialized" \
    --adjudication "$WORK/adjudication" \
    --out "$WORK/READJUDICATION-VERIFIED.json" \
    --verify
```

独立复核器不导入主 verifier 的 heartbeat helper。它必须从原始 JSONL 重新计算：

```text
heartbeat rows       287
heartbeat span       1495086 ms
maximum gap          10033 ms
extended gaps        1
successful reads     99
failed cycles        1
final consecutive    0
collector PID        32772
first/last tick      73636421 / 73636790
code writes          0
```

并确认唯一延长间隔包含同一失败周期与 attempt 1、2、3。

预期：

```text
EXISTING_GUARD_JOINT_PROBE_EVIDENCE_INDEPENDENTLY_READJUDICATED
```

## 8. 确定性装配新 evidence

```bash
run_step "$WORK/07-assemble-evidence" \
  node "$PKG/tools/assemble-evidence.cjs" \
    --repo "$REPO" \
    --package "$PKG" \
    --package-zip "$ZIP" \
    --test-results "$WORK/implementation-tests" \
    --execution-logs "$WORK/execution-logs" \
    --materialized "$WORK/materialized" \
    --adjudication "$WORK/adjudication" \
    --independent-verdict "$WORK/READJUDICATION-VERIFIED.json" \
    --assemble

run_step "$WORK/08-verify-assembled-evidence" \
  node "$PKG/tools/verify-assembled-evidence.cjs" \
    --repo "$REPO" \
    --out "$TARGET/FINAL-VERIFICATION.json" \
    --verify
```

预期：

```text
READJUDICATION_EVIDENCE_ASSEMBLED
READJUDICATION_EVIDENCE_PACKAGE_VERIFIED
```

新目录不得复制原始 `guard-probe.jsonl`、`console.jsonl`、session、heartbeat、collector result、线上模块正文、token 或 `.secret.json`。原始证据仅通过 commit/tree/blob/hash 引用。

## 9. 提交前检查

```bash
git -C "$REPO" diff --check

git -C "$REPO" status --short
```

`status --short` 只能显示：

```text
?? openspec/changes/empire-treasury-core-rewrite/evidence/legacy-read-bridge-i/online-observation-0002-guard-joint-probe-ii-verifier-remediation-i/
```

再次确认 compat 未变化：

```bash
test "$(git -C "$REPO" rev-parse refs/heads/compat/treasury-read-bridge-i)" = \
  'fcfc125f0e5cd6c3370318b4fee0450f4d09af53'
```

## 10. 唯一提交与推送

全部通过后，仅创建一个 evidence 提交：

```bash
git -C "$REPO" add -- "$TARGET_REL"
git -C "$REPO" diff --cached --check
git -C "$REPO" diff --cached --name-only

git -C "$REPO" commit -m \
  'evidence(compat): Guard Joint Probe II verifier remediation and existing evidence re-adjudication'

git -C "$REPO" push origin refactor/empire-treasury-rearchitecture
```

禁止 amend、reset、force-push 或改写历史。

## 11. 成功终态

只有全部固定步骤通过，才可报告：

```text
GUARD_JOINT_PROBE_COMPLETE_IMPLEMENTATION_VERIFIED
PROBE_SESSION_DECOUPLED_FROM_FORMAL_PROFILE
GUARD_COLLECTOR_CONTROL_PLANE_PROBE_INDEPENDENTLY_VERIFIED
EXISTING_EVIDENCE_READJUDICATED
NOT_DEPLOYED
```

不得报告：

```text
ONLINE_COMPAT_READ_OBSERVED
TREASURY_PRODUCTION_READY
DEPLOYED
```

本轮不验证兼容桥样本；它只闭合 Guard Joint Probe II 的独立 verifier 缺口。
