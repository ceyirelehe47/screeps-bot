#!/usr/bin/env node
'use strict';
const fs=require('node:fs');
const path=require('node:path');
const T=require('./tool-common.cjs');
const A=require('./assemble-evidence.cjs');
const ROOT=path.resolve(__dirname,'..');
const HEADS=T.readJson(path.join(ROOT,'references','CURRENT-HEADS.json'));
function verify(repo,out,policy={heads:HEADS,targetRel:A.TARGET_REL}){
  const target=path.join(repo,...policy.targetRel.split('/'));
  if(!fs.statSync(target).isDirectory()||fs.existsSync(out))T.fail('ASSEMBLED_EVIDENCE_INVALID');
  const files=T.listFiles(target);
  const forbidden=files.filter(name=>name.endsWith('.jsonl')||['probe-session.json','preflight-before.json','preflight-after.json',
    'heartbeat.json','collector-result.json','guard-probe-result.json','.secret.json'].includes(path.basename(name)));
  if(forbidden.length)T.fail('RAW_OR_SECRET_EVIDENCE_COPIED',{forbidden});
  const report=fs.readFileSync(path.join(target,'EXECUTION-REPORT.md'),'utf8');
  for(const marker of ['GUARD_COLLECTOR_CONTROL_PLANE_PROBE_INDEPENDENTLY_VERIFIED','EXISTING_EVIDENCE_READJUDICATED',
    'NOT_DEPLOYED','non-material procedural deviation','no collector restart','no 25-minute rerun'])if(!report.includes(marker))T.fail('ASSEMBLED_REPORT_MARKER_MISSING',{marker});
  if(report.includes('ONLINE_COMPAT_READ_OBSERVED')||report.includes('TREASURY_PRODUCTION_READY'))T.fail('ASSEMBLED_REPORT_FORBIDDEN_CLAIM');
  const result=T.readJson(path.join(target,'joint-probe-verification.json'));
  const independent=T.readJson(path.join(target,'READJUDICATION-VERIFIED.json'));
  const summary=T.readJson(path.join(target,'READJUDICATION-SUMMARY.json'));
  if(result.status!=='GUARD_COLLECTOR_CONTROL_PLANE_PROBE_INDEPENDENTLY_VERIFIED'
    ||independent.status!=='EXISTING_GUARD_JOINT_PROBE_EVIDENCE_INDEPENDENTLY_READJUDICATED'
    ||summary.status!=='GUARD_JOINT_PROBE_EXISTING_EVIDENCE_READJUDICATION_COMPLETE'
    ||summary.rawProbeEvidenceModified!==false||summary.probeRerun!==false||summary.networkUsed!==false
    ||summary.onlineCodeWriteRequests!==0||summary.notDeployed!==true)T.fail('ASSEMBLED_RESULT_INVALID');
  const recordedHash=fs.readFileSync(path.join(target,'task-package.sha256'),'utf8').trim();
  if(!/^[a-f0-9]{64}$/.test(recordedHash)||T.sha256File(path.join(target,'task-package.zip'))!==recordedHash)T.fail('ASSEMBLED_PACKAGE_HASH_INVALID');
  const statusLines=T.gitText(repo,['status','--porcelain=v1']).split(/\r?\n/).filter(Boolean);
  const changed=statusLines.map(line=>line.slice(3));
  if(!changed.length||changed.some(name=>!name.startsWith(policy.targetRel+'/')))T.fail('ASSEMBLED_GIT_SCOPE_INVALID',{changed,statusLines});
  const verdict={status:'READJUDICATION_EVIDENCE_PACKAGE_VERIFIED',baseHead:policy.heads.refactorHead,target:policy.targetRel,
    filesBeforeFinalRecord:files.length,verifierStatus:result.status,independentStatus:independent.status,
    rawProbeEvidenceCopied:false,probeRerun:false,networkUsed:false,onlineCodeWriteRequests:0,notDeployed:true};
  T.writeNew(out,verdict);return verdict;
}
function main(argv){const o=T.options(argv,['repo','out'],['verify']);T.required(o,'repo','out');if(!o.verify)T.fail('EXPLICIT_VERIFY_REQUIRED');
  const result=verify(path.resolve(o.repo),path.resolve(o.out));console.log(JSON.stringify(result));}
module.exports={verify,main};if(require.main===module)T.entrypoint(()=>main(process.argv.slice(2)));
