#!/usr/bin/env node
'use strict';
const fs=require('node:fs');
const path=require('node:path');
const cp=require('node:child_process');
const T=require('./tool-common.cjs');
const ROOT=path.resolve(__dirname,'..');
const EXPECTED_TESTS=30;
function run(out){
  T.ensureDirectoryAbsent(out);fs.mkdirSync(out,{recursive:false,mode:0o700});
  const testDir=path.join(ROOT,'implementation','tests');
  const tests=fs.readdirSync(testDir).filter(name=>name.endsWith('.spec.cjs')).sort().map(name=>path.join(testDir,name));
  const syntaxFiles=T.listFiles(ROOT).filter(name=>name.endsWith('.cjs')).map(name=>path.join(ROOT,...name.split('/')));
  const syntax=[];
  for(const file of syntaxFiles){const r=cp.spawnSync(process.execPath,['--check',file],{encoding:'utf8'});syntax.push({path:path.relative(ROOT,file).replace(/\\/g,'/'),exitCode:r.status,stderr:r.stderr});if(r.status!==0)T.fail('SYNTAX_CHECK_FAILED',{file});}
  T.writeNew(path.join(out,'syntax-check.json'),{status:'SYNTAX_CHECK_VERIFIED',files:syntax.length,results:syntax});
  const result=cp.spawnSync(process.execPath,['--test','--test-reporter=tap',...tests],{encoding:'utf8',maxBuffer:32*1024*1024});
  T.writeTextNew(path.join(out,'implementation-tests.tap'),result.stdout||'');
  T.writeTextNew(path.join(out,'implementation-tests.stderr'),result.stderr||'');
  T.writeTextNew(path.join(out,'implementation-tests.exit.txt'),String(result.status)+'\n');
  const matchTests=(result.stdout||'').match(/^# tests (\d+)$/m),matchPass=(result.stdout||'').match(/^# pass (\d+)$/m),matchFail=(result.stdout||'').match(/^# fail (\d+)$/m);
  const testsCount=Number(matchTests?.[1]),passed=Number(matchPass?.[1]),failed=Number(matchFail?.[1]);
  if(result.status!==0||testsCount!==EXPECTED_TESTS||passed!==EXPECTED_TESTS||failed!==0)T.fail('IMPLEMENTATION_TESTS_FAILED',{exitCode:result.status,tests:testsCount,passed,failed});
  const summary={status:'VERIFIER_REMEDIATION_COMPLETE_IMPLEMENTATION_VERIFIED',tests:testsCount,passed,failed,syntaxFiles:syntax.length,testFiles:tests.length};
  T.writeNew(path.join(out,'implementation-tests-summary.json'),summary);return summary;
}
function main(argv){const o=T.options(argv,['out'],['run']);T.required(o,'out');if(!o.run)T.fail('EXPLICIT_RUN_REQUIRED');const result=run(path.resolve(o.out));console.log(JSON.stringify(result));}
module.exports={EXPECTED_TESTS,run,main};if(require.main===module)T.entrypoint(()=>main(process.argv.slice(2)));
