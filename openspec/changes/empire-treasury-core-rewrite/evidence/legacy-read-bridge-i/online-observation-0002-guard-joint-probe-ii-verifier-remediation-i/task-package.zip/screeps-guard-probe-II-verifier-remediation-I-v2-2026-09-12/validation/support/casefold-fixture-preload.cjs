/* Maker-only fault model, NOT an NTFS emulator or part of the runtime.
 * Opt in with: node --require THIS_FILE --test .../assembly.spec.cjs
 * Restrict case-insensitive alias resolution to direct files under the test's
 * temporary package-order-* directory, preserving the first spelling created.
 * No skip, changed assertions, changed production verifier, or network access.
 */
'use strict';
const fs=require('node:fs');
const path=require('node:path');
const readDirectory=fs.readdirSync.bind(fs);
function resolveFixtureAlias(value){
  if(typeof value!=='string')return value;
  const parent=path.dirname(value);
  if(!/^package-order-[A-Za-z0-9_-]+$/.test(path.basename(parent)))return value;
  const name=path.basename(value);
  let names;try{names=readDirectory(parent);}catch{return value;}
  const existing=names.find(item=>item.toLowerCase()===name.toLowerCase());
  return existing===undefined?value:path.join(parent,existing);
}
for(const method of ['writeFileSync','readFileSync']){
  const original=fs[method];
  fs[method]=function(file,...args){return Reflect.apply(original,fs,[resolveFixtureAlias(file),...args]);};
}
