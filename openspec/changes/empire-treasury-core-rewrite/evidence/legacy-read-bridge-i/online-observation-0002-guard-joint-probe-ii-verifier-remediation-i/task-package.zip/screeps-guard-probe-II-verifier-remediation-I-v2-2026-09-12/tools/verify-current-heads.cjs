#!/usr/bin/env node
'use strict';
const path=require('node:path');
const T=require('./tool-common.cjs');
const ROOT=path.resolve(__dirname,'..');
const HEADS=T.readJson(path.join(ROOT,'references','CURRENT-HEADS.json'));
const EVIDENCE=T.readJson(path.join(ROOT,'references','PINNED-EVIDENCE.json'));

function verify(repo){
  const branch=T.gitText(repo,['branch','--show-current']);
  const head=T.gitText(repo,['rev-parse','HEAD']);
  const remoteRefactor=T.gitText(repo,['rev-parse',`refs/remotes/origin/${HEADS.refactorBranch}`]);
  const compatLocal=T.gitText(repo,['rev-parse',`refs/heads/${HEADS.compatBranch}`]);
  const compatRemote=T.gitText(repo,['rev-parse',`refs/remotes/origin/${HEADS.compatBranch}`]);
  const status=T.gitText(repo,['status','--porcelain']);
  if(branch!==HEADS.refactorBranch||head!==HEADS.refactorHead||remoteRefactor!==HEADS.refactorHead
    ||compatLocal!==HEADS.compatHead||compatRemote!==HEADS.compatHead||status)T.fail('PINNED_HEADS_OR_CLEANLINESS_MISMATCH',{
      branch,head,remoteRefactor,compatLocal,compatRemote,clean:status.length===0,
    });
  const parent=T.gitText(repo,['rev-parse',`${HEADS.refactorHead}^`]);
  if(parent!==HEADS.previousRefactorHead)T.fail('PINNED_PARENT_MISMATCH',{parent});
  const probeTree=T.gitText(repo,['rev-parse',`${EVIDENCE.sourceCommit}:${EVIDENCE.probeRunPath}`]);
  const runTree=T.gitText(repo,['rev-parse',`${EVIDENCE.sourceCommit}:${EVIDENCE.probeRunPath}/run`]);
  if(probeTree!==EVIDENCE.probeRunTree||runTree!==EVIDENCE.runTree)T.fail('PINNED_EVIDENCE_TREE_MISMATCH',{probeTree,runTree});
  const changed=T.gitText(repo,['diff','--name-only',HEADS.previousRefactorHead,HEADS.refactorHead]).split(/\r?\n/).filter(Boolean);
  const allowedPrefix='openspec/changes/empire-treasury-core-rewrite/evidence/legacy-read-bridge-i/online-observation-0002-guard-joint-probe-ii/';
  if(!changed.length||changed.some(file=>!file.startsWith(allowedPrefix)))T.fail('SOURCE_COMMIT_SCOPE_INVALID',{changed});
  return {status:'VERIFIER_REMEDIATION_BASELINE_VERIFIED',refactor:{branch,head,remote:remoteRefactor,clean:true},
    compat:{branch:HEADS.compatBranch,head:compatLocal,remote:compatRemote,clean:true},
    sourceEvidence:{commit:EVIDENCE.sourceCommit,probeRunTree:probeTree,runTree},changedFiles:changed.length};
}
function main(argv){const o=T.options(argv,['repo'],['verify']);T.required(o,'repo');if(!o.verify)T.fail('EXPLICIT_VERIFY_REQUIRED');
  const result=verify(path.resolve(o.repo));console.log(JSON.stringify(result));}
module.exports={verify,main};if(require.main===module)T.entrypoint(()=>main(process.argv.slice(2)));
