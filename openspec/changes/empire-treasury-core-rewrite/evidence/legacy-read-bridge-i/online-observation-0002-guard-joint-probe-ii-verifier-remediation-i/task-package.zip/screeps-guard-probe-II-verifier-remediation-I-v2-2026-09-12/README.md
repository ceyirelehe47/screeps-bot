# Guard Joint Probe II — Verifier Remediation I · v2

完整实现与验证任务包；本次修复测试夹具，不改变 verifier 规则。

旧包在 NTFS 上因同时创建 `A.txt` 和 `a.txt` 导致 29/30。本包改用大小写折叠后仍不同的 `Z-upper.txt` / `a-lower.txt`，使用创建排他标志，并在测试内固定输入两个遍历顺序。原始大小写身份核验仍须严格通过。

Agent 只运行固定实现：在 Windows 原环境重跑 30 项测试，然后对固定 `64d9271…` 的真实证据离线重裁决。不得改用 WSL 结果代替 Windows 验证，也不得重跑 25 分钟探针。

入口：`AGENT-RUN.md`。旧包废止及范围：`SUPERSEDES.md`。制作方实测与局限：`validation/MAKER-VALIDATION.json`、`validation/LIMITATIONS.md`。
