# 复现说明（制包方验证，不是 Agent 的额外任务）

原生：

```bash
node "$PKG/tools/run-implementation-tests.cjs" --out /new/nonexistent/output --run
```

大小写别名故障模型：

```bash
node --require "$PKG/validation/support/casefold-fixture-preload.cjs" \
  --test --test-reporter=tap "$PKG"/implementation/tests/*.spec.cjs
```

故障模型只处理测试临时目录 `package-order-*` 内的同步文件读写，解析已存在的 ASCII 大小写别名，保留首次创建的拼写。它不改变 `verify-package.cjs`，不跳过测试，不是完整 NTFS 模拟。用相同 preload 指向旧包测试得到 29/30，指向本包测试得到 30/30；原生日志及模型日志分别归档。

`unsorted-verifier-negative-control/` 是在隔离复制目录中删除 verifier 的 actual-list `.sort()` 后运行两个 assembly 用例的结果：正确得到 1 pass / 1 fail，说明修正版仍能抓住原本的排序回归。分发的 verifier 从未应用该变异。

`old-*` 下失败记录是故障重现证据，不代表本包测试失败。四组全套测试的测试名集合逐项一致。最终严格 runner 结果位于 `maker-test-results/`。
