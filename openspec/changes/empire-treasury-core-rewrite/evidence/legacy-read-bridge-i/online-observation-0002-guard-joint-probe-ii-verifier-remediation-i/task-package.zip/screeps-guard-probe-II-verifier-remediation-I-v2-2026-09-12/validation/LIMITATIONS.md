# 制作方验证范围

本轮原生执行环境：Linux x64，Node v22.16.0，Git 2.47.3。

原包在 Linux 原生文件系统上 30/30；使用仅针对临时 package-order-* 目录的大小写别名故障模型时为 29/30，错误为 PACKAGE_FILE_SET_MISMATCH。修正版在同样两种模式下均为 30/30、skip=0。

该模型保留首个文件名的大小写，并把后续同名不同大小写的读写解析到同一个实际文件；它只复现本次夹具所依赖的别名行为，**不是原生 Windows/NTFS 验证**，也不模拟 NTFS 全部规则。原 Windows Node v22.19.0 / NTFS 的复测仍由 Agent 完成。

主 verifier、独立复核器、物化器、装配器均未因本次修复改动。制作方 30 项测试含合成证据的完整 adjudicate → independent verify → assemble 链，但不能据此声称用户固定 Git evidence 的真实重裁决已经完成。

尚未由制作方执行：从用户本地 Git 对象库物化 `64d9271…` 的全部真实 evidence、对其最终重裁决、用户仓库提交或 push。本轮未使用 token，未连接 Screeps，未运行新探针。
