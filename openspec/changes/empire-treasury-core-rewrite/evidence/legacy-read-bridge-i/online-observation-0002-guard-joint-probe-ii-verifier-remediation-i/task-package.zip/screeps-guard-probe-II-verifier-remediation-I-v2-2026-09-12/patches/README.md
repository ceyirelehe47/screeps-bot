# Patch mirror

这些 unified diff 仅用于审查实现变化；Agent 不应依赖补丁手工拼装代码。

权威执行字节位于 `implementation/` 与 `tools/`，并由 `IMPLEMENTATION-MANIFEST.json` 和 `INTEGRITY.json` 固定。

- `0001`：用覆盖/连续性判断替代固定 295 行配额；增加离线证据合同与 heartbeat continuity helper。
- `0002`：固定 Git tree 物化、重裁决、独立复核和证据装配工具。
- `0003`：完整正反例与端到端离线链测试。

补丁镜像的审查基底：把原 Guard Joint Probe II 包（SHA-256 `69ded1fa9b6c49cc329e5efdcac10230da1c02244d47df848505c8c5ae520dee`）中的旧 `verify-joint-probe.cjs` 放在 `implementation/verifier-runtime/verify-joint-probe.cjs` 后，顺序 check/apply SERIES。0001 不是从空目录开始的补丁。Agent 执行仍直接使用本包完整文件，不需要重建该审查基底。
