#!/usr/bin/env node
'use strict';
const fs=require('node:fs');
const path=require('node:path');
const T=require('./tool-common.cjs');
function verify(root){
  const integrity=T.readJson(path.join(root,'INTEGRITY.json'),4*1024*1024);
  if(integrity.schema!=='screeps-task-package-integrity/v1'||integrity.packageName!==path.basename(root)
    ||!Array.isArray(integrity.files)||!Number.isSafeInteger(integrity.fileCount)||integrity.fileCount!==integrity.files.length)
    T.fail('PACKAGE_INTEGRITY_METADATA_INVALID');
  const actual=T.listFiles(root).filter(name=>name!=='INTEGRITY.json').sort();
  const expected=integrity.files.map(item=>item.path).sort();
  if(JSON.stringify(actual)!==JSON.stringify(expected))T.fail('PACKAGE_FILE_SET_MISMATCH',{expected:expected.length,actual:actual.length});
  for(const item of integrity.files){const file=path.join(root,...T.normalizeRelative(item.path).split('/')),stat=fs.statSync(file);
    if(stat.size!==item.bytes||T.sha256File(file)!==item.sha256)T.fail('PACKAGE_FILE_HASH_MISMATCH',{path:item.path});}
  return {status:'PACKAGE_INTEGRITY_VERIFIED',packageName:integrity.packageName,packageVersion:integrity.packageVersion,
    files:integrity.fileCount,exactFileSet:true,implementationStatus:integrity.implementationStatus,agentRole:integrity.agentRole};
}
function main(argv){const o=T.options(argv,['package'],['verify']);T.required(o,'package');if(!o.verify)T.fail('EXPLICIT_VERIFY_REQUIRED');const result=verify(path.resolve(o.package));console.log(JSON.stringify(result));}
module.exports={verify,main};if(require.main===module)T.entrypoint(()=>main(process.argv.slice(2)));
