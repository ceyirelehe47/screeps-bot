'use strict';
const fs=require('node:fs');
const path=require('node:path');
const crypto=require('node:crypto');
const cp=require('node:child_process');

class ToolFailure extends Error{constructor(code,details={}){super(code);this.name='ToolFailure';this.code=code;this.details=details;}}
function fail(code,details){throw new ToolFailure(code,details);}
function safeFailure(error){return error instanceof ToolFailure?{error:error.code,...error.details}:{error:'UNEXPECTED_TOOL_FAILURE'};}
function entrypoint(fn){Promise.resolve().then(fn).catch(error=>{process.stderr.write(JSON.stringify(safeFailure(error))+'\n');process.exitCode=1;});}
function sha256(value){return crypto.createHash('sha256').update(value).digest('hex');}
function sha256File(file){return sha256(fs.readFileSync(file));}
function readJson(file,maxBytes=20*1024*1024){
  try{const stat=fs.statSync(file);if(!stat.isFile()||stat.size>maxBytes)fail('FILE_INVALID',{file:path.basename(file)});return JSON.parse(fs.readFileSync(file,'utf8'));}
  catch(error){if(error instanceof ToolFailure)throw error;fail('JSON_UNREADABLE',{file:path.basename(file)});}
}
function writeNew(file,value){fs.mkdirSync(path.dirname(file),{recursive:true,mode:0o700});fs.writeFileSync(file,JSON.stringify(value,null,2)+'\n',{flag:'wx',mode:0o600});}
function writeTextNew(file,text){fs.mkdirSync(path.dirname(file),{recursive:true,mode:0o700});fs.writeFileSync(file,text,{flag:'wx',mode:0o600});}
function options(argv,names,flags=[]){const out={};for(let i=0;i<argv.length;i++){
  const arg=argv[i];if(typeof arg!=='string'||!arg.startsWith('--'))fail('INVALID_ARGUMENTS');const key=arg.slice(2);
  if(!key||Object.prototype.hasOwnProperty.call(out,key))fail('INVALID_ARGUMENTS');
  if(flags.includes(key)){out[key]=true;continue;}if(!names.includes(key)||i+1>=argv.length||argv[i+1].startsWith('--'))fail('INVALID_ARGUMENTS');
  out[key]=argv[++i];
}return out;}
function required(value,...keys){for(const key of keys)if(!value[key])fail('MISSING_ARGUMENT',{key});}
function git(repo,args,{encoding='utf8',maxBuffer=64*1024*1024}={}){
  try{return cp.execFileSync('git',['-C',repo,...args],{encoding,maxBuffer,stdio:['ignore','pipe','pipe']});}
  catch(error){fail('GIT_COMMAND_FAILED',{args});}
}
function gitText(repo,args){return git(repo,args,{encoding:'utf8'}).trim();}
function ensureDirectoryAbsent(dir){if(fs.existsSync(dir))fail('OUTPUT_ALREADY_EXISTS',{path:dir});}
function normalizeRelative(value){
  if(typeof value!=='string'||!value||path.isAbsolute(value)||value.includes('\0'))fail('PATH_INVALID');
  const normalized=value.replace(/\\/g,'/');
  if(normalized.split('/').some(part=>!part||part==='.'||part==='..'))fail('PATH_INVALID',{path:value});
  return normalized;
}
function copyFileNew(source,destination){fs.mkdirSync(path.dirname(destination),{recursive:true,mode:0o700});fs.copyFileSync(source,destination,fs.constants.COPYFILE_EXCL);}
function listFiles(root){const out=[];function walk(dir){for(const entry of fs.readdirSync(dir,{withFileTypes:true}).sort((a,b)=>a.name.localeCompare(b.name))){
  const absolute=path.join(dir,entry.name),relative=path.relative(root,absolute).replace(/\\/g,'/');
  if(entry.isSymbolicLink())fail('SYMLINK_FORBIDDEN',{path:relative});if(entry.isDirectory())walk(absolute);else if(entry.isFile())out.push(relative);else fail('SPECIAL_FILE_FORBIDDEN',{path:relative});
}}walk(root);return out;}
module.exports={ToolFailure,fail,safeFailure,entrypoint,sha256,sha256File,readJson,writeNew,writeTextNew,
  options,required,git,gitText,ensureDirectoryAbsent,normalizeRelative,copyFileNew,listFiles};
