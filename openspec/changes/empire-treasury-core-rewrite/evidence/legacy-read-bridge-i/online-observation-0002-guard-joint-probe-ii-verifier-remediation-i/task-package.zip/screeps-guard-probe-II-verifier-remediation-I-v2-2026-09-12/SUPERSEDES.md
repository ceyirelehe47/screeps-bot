# v2 取代关系与范围

废止旧执行包：

```text
screeps-treasury-compat-guard-joint-probe-II-verifier-remediation-I-complete-implementation-verification-task-package-2026-09-12.zip
SHA-256: b9d924994dd3f5d52f50406bad2d323c8e604ec036f28c92e268b4063fb464a4
```

此前已完成的测试日志与失败报告不得删除。旧包中的 verifier 算法并非因本次夹具修复而更换；只是不再把旧包交给 Agent 当作可跨平台通过的完整任务包。

## 唯一可执行代码变更

`implementation/tests/assembly.spec.cjs` 的第二个用例：

原夹具把 `A.txt` 与 `a.txt` 同时当作两个物理文件；大小写不敏感目录中它们会指向同一文件。本包使用 `Z-upper.txt` / `a-lower.txt`，并核对折叠后的名称互异、使用 `wx` 创建、核对两个文件实际存在。

为了仍覆盖原本的排序回归，用例在自身作用域内给 `T.listFiles` 提供两种固定排列，结束时在 `finally` 恢复。不依赖机器 locale，也不改写生产 `listFiles`、`verify-package` 或主 verifier。错大小写的清单、额外文件和内容变更仍必须拒绝。

`patches/0003-regression-tests.patch` 为修正版测试的完整镜像；`review/fixture-v1-to-v2.patch` 仅供审阅，不属于执行 SERIES，不要二次叠加。

## 明确不变

四个 verifier runtime 文件、九个工具、其他六个测试/夹具文件、两份固定引用文件、heartbeat 规则、成功标签和 Git 基线均保持逐字节不变。测试数仍 30，测试名集合不变，不新增 skip。`validation/support/` 下新增的文件是制包方隔离故障模型，不是运行时实现，也不是 NTFS 全功能模拟器。

## 证据边界

不取代或改写 `64d9271…` 的原始 25 分钟运行；仍仅离线重裁决既有证据。保留原始 toolkit 运行中重建事项的披露。本轮不使用 token、不连接 Screeps、不重启 collector、不上传或 restore。

Windows 29/30 与 WSL ext4 30/30 是用户转交的 Agent 报告。制包方本轮另在 Linux 上复现了原夹具的大小写别名失败，并测试修正版；不能把该模型的结果描述为制包方在原生 Windows/NTFS 上实测通过。
