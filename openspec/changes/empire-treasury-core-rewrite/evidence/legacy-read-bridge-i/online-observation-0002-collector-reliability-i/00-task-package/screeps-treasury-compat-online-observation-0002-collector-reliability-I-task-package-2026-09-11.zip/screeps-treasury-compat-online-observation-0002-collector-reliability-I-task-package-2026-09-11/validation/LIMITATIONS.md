# 制作方验证限制

制作方验证只覆盖补丁机械可应用性、Node 语法和 16 项 fake WebSocket／纯函数回归。

未覆盖：

- Windows 10 实际文件锁、Ctrl+C 和长时间进程行为；
- 官方 `screeps.com` WebSocket；
- 真实 token；
- 20 分钟无上传稳定性探针；
- 正式候选上传、采样和恢复；
- 完整兼容候选 TypeScript／Rollup 构建；
- 线上旧 bot 业务健康。

因此本目录不能作为线上通过证据，也不能与候选历史 195/685 或完整 Treasury 248/1539 相加。
