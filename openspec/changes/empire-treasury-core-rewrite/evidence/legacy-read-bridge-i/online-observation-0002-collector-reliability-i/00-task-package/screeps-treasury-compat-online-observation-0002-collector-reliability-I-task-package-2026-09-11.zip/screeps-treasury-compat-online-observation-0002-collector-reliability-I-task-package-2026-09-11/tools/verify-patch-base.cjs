#!/usr/bin/env node
'use strict';
const fs=require('node:fs');const path=require('node:path');const crypto=require('node:crypto');
function fail(code){throw new Error(code);}
function options(argv){const out={};for(let i=0;i<argv.length;i+=2){if(!argv[i]?.startsWith('--')||!argv[i+1])fail('INVALID_ARGUMENTS');out[argv[i].slice(2)]=argv[i+1];}return out;}
function blob(data){return crypto.createHash('sha1').update(Buffer.from(`blob ${data.length}\0`)).update(data).digest('hex');}
function manifest(){return JSON.parse(fs.readFileSync(path.resolve(__dirname,'..','references','PATCH-BASE.json'),'utf8'));}
function verify(kit){
  const root=path.resolve(kit),m=manifest();const checked=[];
  if(!fs.statSync(root).isDirectory())fail('KIT_NOT_DIRECTORY');
  for(const entry of m.files){
    const target=path.resolve(root,entry.path);
    if(!target.startsWith(root+path.sep)||!fs.statSync(target).isFile())fail(`BASE_FILE_MISSING:${entry.path}`);
    const actual=blob(fs.readFileSync(target));
    if(actual!==entry.gitBlob)fail(`BASE_FILE_CHANGED:${entry.path}`);
    checked.push({path:entry.path,gitBlob:actual});
  }
  return {status:'PATCH_BASE_VERIFIED',sourceRef:m.sourceRef,files:checked.length,checked};
}
function main(argv){const o=options(argv);if(!o.kit)fail('MISSING_ARGUMENT');console.log(JSON.stringify(verify(o.kit)));}
module.exports={verify};
if(require.main===module){try{main(process.argv.slice(2));}catch(e){process.stderr.write(JSON.stringify({error:String(e.message||'VERIFY_FAILED')})+'\n');process.exitCode=1;}}
