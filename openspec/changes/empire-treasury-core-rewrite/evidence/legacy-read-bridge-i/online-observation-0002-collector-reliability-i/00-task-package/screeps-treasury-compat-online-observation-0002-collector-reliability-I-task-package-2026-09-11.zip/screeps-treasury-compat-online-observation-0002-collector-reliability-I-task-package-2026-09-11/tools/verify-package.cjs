#!/usr/bin/env node
'use strict';
const fs=require('node:fs');const path=require('node:path');const crypto=require('node:crypto');
const root=path.resolve(__dirname,'..');
try{
  const manifest=JSON.parse(fs.readFileSync(path.join(root,'INTEGRITY.json'),'utf8'));
  if(manifest.schema!=='screeps-task-package-integrity/v1'||!Array.isArray(manifest.files))throw new Error('bad manifest');
  for(const entry of manifest.files){
    if(typeof entry.path!=='string'||path.isAbsolute(entry.path)||entry.path.split(/[\\/]/).includes('..'))throw new Error('bad path');
    const target=path.resolve(root,entry.path);
    if(!target.startsWith(root+path.sep))throw new Error('escape');
    const data=fs.readFileSync(target);
    const digest=crypto.createHash('sha256').update(data).digest('hex');
    if(data.length!==entry.bytes||digest!==entry.sha256)throw new Error('changed file');
  }
  console.log(JSON.stringify({status:'PACKAGE_FILES_VERIFIED',files:manifest.files.length,gameActions:0}));
}catch{
  process.stderr.write('PACKAGE_INTEGRITY_FAILED\n');process.exitCode=1;
}
