# Treasury Legacy Read Bridge I — Online Observation 0002  
## Collector Reliability I + 一次完整限定线上观察

**本文件是本任务包的最高优先级任务书。**  
本轮不是重新实现 Treasury，不是再次做 Terminal send 实验，也不是把完整 `refactor/empire-treasury-rearchitecture` 分支部署到线上。唯一主线是：

1. 在不上传候选代码的情况下，修复并证明 collector 的终态证据与故障分类可靠；
2. collector 稳定性预检通过后，只执行一次限定兼容桥线上观察；
3. 无论成功、失败或材料不足，都精确恢复本轮上线前的线上模块集合；
4. 将候选源码恢复为已经验收的默认 OFF，关闭构建不再次上传。

---

## 1. 固定仓库、分支与起点

仓库：`ceyirelehe47/screeps-bot`

| 用途 | 固定值 |
|---|---|
| 完整 Treasury／证据分支 | `refactor/empire-treasury-rearchitecture` |
| 本任务制作时证据分支 HEAD | `f4204c2b4c0bc3637ac0347e8d87b23d516bb934` |
| 兼容候选分支 | `compat/treasury-read-bridge-i` |
| 本任务制作时兼容分支 HEAD | `91532745123ca14cddb78385f9a88800fca4bf1a` |
| 旧线上生产源基线 | `06ffedb7c558e0bc625f4a2ff450c474fb9d6f1c` |
| 固定读取算法来源 | `01bd9831454950c4928df98dd8679692b55603e5` |
| 兼容工具基底来源 | `f4204c2…` 下上一轮 `package-and-tooling/` Git 对象 |
| 上一轮线上终态 | `ONLINE_COMPAT_READ_INCONCLUSIVE / RESTORED` |
| 上一轮缺口 | 候选上传、运行身份和恢复均有证据，但首个采样点前 collector 退出；桥样本为 0 |

启动后立即执行：

```bash
git -C "$REFACTOR_REPO" fetch origin
git -C "$COMPAT_REPO" fetch origin

git -C "$REFACTOR_REPO" rev-parse HEAD
git -C "$REFACTOR_REPO" rev-parse origin/refactor/empire-treasury-rearchitecture
git -C "$COMPAT_REPO" rev-parse HEAD
git -C "$COMPAT_REPO" rev-parse origin/compat/treasury-read-bridge-i

git -C "$REFACTOR_REPO" status --short
git -C "$COMPAT_REPO" status --short
```

要求两个工作树均干净，且本地／远端 HEAD 与上表一致。任一 HEAD 已前移、分叉或工作树不净，停止在线部分并报告 `BASELINE_DRIFT`；不要自动 rebase、merge、reset、force 或把补丁手工套到未知版本。

`bd9570d…`、`54d0676…` 和早期 Terminal Lab 都是历史，不是本轮起点。

---

## 2. 不可突破的范围

### 2.1 允许修改

**兼容候选分支：**

- 仅 `src/runtime/treasuryCompatConfig.ts`
  - 为无上传稳定性探针绑定一次临时远期 profile；
  - 探针通过后，为正式线上观察重新绑定最终 profile；
  - 收尾恢复已验收的默认 OFF 原字节。

**证据分支：**

- 本轮任务包原件、补丁、实际使用的外部工具源码、测试和证据；
- 新证据目录：
  `openspec/changes/empire-treasury-core-rewrite/evidence/legacy-read-bridge-i/online-observation-0002-collector-reliability-i/`

**工作树外工具目录：**

- 使用本包补丁修改上一轮外部观察工具的复制件；
- 这些工具不进入 Screeps bundle。

### 2.2 禁止修改

- `src/main.ts`
- `src/runtime/treasuryCompatRead.ts`
- `src/runtime/treasuryCompatReadCore.generated.ts`
- `src/runtime/treasuryCompatRuntime.ts`
- `src/runtime/treasuryCompatTypes.ts`
- 完整 Treasury facade、kernel、adapter、policy、observation、commitments
- 旧 `resourceControl`、reservation、Defense、市场、物流及 Memory 生命周期
- Rollup、依赖、部署守卫和生产测试预算
- 上一轮任何既有 evidence 原件

### 2.3 禁止行为

- 不部署完整 `refactor` 分支；
- 不执行 Terminal `send`、market `deal`、console 注入或 Memory 写；
- 不迁移旧表；
- 不切换活动世界分支；
- 不停止用户已有长期监控；
- 不自动重连并拼接一轮采样。正式观察期间连接一旦关闭，本轮即失败闭合并恢复；
- 不因第一次失败而换窗口进行第二次启用上传；
- 不把上传成功、恢复成功、离线测试成功写成“完整 Treasury 已上线”。

---

## 3. 本包补丁的作用

补丁基于上一轮已归档工具的固定 Git blob，不覆盖历史目录。

补丁序列：

```text
0001-collector-terminal-evidence.patch
0002-guard-classification-and-probe-verifier.patch
0003-tooling-regression-tests.patch
```

主要变化：

1. collector 明确区分连接、认证、console、CPU 与终态；
2. WebSocket `error` 与 `close` 不再都压缩成模糊的 `collector_stalled`；
3. 保存 close code、经脱敏且有界的 close reason；
4. arbitrary error message／stack 仍不落原文，只保存安全字段、长度和脱敏后摘要哈希；
5. 正常结束、可处理异常、未捕获异常和进程普通退出均尽最大可能产生单一 footer 与 `collector-result.json`；
6. 增加跨平台文件式 collector 关闭请求；
7. guard 读取 collector 终态，区分：
   - heartbeat 缺失或外来实例；
   - 尚未 streaming；
   - socket 非 open；
   - heartbeat 过旧；
   - 从未收到 console；
   - console 静默；
   - collector 主动报告失败；
   - collector 以具体稳定原因退出；
8. 增加无上传稳定性探针验证器；
9. 增加 16 项制作方回归，其中包含真实子进程、假的 WebSocket close/error、单一 footer、脱敏和探针终态。

**硬限制：**操作系统强制终止、主机断电或文件系统完全不可写仍可能无法由被杀进程自己生成 footer。此类情况必须由 shell 退出码、进程监督证据和缺失文件共同判为失败；不得补造 footer。

---

## 4. 构造本轮工具副本并应用补丁

本任务包不要求继续使用上一轮原始 zip。它会从固定证据 commit 中逐 Git blob 构造只读基底。

```bash
TASK="/absolute/path/to/this-task-package"
TOOLKIT="/absolute/path/outside/all-git-worktrees/compat-observation-0002-toolkit"

node "$TASK/tools/verify-package.cjs"
node "$TASK/tools/materialize-base.cjs" \
  --repo "$REFACTOR_REPO" \
  --out "$TOOLKIT"

node "$TASK/tools/verify-patch-base.cjs" --kit "$TOOLKIT"
node "$TASK/tools/apply-series.cjs" --kit "$TOOLKIT"
```

要求：

- `TOOLKIT` 事先不存在；
- materializer 从 `f4204c2…` 的固定路径读取 17 个 Git blob；
- 任一 blob 不匹配立即失败；
- patch helper 先在临时副本上完成全部 `--check` 和应用，再应用到实际副本；
- patch reject 时不得手工拼接或使用 `--reject` 继续；
- `PATCH-APPLICATION.json` 是补丁实际版本证据。

执行：

```bash
for f in \
  collector-diagnostics.cjs \
  console-collector.cjs \
  deadline-guard.cjs \
  request-collector-stop.cjs \
  session.cjs \
  verify-collector-probe.cjs \
  watch.cjs
do
  node --check "$TOOLKIT/$f"
done

node --test "$TOOLKIT"/tests/*.spec.cjs \
  > "$EVIDENCE/tool-tests-original.tap" \
  2> "$EVIDENCE/tool-tests-original.stderr"
printf '%s\n' "$?" > "$EVIDENCE/tool-tests-original.exit.txt"
```

制作方结果是 16/16，但 Agent 必须在实际 Node 22 / Windows 环境重新执行。不能用制作方 Linux 结果代替。

### 独立反例

在不修改补丁原始测试的前提下另建 `agent-independent/`，至少覆盖：

- `error` 后无 `close`；
- `error` 后迟到 `close`；
- close code/reason 缺失；
- result 文件损坏或外来 runId；
- heartbeat 新鲜但 console 静默；
- console 新鲜但 socket 已 closed；
- footer 重复；
- stop request 外来 runId／非法 reason；
- 私有诊断中注入 fake token、URL token、36hex；
- collector-result 写盘失败；
- heartbeat 写盘失败；
- SIGINT 或文件关闭请求的 Windows 行为。

每个失败反例配合法正对照。测试只能使用 fake token 和回环／进程替身，不连接官方服。

如果补丁在真实环境暴露缺陷，允许仅修本轮外部工具；必须：

1. 保存补丁原样失败证据；
2. 单独记录 `TOOLING_REMEDIATION` diff；
3. 重跑原始 16 项、全部独立反例和受影响故障变异；
4. 在正式探针前固定实际工具文件摘要；
5. 不借工具修复修改候选源码或放宽线上恢复条件。

---

## 5. 凭据和线上权限边界

凭据从本地 `.secret.json` 的 `main` 读取。命令行只传**文件路径**，不传 token。

固定目标：

```text
server   https://screeps.com
username forster
userId   634fe406347a7b69b28aeccb
branch   default（唯一 activeWorld）
shard    shard1
```

每次线上阶段均重新认证账号、唯一活动分支和当前代码模块。之前的恢复证据只说明 2026-09-11 上一轮收尾时已恢复，不证明执行本任务时线上仍未变化。

不得保存：

- 原 token；
- token 前缀；
- 带 token 的 URL；
- HTTP authorization header；
- 全机器进程 CommandLine；
- 未经审查的异常正文或服务器响应正文。

本补丁的 `collector-private.jsonl` 不保留任意异常 message／stack 原文，只保留稳定安全字段、长度、截断标记和脱敏后 SHA-256；仍需在归档前进行秘密扫描。

---

## 6. 阶段 A：新鲜只读前检

在兼容候选仍为默认 OFF 时执行：

```bash
node "$TOOLKIT/token-status.cjs" --secret "$SECRET"

node "$TOOLKIT/preflight-read.cjs" \
  --repo "$COMPAT_REPO" \
  --secret "$SECRET" \
  --out "$EVIDENCE/preflight-off"
```

必须重新确认：

- 账号与 userId；
- `default` 是唯一 `activeWorld=true`；
- 当前线上模块集合非空且只有预期有效模块；
- 当前线上完整逐模块内容与本轮备份一致；
- 已知旧生产摘要、字节数和内嵌来源仍一致；
- `E3N59` 与 `E4N58` 仍属于 shard1 上的当前账号；
- game tick 可读并前进。

若线上代码已变化，停止，不以旧 `BUILD_COMMIT`、近似大小或相似 hash 放行。不要用旧备份覆盖新操作者代码。

---

## 7. 阶段 B：无上传 collector 稳定性探针

### 7.1 绑定远期探针 profile

在兼容分支仅改 `treasuryCompatConfig.ts`：

```text
enabled       true
shardName     shard1
rooms         E3N59, E4N58
resources     energy, H
interval      100
endTick       startTick + 1100
minBucket     2000
maxSampleCpu  2
reserveCpu    5
maxLogBytes   16384
```

探针 `startTick` 选择足够远，使至少 20 分钟 collector 探针及构建完成时窗口仍未开始。建议相对实时 tick 至少留 2000 tick；这是探针 profile，不会上传。

提交：

```text
PROBE_PROFILE_HEAD
```

除 config 外有任何候选差异即停止。

### 7.2 独立构建并准备 probe session

```bash
git worktree add --detach "$PROBE_BUILD" "$PROBE_PROFILE_HEAD"
cd "$PROBE_BUILD"
unset DEST DEPLOY_ALLOW_DIRTY NODE_OPTIONS
npm ci

node "$TOOLKIT/check-profile.cjs" \
  --repo "$PROBE_BUILD" \
  --mode on \
  --observed-tick "$OFF_PREFLIGHT_TICK"

node "$TOOLKIT/profile-smoke.cjs" --repo "$PROBE_BUILD"
npx --no-install tsc --noEmit -p tsconfig.build.json
npx --no-install tsc --noEmit -p tsconfig.json
npm run build

node "$TOOLKIT/preflight-read.cjs" \
  --repo "$PROBE_BUILD" \
  --secret "$SECRET" \
  --out "$EVIDENCE/preflight-probe"

node "$TOOLKIT/prepare-session.cjs" \
  --repo "$PROBE_BUILD" \
  --preflight "$EVIDENCE/preflight-probe" \
  --run "$PROBE_RUN"
```

### 7.3 只启动 collector，不启动 guard，不执行 upload

```bash
(
  node "$TOOLKIT/console-collector.cjs" \
    --repo "$PROBE_BUILD" \
    --secret "$SECRET" \
    --run "$PROBE_RUN" \
    > "$EVIDENCE/probe-collector.stdout" \
    2> "$EVIDENCE/probe-collector.stderr"
  printf '%s\n' "$?" > "$EVIDENCE/probe-collector.exit.txt"
) &
PROBE_COLLECTOR_PID=$!
printf '%s\n' "$PROBE_COLLECTOR_PID" > "$EVIDENCE/probe-collector.pid"
```

探针期间：

- `upload-attempt.json` 必须始终不存在；
- 不执行 `upload-once`；
- 不启动恢复 guard，因为线上代码从未改变；
- 不注入 console 表达式；
- collector 连续运行至少 `1,200,000 ms`；
- console 与 CPU 两个目标频道都必须在认证后持续出现；
- 运行区间必须超过上一轮约 14 分钟的中断点；
- 不允许通过重新启动 collector 把多个区间拼接成一次探针。

达到探针范围后使用文件式正常收尾：

```bash
node "$TOOLKIT/request-collector-stop.cjs" \
  --repo "$PROBE_BUILD" \
  --run "$PROBE_RUN" \
  --reason probe_complete

node "$TOOLKIT/verify-collector-probe.cjs" \
  --repo "$PROBE_BUILD" \
  --run "$PROBE_RUN" \
  --min-ms 1200000 \
  > "$EVIDENCE/probe-verification.json"
```

通过条件：

- `collector-result.json`：`status=closed`、`reason=probe_complete`、`exitCode=0`；
- 最终 heartbeat：认证、console、CPU 和关闭时间线完整；
- 认证后持续时间至少 20 分钟；
- `console.jsonl` 恰好一个本 runId footer；
- 无上传 attempt；
- 进程实际退出；
- stdout、stderr、PID、退出码和结果文件全部归档；
- 秘密扫描零命中。

任一条件失败：本轮终止于 `COLLECTOR_PROBE_FAILED / NOT_DEPLOYED`。不要进入正式上传。

---

## 8. 阶段 C：正式 profile 与候选验证

探针通过后，不复用 `PROBE_RUN` 或 `PROBE_BUILD`。

重新只读获取当前 tick，并只改 config 绑定正式窗口：

- `S` 为 100 的整数倍；
- `endTick=S+1100`；
- 12 个预定采样点；
- 正式上传完成时至少距离 S 100 tick；
- 准备耗尽余量时，可在第一次启用上传 attempt 产生前重新绑定、重新提交和重新验证；
- 第一次启用 attempt 产生后不得改 S、换 run 目录或第二次启用。

提交：

```text
PROFILE_HEAD
```

验证：

```bash
git worktree add --detach "$BUILD" "$PROFILE_HEAD"
cd "$BUILD"
unset DEST DEPLOY_ALLOW_DIRTY NODE_OPTIONS
npm ci

node "$TOOLKIT/check-profile.cjs" \
  --repo "$BUILD" \
  --mode on \
  --observed-tick "$CURRENT_TICK"

node "$TOOLKIT/profile-smoke.cjs" --repo "$BUILD"
npx --no-install tsc --noEmit -p tsconfig.build.json
npx --no-install tsc --noEmit -p tsconfig.json
npm run build
```

再做最终线上前检与会话固定：

```bash
node "$TOOLKIT/preflight-read.cjs" \
  --repo "$BUILD" \
  --secret "$SECRET" \
  --out "$EVIDENCE/preflight-final"

node "$TOOLKIT/prepare-session.cjs" \
  --repo "$BUILD" \
  --preflight "$EVIDENCE/preflight-final" \
  --run "$RUN"
```

要求备份、候选、实际 bundle、内嵌 identity、Git HEAD/tree、活动分支和逐模块摘要分别记录，不把不同 hash 混写成一个“构建 hash”。

---

## 9. 阶段 D：唯一一次限定线上观察

### 9.1 启动 collector 与恢复 guard

先启动 collector，并把 shell stderr 与退出码保存在工作树外：

```bash
(
  node "$TOOLKIT/console-collector.cjs" \
    --repo "$BUILD" \
    --secret "$SECRET" \
    --run "$RUN" \
    > "$EVIDENCE/collector.stdout" \
    2> "$EVIDENCE/collector.stderr"
  printf '%s\n' "$?" > "$EVIDENCE/collector.exit.txt"
) &
COLLECTOR_PID=$!
```

等待同一 runId 满足：

- heartbeat `state=streaming`
- `socketState=open`
- `authenticatedAtMs` 存在
- `lastConsoleAtMs` 存在且新鲜
- `lastCpuAtMs` 存在且新鲜

再启动已授权的恢复 guard：

```bash
(
  node "$TOOLKIT/deadline-guard.cjs" \
    --repo "$BUILD" \
    --secret "$SECRET" \
    --run "$RUN" \
    --execute \
    > "$EVIDENCE/guard.stdout" \
    2> "$EVIDENCE/guard.stderr"
  printf '%s\n' "$?" > "$EVIDENCE/guard.exit.txt"
) &
GUARD_PID=$!
```

确认 `guard-ready.json` 为本 runId、状态 ready、collector/socket 状态正确且新鲜。

### 9.2 上传固定快照一次

```bash
node "$TOOLKIT/upload-once.cjs" \
  --repo "$BUILD" \
  --secret "$SECRET" \
  --run "$RUN"

node "$TOOLKIT/upload-once.cjs" \
  --repo "$BUILD" \
  --secret "$SECRET" \
  --run "$RUN" \
  --execute
```

第一条是 dry run；第二条是唯一启用 POST。

禁止：

- `npm run push`
- 重新构建后上传另一份产物
- 重复调用 `--execute`
- 删除 attempt 文件绕过一次性门禁
- 上传报错后再次启用
- collector 退出后启动另一个 collector 续接同轮数据

上传结果不确定时，按“可能已上传”处理，保留 attempt 并由 guard 安全恢复。

---

## 10. 正式观察通过标准

本轮目的不是“收到过一条日志”，而是闭合完整窗口。

`ONLINE_COMPAT_READ_OBSERVED / RESTORED` 只有全部满足才可使用：

1. 12 个预定 tick 全部各有且仅有一条一致报告；
2. 无冲突重复 tick；
3. 每条均：
   - `kind=treasury-legacy-read-bridge`
   - `authorizesActions=false`
   - `spendable=null`
   - `kernelLifecycleRun=false`
   - `facadeQueryRun=false`
   - shard、rooms、resources 与 profile 完全一致；
4. 每个房间的 storage/terminal 行恰好一条；
5. `directStatus=ok`；
6. `coreComparison=match_selected_scope`；
7. 无 `mismatch`、`existence_mismatch`、`fault_disabled`、`output_limited`；
8. commitment 输入没有把缺失、损坏或超界伪装成空表；
9. `commitments.status=read_complete`；
10. 无连续 partial、CPU stop reason 或 collector terminal failure；
11. 至少 11 条 `previousRun.cpuIncludingEmit` 可精确归属到前一个采样 tick且不超过 5 CPU；
12. 最末样本因没有下一样本而缺少 `previousRun` 时必须明确标注，不得伪造；若能从既有 profiler 原件取得则单列来源；
13. collector 从上传前到恢复完成保持同一进程、同一 runId、同一 WebSocket 会话；
14. collector 有且仅有一个 footer 与一个 terminal result；
15. guard 原始关闭原因、触发时刻、恢复开始／完成时刻完整；
16. 线上模块集合精确恢复，并取得随后主循环继续运行的独立证据；
17. 归档前秘密扫描零命中。

任何一个采样点缺失、正式期间连接关闭、collector 重启、runId 改变或数据拼接，只能：

```text
ONLINE_COMPAT_READ_INCONCLUSIVE / RESTORED
```

恢复不确认则：

```text
ONLINE_CLOSE_UNCONFIRMED
```

不要因只差一条样本而在本轮再开第二窗口。

---

## 11. 自动关闭与人工关闭

guard 继续处理：

- collector 具体终态；
- heartbeat 过旧；
- console 静默；
- 桥 fault／authority 异常；
- core observation mismatch；
- 连续 partial；
- sample CPU 超界；
- game tick 越过窗口；
- 最后样本到达；
- 墙钟截止；
- 显式关闭请求。

人工发现旧 bot 异常、活动分支变化、第三方部署、连续 bucket 风险或无法解释的业务异常时：

```bash
node "$TOOLKIT/request-close.cjs" \
  --repo "$BUILD" \
  --run "$RUN"
```

这只写关闭请求，不代表已经恢复。最终依据：

- `guard-result.json`
- `restore-result.json`
- 精确 user/code 回读
- 唯一活动分支复核
- 恢复后新鲜主循环／CPU 帧

本补丁不会自动重连。`socket_closed`、`socket_error_without_close` 等会形成具体 collector result，guard 应使用该具体原因而不是退化为笼统 `collector_stalled`。

---

## 12. 精确恢复与默认 OFF

恢复前必须重新认证：

- 账号；
- userId；
- 唯一活动世界分支；
- 当前远端模块集合。

规则：

- 当前==candidate：恢复备份并逐模块回读；
- 当前==backup 且没有未决启用：幂等不写；
- 当前==第三方产物：拒绝覆盖并报告冲突；
- 当前不可读或 POST 结果不确定：保持 `ONLINE_CLOSE_UNCONFIRMED`；
- 不用旧备份覆盖未知新代码；
- 不恢复 Memory。

恢复确认后：

1. 在兼容候选分支把 `treasuryCompatConfig.ts` 恢复为 `9153274…` 的默认 OFF 原字节；
2. 提交 `CLOSED_SOURCE_HEAD`；
3. 执行 off profile 检查、双 TypeScript 检查和必要构建；
4. **不上传关闭构建**；
5. 线上保留恢复出来的本轮前检备份原字节。

---

## 13. 证据目录

证据分支新增：

```text
openspec/changes/empire-treasury-core-rewrite/evidence/legacy-read-bridge-i/
  online-observation-0002-collector-reliability-i/
    00-task-package/
    01-baseline/
    02-tooling/
    03-independent-tests/
    04-probe-no-upload/
    05-profile-and-build/
    06-online-run/
    07-restore/
    08-analysis/
    REPORT.md
```

至少保留：

- 原任务 zip 与 SHA-256；
- `PATCH-BASE.json`、三个 patch、`PATCH-APPLICATION.json`；
- 实际使用工具逐文件 SHA-256／Git blob；
- 制作方 16 项测试、Agent 原样重跑、独立反例及退出码；
- probe stdout/stderr/PID/exit、heartbeat、console、collector-result、单一 footer；
- 正式 run 的 preflight/session/upload/collector/guard/restore 原始文件；
- 12 个采样点索引和逐字段判读；
- 线上前后完整模块摘要与逐模块 diff；
- 恢复后运行确认；
- config ON/OFF blob；
- 两条分支最终 SHA；
- 秘密扫描结果。

完整线上模块正文、原凭据、全量 Memory 和不适合公开的原始敏感数据留在受控工作树外；仓库中保存摘要和必要脱敏证据。不得为了“原始”二字提交秘密。

---

## 14. 提交规则

- 兼容分支与证据分支分别线性 commit/push；
- 不 merge 两个分支；
- 不 amend 已推送提交；
- 不 reset/force；
- 工具补丁、工具后续修正、probe、正式 profile、OFF 收尾、证据报告的归属分开；
- 候选分支的非 config 差异恒为零；
- 旧 evidence 目录原字节不变。

建议提交身份：

```text
compat:
  PROBE_PROFILE_HEAD
  PROFILE_HEAD
  CLOSED_SOURCE_HEAD

refactor:
  TOOLING_EVIDENCE_HEAD
  PROBE_EVIDENCE_HEAD
  ONLINE_RUN_EVIDENCE_HEAD
  FINAL_REPORT_HEAD
```

实际可合并相邻纯证据提交，但不能把候选生产 config 与证据工具混到同一分支。

---

## 15. Agent 最终回答

最终必须明确列出：

1. 启动与最终两条分支 SHA；
2. 补丁是否原样应用；若有工具修复，给出单独 diff 身份；
3. 原始 16 项和 Agent 独立反例结果；
4. 无上传稳定性探针的真实持续时间、console/CPU 覆盖、footer/result；
5. 是否产生唯一上传 attempt及其结果；
6. 12 个预定样本的实际获得数、完整数、缺失 tick；
7. CPU 可归属样本数、最大值和最后样本成本口径；
8. guard 的具体关闭原因；
9. 精确恢复、活动分支和恢复后主循环确认；
10. `CLOSED_SOURCE_HEAD` 默认 OFF 证据；
11. 最终标签；
12. 未验证事项。

不能只给“全部通过”。所有结论须指向仓库内原始证据路径。

---

## 16. 制作方验证边界

本任务包制作时已经完成：

- 固定 Git blob 与补丁基底核对；
- 三个 patch 在临时 Git 工作树顺序 `git apply --check`；
- 三个 patch 顺序应用成功；
- Node 语法检查；
- 16/16 Node 测试：
  - error→close；
  - error 无 close；
  - 单一 footer/result；
  - close code/reason；
  - fake secret 脱敏；
  - heartbeat 分类；
  - probe verifier；
  - 文件式正常关闭。

制作方测试使用 Linux、Node 22 和 fake WebSocket，没有：

- 连接 screeps.com；
- 使用真实 token；
- 上传代码；
- 读取真实玩家世界；
- 验证 Windows 文件锁／信号全部行为；
- 执行 20 分钟官方服探针；
- 产生任何真实兼容桥样本。

这些必须由执行 Agent 完成，且不得把制作方 16 项与候选历史 195/685 或完整 Treasury 248/1539 混成一个测试总数。
