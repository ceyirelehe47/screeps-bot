#!/usr/bin/env node
'use strict';
const fs=require('node:fs');const os=require('node:os');const path=require('node:path');const crypto=require('node:crypto');const cp=require('node:child_process');
const {verify}=require('./verify-patch-base.cjs');
function fail(code){throw new Error(code);}
function options(argv){const out={};for(let i=0;i<argv.length;i+=2){if(!argv[i]?.startsWith('--')||!argv[i+1])fail('INVALID_ARGUMENTS');out[argv[i].slice(2)]=argv[i+1];}return out;}
function sha256(p){return crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');}
function apply(dir,patch,check=false){
  const args=['-C',dir,'apply','--no-index','--whitespace=error-all'];
  if(check)args.push('--check');args.push(patch);
  cp.execFileSync('git',args,{stdio:['ignore','pipe','pipe'],timeout:20000});
}
function main(argv){
  const o=options(argv);if(!o.kit)fail('MISSING_ARGUMENT');
  const kit=path.resolve(o.kit),task=path.resolve(__dirname,'..'),patchDir=path.join(task,'patches');
  const names=fs.readFileSync(path.join(patchDir,'SERIES'),'utf8').split(/\r?\n/).filter(Boolean);
  if(!names.length||names.some(n=>path.basename(n)!==n||!/^000\d-.+\.patch$/.test(n)))fail('PATCH_SERIES_INVALID');
  verify(kit);
  const temp=fs.mkdtempSync(path.join(os.tmpdir(),'compat-observation-patch-check-'));
  try{
    fs.cpSync(kit,temp,{recursive:true});
    for(const name of names){const patch=path.join(patchDir,name);apply(temp,patch,true);apply(temp,patch,false);}
    verify(kit);
    for(const name of names){const patch=path.join(patchDir,name);apply(kit,patch,true);apply(kit,patch,false);}
    const record={status:'PATCH_SERIES_APPLIED',at:new Date().toISOString(),patches:names.map(name=>({name,sha256:sha256(path.join(patchDir,name))}))};
    fs.writeFileSync(path.join(kit,'PATCH-APPLICATION.json'),JSON.stringify(record,null,2)+'\n',{flag:'wx',mode:0o600});
    console.log(JSON.stringify(record));
  }finally{fs.rmSync(temp,{recursive:true,force:true});}
}
try{main(process.argv.slice(2));}catch(e){process.stderr.write(JSON.stringify({error:String(e.message||'PATCH_APPLY_FAILED')})+'\n');process.exitCode=1;}
