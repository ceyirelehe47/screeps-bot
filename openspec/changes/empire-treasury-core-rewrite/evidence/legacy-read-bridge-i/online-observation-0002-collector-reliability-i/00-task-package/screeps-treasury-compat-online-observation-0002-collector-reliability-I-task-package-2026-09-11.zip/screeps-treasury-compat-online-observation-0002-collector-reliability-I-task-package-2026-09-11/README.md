# Screeps Treasury 兼容线上观察 0002 — Agent 任务包

本包用于接续 `ONLINE_COMPAT_READ_INCONCLUSIVE / RESTORED`：先补强 collector 终态证据与 guard 故障分类，完成一次**不上传代码**的官方服稳定性探针；探针通过后，才允许执行一次限定兼容桥线上观察并精确恢复原件。

## 入口

1. 先运行本包完整性检查：

```bash
node tools/verify-package.cjs
```

2. 完整阅读并执行：

```text
AGENT-RUN.md
```

3. 补丁顺序：

```text
patches/SERIES
```

## 包内内容

- `AGENT-RUN.md`：权威任务书；
- `patches/`：三份可顺序应用的 unified patch；
- `references/PATCH-BASE.json`：固定 Git blob 基底；
- `tools/materialize-base.cjs`：从证据 commit 构造上一轮工具副本；
- `tools/verify-patch-base.cjs`：补丁前基底核验；
- `tools/apply-series.cjs`：先在临时副本验证，再应用补丁；
- `validation/`：制作方 patch apply、语法和 16 项 fake WebSocket 测试证据；
- `INTEGRITY.json`：本包逐文件 SHA-256。

## 重要边界

解压或应用补丁本身不会连接 Screeps，也不会上传代码。  
在线动作只有在 `AGENT-RUN.md` 的前检、无上传稳定性探针、发布／恢复授权和一次性门禁全部满足后才可执行。

补丁只修改工作树外的观察工具复制件，不修改兼容桥、完整 Treasury、`main.ts`、Memory 或经济动作。
