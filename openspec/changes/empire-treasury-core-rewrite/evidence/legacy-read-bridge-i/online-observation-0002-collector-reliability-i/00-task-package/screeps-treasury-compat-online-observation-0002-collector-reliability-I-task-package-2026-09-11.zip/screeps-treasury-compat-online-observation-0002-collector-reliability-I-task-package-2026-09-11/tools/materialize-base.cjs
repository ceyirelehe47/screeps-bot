#!/usr/bin/env node
'use strict';
const fs=require('node:fs');const path=require('node:path');const crypto=require('node:crypto');const cp=require('node:child_process');
function fail(code){throw new Error(code);}
function options(argv){const out={};for(let i=0;i<argv.length;i+=2){if(!argv[i]?.startsWith('--')||!argv[i+1])fail('INVALID_ARGUMENTS');out[argv[i].slice(2)]=argv[i+1];}return out;}
function blob(data){return crypto.createHash('sha1').update(Buffer.from(`blob ${data.length}\0`)).update(data).digest('hex');}
function safeRelative(p){return typeof p==='string'&&p.length>0&&!path.isAbsolute(p)&&!p.split(/[\\/]/).includes('..');}
function readManifest(){
  const p=path.resolve(__dirname,'..','references','PATCH-BASE.json');
  return JSON.parse(fs.readFileSync(p,'utf8'));
}
function main(argv){
  const o=options(argv);if(!o.repo||!o.out)fail('MISSING_ARGUMENT');
  const repo=path.resolve(o.repo),out=path.resolve(o.out),m=readManifest();
  if(fs.existsSync(out))fail('OUTPUT_ALREADY_EXISTS');
  cp.execFileSync('git',['-C',repo,'cat-file','-e',`${m.sourceRef}^{commit}`],{stdio:'ignore',timeout:10000});
  fs.mkdirSync(path.dirname(out),{recursive:true});
  const tmp=out+`.tmp-${process.pid}-${crypto.randomBytes(4).toString('hex')}`;
  fs.mkdirSync(tmp,{recursive:false,mode:0o700});
  try{
    for(const entry of m.files){
      if(!safeRelative(entry.path)||!/^[a-f0-9]{40}$/.test(entry.gitBlob))fail('MANIFEST_INVALID');
      const spec=`${m.sourceRef}:${m.sourcePath}/${entry.path}`;
      const data=cp.execFileSync('git',['-C',repo,'show',spec],{encoding:null,maxBuffer:20*1024*1024,timeout:20000});
      if(blob(data)!==entry.gitBlob)fail(`SOURCE_BLOB_MISMATCH:${entry.path}`);
      const target=path.join(tmp,entry.path);fs.mkdirSync(path.dirname(target),{recursive:true});
      fs.writeFileSync(target,data,{mode:0o600});
    }
    fs.renameSync(tmp,out);
  }catch(e){fs.rmSync(tmp,{recursive:true,force:true});throw e;}
  console.log(JSON.stringify({status:'TOOL_BASE_MATERIALIZED',sourceRef:m.sourceRef,files:m.files.length,out}));
}
try{main(process.argv.slice(2));}catch(e){process.stderr.write(JSON.stringify({error:String(e.message||'MATERIALIZE_FAILED')})+'\n');process.exitCode=1;}
